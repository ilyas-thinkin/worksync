--
-- PostgreSQL database dump
--

\restrict ZJJ3hPJfJjF7AAnbZgQESGF4zi2Dqf8dH36dJWkJyWDrFnxNnxfLnCxFXzGI28H

-- Dumped from database version 17.7 (Debian 17.7-0+deb13u1)
-- Dumped by pg_dump version 17.7 (Debian 17.7-0+deb13u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: log_material_transaction(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.log_material_transaction() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM pg_notify('worksync_changes', json_build_object(
        'table', TG_TABLE_NAME,
        'action', TG_OP,
        'id', NEW.id,
        'line_id', NEW.line_id,
        'work_date', NEW.work_date
    )::text);
    RETURN NEW;
END;
$$;


--
-- Name: notify_data_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.notify_data_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    payload jsonb;
BEGIN
    IF TG_TABLE_NAME = 'employee_process_assignments' THEN
        IF (TG_OP = 'DELETE') THEN
            payload = jsonb_build_object(
                'entity', TG_TABLE_NAME,
                'action', TG_OP,
                'process_id', OLD.process_id,
                'employee_id', OLD.employee_id,
                'line_id', OLD.line_id
            );
        ELSE
            payload = jsonb_build_object(
                'entity', TG_TABLE_NAME,
                'action', TG_OP,
                'process_id', NEW.process_id,
                'employee_id', NEW.employee_id,
                'line_id', NEW.line_id
            );
        END IF;
        PERFORM pg_notify('data_change', payload::text);
        RETURN NULL;
    END IF;

    IF (TG_OP = 'DELETE') THEN
        payload = jsonb_build_object(
            'entity', TG_TABLE_NAME,
            'action', TG_OP,
            'id', OLD.id
        );
        IF TG_TABLE_NAME = 'product_processes' THEN
            payload = payload || jsonb_build_object('product_id', OLD.product_id);
        END IF;
    ELSE
        payload = jsonb_build_object(
            'entity', TG_TABLE_NAME,
            'action', TG_OP,
            'id', NEW.id
        );
        IF TG_TABLE_NAME = 'product_processes' THEN
            payload = payload || jsonb_build_object('product_id', NEW.product_id);
        END IF;
    END IF;

    PERFORM pg_notify('data_change', payload::text);
    RETURN NULL;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: app_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_settings (
    key character varying(50) NOT NULL,
    value character varying(100) NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    table_name character varying(50) NOT NULL,
    record_id integer NOT NULL,
    action character varying(20) NOT NULL,
    old_values jsonb,
    new_values jsonb,
    changed_by integer,
    changed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    reason text,
    ip_address character varying(50),
    user_agent text,
    session_id character varying(100),
    request_path character varying(255),
    http_method character varying(10)
);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: employee_attendance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_attendance (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    attendance_date date NOT NULL,
    in_time time without time zone,
    out_time time without time zone,
    status character varying(30) DEFAULT 'present'::character varying,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: employee_attendance_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_attendance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_attendance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_attendance_id_seq OWNED BY public.employee_attendance.id;


--
-- Name: employee_process_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_process_assignments (
    id integer NOT NULL,
    process_id integer NOT NULL,
    employee_id integer NOT NULL,
    assigned_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    line_id integer
);


--
-- Name: employee_process_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_process_assignments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_process_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_process_assignments_id_seq OWNED BY public.employee_process_assignments.id;


--
-- Name: employees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employees (
    id integer NOT NULL,
    emp_code character varying(50) NOT NULL,
    emp_name character varying(100) NOT NULL,
    designation character varying(100),
    default_line_id integer,
    qr_code_path character varying(255),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by integer,
    updated_by integer,
    manpower_factor numeric DEFAULT 1 NOT NULL,
    CONSTRAINT emp_code_format CHECK (((emp_code)::text ~ '^[A-Z0-9]+$'::text)),
    CONSTRAINT employees_manpower_factor_check CHECK ((manpower_factor > (0)::numeric))
);


--
-- Name: employees_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employees_id_seq OWNED BY public.employees.id;


--
-- Name: line_daily_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.line_daily_metrics (
    id integer NOT NULL,
    line_id integer NOT NULL,
    work_date date NOT NULL,
    forwarded_quantity integer DEFAULT 0 NOT NULL,
    remaining_wip integer DEFAULT 0 NOT NULL,
    materials_issued integer DEFAULT 0 NOT NULL,
    updated_by integer,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    qa_output integer DEFAULT 0 NOT NULL,
    CONSTRAINT line_daily_metrics_qa_check CHECK ((qa_output >= 0))
);


--
-- Name: line_daily_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.line_daily_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: line_daily_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.line_daily_metrics_id_seq OWNED BY public.line_daily_metrics.id;


--
-- Name: line_daily_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.line_daily_plans (
    id integer NOT NULL,
    line_id integer NOT NULL,
    product_id integer NOT NULL,
    work_date date NOT NULL,
    target_units integer DEFAULT 0 NOT NULL,
    created_by integer,
    updated_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    is_locked boolean DEFAULT false NOT NULL
);


--
-- Name: line_daily_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.line_daily_plans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: line_daily_plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.line_daily_plans_id_seq OWNED BY public.line_daily_plans.id;


--
-- Name: line_material_stock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.line_material_stock (
    id integer NOT NULL,
    line_id integer NOT NULL,
    work_date date NOT NULL,
    opening_stock integer DEFAULT 0 NOT NULL,
    total_issued integer DEFAULT 0 NOT NULL,
    total_used integer DEFAULT 0 NOT NULL,
    total_returned integer DEFAULT 0 NOT NULL,
    closing_stock integer DEFAULT 0 NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE line_material_stock; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.line_material_stock IS 'Daily material stock balance per line';


--
-- Name: line_material_stock_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.line_material_stock_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: line_material_stock_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.line_material_stock_id_seq OWNED BY public.line_material_stock.id;


--
-- Name: line_process_hourly_progress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.line_process_hourly_progress (
    id integer NOT NULL,
    line_id integer NOT NULL,
    process_id integer NOT NULL,
    work_date date NOT NULL,
    hour_slot integer NOT NULL,
    quantity integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    employee_id integer,
    forwarded_quantity integer DEFAULT 0 NOT NULL,
    remaining_quantity integer DEFAULT 0 NOT NULL,
    CONSTRAINT line_process_hourly_progress_forwarded_check CHECK ((forwarded_quantity >= 0)),
    CONSTRAINT line_process_hourly_progress_hour_slot_check CHECK (((hour_slot >= 8) AND (hour_slot <= 19))),
    CONSTRAINT line_process_hourly_progress_remaining_check CHECK ((remaining_quantity >= 0))
);


--
-- Name: line_process_hourly_progress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.line_process_hourly_progress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: line_process_hourly_progress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.line_process_hourly_progress_id_seq OWNED BY public.line_process_hourly_progress.id;


--
-- Name: line_shift_closures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.line_shift_closures (
    id integer NOT NULL,
    line_id integer NOT NULL,
    work_date date NOT NULL,
    closed_by integer,
    closed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    notes text
);


--
-- Name: line_shift_closures_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.line_shift_closures_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: line_shift_closures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.line_shift_closures_id_seq OWNED BY public.line_shift_closures.id;


--
-- Name: material_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.material_transactions (
    id integer NOT NULL,
    line_id integer NOT NULL,
    work_date date NOT NULL,
    transaction_type character varying(50) NOT NULL,
    quantity integer NOT NULL,
    from_process_id integer,
    to_process_id integer,
    notes text,
    recorded_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE material_transactions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.material_transactions IS 'Tracks all material movements in the production line';


--
-- Name: material_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.material_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: material_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.material_transactions_id_seq OWNED BY public.material_transactions.id;


--
-- Name: operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.operations (
    id integer NOT NULL,
    operation_code character varying(50) NOT NULL,
    operation_name character varying(200) NOT NULL,
    operation_description text,
    operation_category character varying(100),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by integer,
    updated_by integer,
    qr_code_path character varying(255)
);


--
-- Name: TABLE operations; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.operations IS 'Master list of all manufacturing operations';


--
-- Name: operations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.operations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: operations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.operations_id_seq OWNED BY public.operations.id;


--
-- Name: process_assignment_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.process_assignment_history (
    id integer NOT NULL,
    line_id integer NOT NULL,
    process_id integer NOT NULL,
    employee_id integer NOT NULL,
    start_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    end_time timestamp without time zone,
    quantity_completed integer DEFAULT 0 NOT NULL,
    changed_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    materials_at_link integer DEFAULT 0 NOT NULL,
    existing_materials integer DEFAULT 0 NOT NULL,
    CONSTRAINT process_assignment_history_existing_materials_check CHECK ((existing_materials >= 0)),
    CONSTRAINT process_assignment_history_materials_check CHECK ((materials_at_link >= 0))
);


--
-- Name: process_assignment_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.process_assignment_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: process_assignment_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.process_assignment_history_id_seq OWNED BY public.process_assignment_history.id;


--
-- Name: process_material_wip; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.process_material_wip (
    id integer NOT NULL,
    line_id integer NOT NULL,
    process_id integer NOT NULL,
    work_date date NOT NULL,
    materials_in integer DEFAULT 0 NOT NULL,
    materials_out integer DEFAULT 0 NOT NULL,
    wip_quantity integer DEFAULT 0 NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE process_material_wip; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.process_material_wip IS 'Work-in-progress materials at each process step';


--
-- Name: process_material_wip_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.process_material_wip_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: process_material_wip_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.process_material_wip_id_seq OWNED BY public.process_material_wip.id;


--
-- Name: product_processes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_processes (
    id integer NOT NULL,
    product_id integer NOT NULL,
    operation_id integer NOT NULL,
    sequence_number integer NOT NULL,
    operation_sah numeric(10,4) NOT NULL,
    cycle_time_seconds integer,
    manpower_required integer DEFAULT 1,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by integer,
    updated_by integer,
    qr_code_path character varying(255),
    target_units integer DEFAULT 0 NOT NULL,
    CONSTRAINT chk_sah_positive CHECK ((operation_sah > (0)::numeric)),
    CONSTRAINT chk_sequence_positive CHECK ((sequence_number > 0)),
    CONSTRAINT chk_target_units_nonnegative CHECK ((target_units >= 0))
);


--
-- Name: TABLE product_processes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.product_processes IS 'Product-specific operation sequences with SAH and workspace assignments';


--
-- Name: COLUMN product_processes.sequence_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_processes.sequence_number IS 'Order of operation in the process flow (1, 2, 3, ...)';


--
-- Name: COLUMN product_processes.operation_sah; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_processes.operation_sah IS 'SAH for this specific operation on this product';


--
-- Name: COLUMN product_processes.cycle_time_seconds; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_processes.cycle_time_seconds IS 'Cycle time in seconds';


--
-- Name: product_processes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_processes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_processes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_processes_id_seq OWNED BY public.product_processes.id;


--
-- Name: production_day_locks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.production_day_locks (
    work_date date NOT NULL,
    locked_by integer,
    locked_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    notes text
);


--
-- Name: production_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.production_lines (
    id integer NOT NULL,
    line_code character varying(50) NOT NULL,
    line_name character varying(100) NOT NULL,
    hall_location character varying(50),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by integer,
    updated_by integer,
    current_product_id integer,
    target_units integer DEFAULT 0 NOT NULL,
    efficiency numeric(5,2) DEFAULT 0 NOT NULL,
    qr_code_path character varying(255)
);


--
-- Name: production_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.production_lines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: production_lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.production_lines_id_seq OWNED BY public.production_lines.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id integer NOT NULL,
    product_code character varying(50) NOT NULL,
    product_name character varying(200) NOT NULL,
    product_description text,
    category character varying(100),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by integer,
    updated_by integer,
    line_id integer
);


--
-- Name: TABLE products; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.products IS 'Master table for products/styles manufactured';


--
-- Name: COLUMN products.product_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.products.product_code IS 'Unique product identifier (e.g., CY405)';


--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    full_name character varying(100) NOT NULL,
    role character varying(20) NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['admin'::character varying, 'ie'::character varying, 'supervisor'::character varying])::text[])))
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: v_audit_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_audit_summary AS
 SELECT date(changed_at) AS audit_date,
    table_name,
    action,
    count(*) AS action_count,
    count(DISTINCT changed_by) AS unique_users
   FROM public.audit_logs
  WHERE (changed_at >= (CURRENT_DATE - '30 days'::interval))
  GROUP BY (date(changed_at)), table_name, action
  ORDER BY (date(changed_at)) DESC, table_name, action;


--
-- Name: v_daily_material_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_daily_material_summary AS
 SELECT line_id,
    work_date,
    COALESCE(sum(
        CASE
            WHEN ((transaction_type)::text = 'issued'::text) THEN quantity
            ELSE 0
        END), (0)::bigint) AS total_issued,
    COALESCE(sum(
        CASE
            WHEN ((transaction_type)::text = 'used'::text) THEN quantity
            ELSE 0
        END), (0)::bigint) AS total_used,
    COALESCE(sum(
        CASE
            WHEN ((transaction_type)::text = 'returned'::text) THEN quantity
            ELSE 0
        END), (0)::bigint) AS total_returned,
    COALESCE(sum(
        CASE
            WHEN ((transaction_type)::text = 'forwarded'::text) THEN quantity
            ELSE 0
        END), (0)::bigint) AS total_forwarded,
    COALESCE(sum(
        CASE
            WHEN ((transaction_type)::text = 'received'::text) THEN quantity
            ELSE 0
        END), (0)::bigint) AS total_received
   FROM public.material_transactions
  GROUP BY line_id, work_date;


--
-- Name: v_recent_critical_changes; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_recent_critical_changes AS
 SELECT al.id,
    al.table_name,
    al.record_id,
    al.action,
    al.changed_at,
    al.ip_address,
    u.username AS changed_by_user,
    al.old_values,
    al.new_values,
    al.reason
   FROM (public.audit_logs al
     LEFT JOIN public.users u ON ((al.changed_by = u.id)))
  WHERE (((al.table_name)::text = ANY ((ARRAY['users'::character varying, 'production_lines'::character varying, 'products'::character varying, 'employees'::character varying])::text[])) AND ((al.action)::text = ANY ((ARRAY['delete'::character varying, 'update'::character varying])::text[])) AND (al.changed_at >= (CURRENT_TIMESTAMP - '7 days'::interval)))
  ORDER BY al.changed_at DESC
 LIMIT 100;


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: employee_attendance id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_attendance ALTER COLUMN id SET DEFAULT nextval('public.employee_attendance_id_seq'::regclass);


--
-- Name: employee_process_assignments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_process_assignments ALTER COLUMN id SET DEFAULT nextval('public.employee_process_assignments_id_seq'::regclass);


--
-- Name: employees id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees ALTER COLUMN id SET DEFAULT nextval('public.employees_id_seq'::regclass);


--
-- Name: line_daily_metrics id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_daily_metrics ALTER COLUMN id SET DEFAULT nextval('public.line_daily_metrics_id_seq'::regclass);


--
-- Name: line_daily_plans id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_daily_plans ALTER COLUMN id SET DEFAULT nextval('public.line_daily_plans_id_seq'::regclass);


--
-- Name: line_material_stock id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_material_stock ALTER COLUMN id SET DEFAULT nextval('public.line_material_stock_id_seq'::regclass);


--
-- Name: line_process_hourly_progress id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_process_hourly_progress ALTER COLUMN id SET DEFAULT nextval('public.line_process_hourly_progress_id_seq'::regclass);


--
-- Name: line_shift_closures id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_shift_closures ALTER COLUMN id SET DEFAULT nextval('public.line_shift_closures_id_seq'::regclass);


--
-- Name: material_transactions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_transactions ALTER COLUMN id SET DEFAULT nextval('public.material_transactions_id_seq'::regclass);


--
-- Name: operations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operations ALTER COLUMN id SET DEFAULT nextval('public.operations_id_seq'::regclass);


--
-- Name: process_assignment_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_assignment_history ALTER COLUMN id SET DEFAULT nextval('public.process_assignment_history_id_seq'::regclass);


--
-- Name: process_material_wip id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_material_wip ALTER COLUMN id SET DEFAULT nextval('public.process_material_wip_id_seq'::regclass);


--
-- Name: product_processes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_processes ALTER COLUMN id SET DEFAULT nextval('public.product_processes_id_seq'::regclass);


--
-- Name: production_lines id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_lines ALTER COLUMN id SET DEFAULT nextval('public.production_lines_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app_settings (key, value, updated_at) FROM stdin;
default_in_time	08:00	2026-01-15 20:03:32.287665
default_out_time	17:00	2026-01-15 20:03:32.287665
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, table_name, record_id, action, old_values, new_values, changed_by, changed_at, reason, ip_address, user_agent, session_id, request_path, http_method) FROM stdin;
1	production_day_locks	0	unlock	\N	\N	\N	2026-01-19 18:51:06.700983	\N	\N	\N	\N	\N	\N
2	production_day_locks	0	lock	\N	{"work_date": "2026-01-19"}	\N	2026-01-19 18:51:07.738577	\N	\N	\N	\N	\N	\N
3	production_day_locks	0	unlock	{"notes": null, "locked_at": "2026-01-19T13:21:07.735Z", "locked_by": null, "work_date": "2026-01-18T18:30:00.000Z"}	\N	\N	2026-01-19 18:51:08.595144	\N	\N	\N	\N	\N	\N
4	production_day_locks	0	lock	\N	{"work_date": "2026-01-19"}	\N	2026-01-19 19:10:55.18531	\N	\N	\N	\N	\N	\N
5	production_day_locks	0	unlock	{"notes": null, "locked_at": "2026-01-19T13:40:55.182Z", "locked_by": null, "work_date": "2026-01-18T18:30:00.000Z"}	\N	\N	2026-01-19 19:10:55.831846	\N	\N	\N	\N	\N	\N
6	line_daily_metrics	1	create	\N	{"id": 1, "line_id": 2, "qa_output": 0, "work_date": "2026-01-20T18:30:00.000Z", "updated_at": "2026-01-21T11:07:19.172Z", "updated_by": null, "remaining_wip": 0, "materials_issued": 0, "forwarded_quantity": 0}	\N	2026-01-21 16:37:19.186615	\N	\N	\N	\N	\N	\N
7	line_daily_metrics	1	update	{"id": 1, "line_id": 2, "qa_output": 0, "work_date": "2026-01-20T18:30:00.000Z", "updated_at": "2026-01-21T11:07:19.172Z", "updated_by": null, "remaining_wip": 0, "materials_issued": 0, "forwarded_quantity": 0}	{"id": 1, "line_id": 2, "qa_output": 1, "work_date": "2026-01-20T18:30:00.000Z", "updated_at": "2026-01-21T11:52:49.079Z", "updated_by": null, "remaining_wip": 2, "materials_issued": 2, "forwarded_quantity": 10}	\N	2026-01-21 17:22:49.081887	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: employee_attendance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_attendance (id, employee_id, attendance_date, in_time, out_time, status, notes, created_at, updated_at) FROM stdin;
1	2	2026-01-15	19:17:00	17:00:00	present	Supervisor scan	2026-01-15 19:17:25.090225	2026-01-15 19:17:43.915993
5	69	2026-01-15	19:18:00	17:00:00	present	Supervisor scan	2026-01-15 19:18:30.616213	2026-01-15 19:18:30.616213
6	69	2026-01-21	17:14:00	17:00:00	present	Supervisor scan	2026-01-21 17:14:43.642547	2026-01-21 17:14:43.642547
7	2	2026-01-21	17:20:00	17:00:00	present	Supervisor scan	2026-01-21 17:20:39.886451	2026-01-21 17:42:50.768353
13	2	2026-01-22	18:12:00	17:00:00	present	Supervisor scan	2026-01-22 18:12:21.442881	2026-01-22 18:18:28.963088
\.


--
-- Data for Name: employee_process_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_process_assignments (id, process_id, employee_id, assigned_at, line_id) FROM stdin;
240	77	144	2026-01-15 14:17:49.930071	3
248	6	2	2026-01-21 17:26:47.276909	2
163	77	1	2026-01-15 13:38:23.96625	1
165	7	3	2026-01-15 13:38:30.529735	2
166	8	4	2026-01-15 13:39:30.154719	2
167	9	5	2026-01-15 13:39:31.617343	2
168	10	6	2026-01-15 13:39:33.370279	2
169	11	7	2026-01-15 13:39:35.51379	2
170	12	9	2026-01-15 13:39:39.865374	2
171	13	8	2026-01-15 13:39:42.083569	2
173	14	11	2026-01-15 13:39:46.930149	2
174	15	10	2026-01-15 13:39:48.320966	2
175	16	12	2026-01-15 13:39:49.914512	2
176	17	13	2026-01-15 13:39:51.433232	2
177	18	14	2026-01-15 13:39:53.169544	2
178	19	15	2026-01-15 13:39:55.806912	2
179	20	16	2026-01-15 13:39:57.081813	2
180	21	17	2026-01-15 13:39:58.394292	2
181	22	18	2026-01-15 13:39:59.963183	2
182	23	19	2026-01-15 13:40:01.248901	2
185	24	20	2026-01-15 13:40:05.584784	2
187	25	21	2026-01-15 13:40:08.060883	2
188	26	22	2026-01-15 13:40:09.890208	2
189	27	23	2026-01-15 13:40:11.37747	2
190	28	24	2026-01-15 13:40:13.7303	2
191	29	25	2026-01-15 13:40:15.577528	2
192	30	26	2026-01-15 13:40:18.023101	2
193	31	27	2026-01-15 13:40:19.453374	2
194	32	28	2026-01-15 13:40:20.665068	2
195	33	29	2026-01-15 13:40:22.065827	2
196	34	30	2026-01-15 13:40:26.082791	2
197	35	31	2026-01-15 13:40:27.529421	2
198	36	32	2026-01-15 13:40:29.313358	2
199	37	33	2026-01-15 13:40:31.987128	2
200	38	34	2026-01-15 13:40:33.913239	2
201	39	35	2026-01-15 13:40:35.273751	2
202	40	36	2026-01-15 13:40:36.602593	2
203	41	37	2026-01-15 13:40:37.798827	2
204	42	38	2026-01-15 13:40:39.320909	2
205	43	39	2026-01-15 13:40:40.657208	2
206	44	40	2026-01-15 13:40:49.628646	2
207	45	41	2026-01-15 13:40:51.385288	2
208	46	42	2026-01-15 13:40:53.369432	2
209	47	106	2026-01-15 13:40:54.937788	2
210	48	107	2026-01-15 13:40:56.169218	2
211	49	43	2026-01-15 13:40:57.753334	2
212	50	44	2026-01-15 13:41:00.001063	2
213	51	45	2026-01-15 13:41:02.863768	2
214	52	46	2026-01-15 13:41:06.016245	2
215	53	47	2026-01-15 13:41:09.631818	2
216	54	48	2026-01-15 13:41:11.453831	2
217	55	49	2026-01-15 13:41:12.898036	2
218	56	50	2026-01-15 13:41:15.986052	2
219	57	108	2026-01-15 13:41:18.449738	2
220	58	109	2026-01-15 13:41:20.619563	2
221	59	110	2026-01-15 13:41:22.092783	2
222	60	111	2026-01-15 13:41:24.201446	2
223	61	112	2026-01-15 13:41:26.738302	2
224	62	113	2026-01-15 13:41:29.835744	2
225	63	114	2026-01-15 13:41:32.062413	2
226	64	115	2026-01-15 13:41:33.865993	2
227	65	116	2026-01-15 13:41:35.433314	2
228	66	117	2026-01-15 13:41:37.249491	2
229	67	51	2026-01-15 13:41:39.033259	2
230	68	52	2026-01-15 13:41:41.688247	2
231	69	53	2026-01-15 13:41:43.369239	2
232	70	54	2026-01-15 13:41:54.405603	2
233	71	118	2026-01-15 13:41:56.241208	2
234	72	55	2026-01-15 13:41:58.56986	2
235	73	119	2026-01-15 13:42:00.20832	2
236	74	56	2026-01-15 13:42:01.64186	2
237	75	57	2026-01-15 13:42:05.83455	2
238	76	59	2026-01-15 13:42:09.761262	2
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employees (id, emp_code, emp_name, designation, default_line_id, qr_code_path, is_active, created_at, updated_at, created_by, updated_by, manpower_factor) FROM stdin;
144	LPD9801	ILYAS	NONE	\N	qrcodes/employees/employee_144.png	t	2026-01-15 14:05:29.041393	2026-01-15 14:16:54.785923	\N	\N	1
81	LPD12236	S. UMA	Associate	1	qrcodes/employees/employee_81.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
104	LPDS95742	SUGUNA	Table Worker	1	qrcodes/employees/employee_104.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
119	LPD10281	MD. SHAMIM AHAMAD	Stitcher	2	qrcodes/employees/employee_119.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
136	LPD12254	RABIUL MOLLA	Table Worker	2	qrcodes/employees/employee_136.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
1	LPD00059	A. NOORUN	Lw M/C Optr	1	qrcodes/employees/employee_1.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
2	LPD00334	R. VASANTHI	Stitcher	1	qrcodes/employees/employee_2.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
3	LPD00601	A. SADIKHA	Table Worker	1	qrcodes/employees/employee_3.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
4	LPD01253	G. SARASWATHI	Table Worker	1	qrcodes/employees/employee_4.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
5	LPD02946	A. ALEMELU	Lw M/C Optr	1	qrcodes/employees/employee_5.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
6	LPD03298	G. PADMINI	Table Worker	1	qrcodes/employees/employee_6.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
7	LPD04519	G. MANIMALA	Stitcher	1	qrcodes/employees/employee_7.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
8	LPD04803	S. RAJASHWARI	Table Worker	1	qrcodes/employees/employee_8.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
9	LPD04804	V. MEENATCHI	Table Worker	1	qrcodes/employees/employee_9.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
10	LPD04824	P. LOGANAYAGI	Stitcher	1	qrcodes/employees/employee_10.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
11	LPD05183	R. SRI DEVI	Table Worker	1	qrcodes/employees/employee_11.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
12	LPD05609	M. GOWRI	Table Worker	1	qrcodes/employees/employee_12.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
13	LPD05920	S. PARMESHWARI	Table Worker	1	qrcodes/employees/employee_13.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
14	LPD06518	M. ANITHA	Table Worker	1	qrcodes/employees/employee_14.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
15	LPD07392	V.P. MUBARAK	Lw M/C Optr	1	qrcodes/employees/employee_15.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
16	LPD07459	S. VIJAYA	Edge Inking	1	qrcodes/employees/employee_16.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
17	LPD07479	A. CHANMA	Table Worker	1	qrcodes/employees/employee_17.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
29	LPD08204	P. ANITHA	Edge Inking	1	qrcodes/employees/employee_29.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
46	LPD09683	GIRIJA	Table Worker	1	qrcodes/employees/employee_46.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
64	LPD11181	SALLUBANU	Hw M/C Optr	1	qrcodes/employees/employee_64.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
79	LPD11988	F GULZAR	Edge Inking	1	qrcodes/employees/employee_79.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
20	LPD07590	D. LATHA	Stitcher	1	qrcodes/employees/employee_20.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
21	LPD07628	GNANAMMAL	Edge Inking	1	qrcodes/employees/employee_21.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
22	LPD07785	S. RANI	Table Worker	1	qrcodes/employees/employee_22.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
23	LPD07789	R. KAVITHA	Edge Inking	1	qrcodes/employees/employee_23.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
24	LPD07870	M. NIROSHA	Edge Inking	1	qrcodes/employees/employee_24.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
25	LPD07950	S. RAHIMUNNISA	Lw M/C Optr	1	qrcodes/employees/employee_25.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
26	LPD08048	S. RIYAZ	Hw M/C Optr	1	qrcodes/employees/employee_26.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
27	LPD08118	D. SUREKA	Stitcher	1	qrcodes/employees/employee_27.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
28	LPD08142	M. MUMTAJ	Stitcher	1	qrcodes/employees/employee_28.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
30	LPD08268	VASANTHI	Edge Inking	1	qrcodes/employees/employee_30.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
31	LPD08305	S. SUDHA	Table Worker	1	qrcodes/employees/employee_31.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
32	LPD08346	M. KHADAR BEE	Table Worker	1	qrcodes/employees/employee_32.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
33	LPD08372	JAYANTHI	Edge Inking	1	qrcodes/employees/employee_33.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
34	LPD08441	ESWARI	Hw M/C Optr	1	qrcodes/employees/employee_34.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
35	LPD08486	SASIKALA	Edge Inking	1	qrcodes/employees/employee_35.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
36	LPD08506	AYESHA	Table Worker	1	qrcodes/employees/employee_36.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
37	LPD08523	DEVI	Table Worker	1	qrcodes/employees/employee_37.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
38	LPD08619	SHARFUDDIN	Ams Stitcher	1	qrcodes/employees/employee_38.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
39	LPD08664	ANITHA	Table Worker	1	qrcodes/employees/employee_39.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
40	LPD08685	Z. NAYEEMUNNISA	Stitcher	1	qrcodes/employees/employee_40.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
41	LPD08744	S.L. LAKSHMI	Table Worker	1	qrcodes/employees/employee_41.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
42	LPD08891	UMA MAHESWARI	Table Worker	1	qrcodes/employees/employee_42.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
43	LPD09146	ALAMELU	Edge Inking	1	qrcodes/employees/employee_43.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
44	LPD09393	M. USHA RANI	Table Worker	1	qrcodes/employees/employee_44.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
45	LPD09605	REKHA	Stitcher	1	qrcodes/employees/employee_45.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
47	LPD09689	SARANYA	Stitcher	1	qrcodes/employees/employee_47.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
48	LPD09702	DEVI	Stitcher	1	qrcodes/employees/employee_48.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
49	LPD09907	RIZWAN	Hw M/C Optr	1	qrcodes/employees/employee_49.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
50	LPD09910	JABINA BANU	Ams Stitcher	1	qrcodes/employees/employee_50.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
51	LPD10183	M. KALAIMATHI	Stitcher	1	qrcodes/employees/employee_51.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
52	LPD10197	M. GIRIJA	Stitcher	1	qrcodes/employees/employee_52.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
53	LPD10209	HAJEERA	Stitcher	1	qrcodes/employees/employee_53.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
54	LPD10251	JAYACHITRA	Table Worker	1	qrcodes/employees/employee_54.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
55	LPD10276	PARVEEN	Stitcher	1	qrcodes/employees/employee_55.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
56	LPD10419	A. FARHANA BEGAM	Stitcher	1	qrcodes/employees/employee_56.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
57	LPD10455	THAMRIN	Edge Inking	1	qrcodes/employees/employee_57.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
58	LPD10561	G. SELVARANI	Table Worker	1	qrcodes/employees/employee_58.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
59	LPD10617	ANJALI	Table Worker	1	qrcodes/employees/employee_59.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
60	LPD10916	N. JAYACHITRA	Table Worker	1	qrcodes/employees/employee_60.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
61	LPD10967	K. SHANTHI	Table Worker	1	qrcodes/employees/employee_61.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
62	LPD11088	Y. ALMAS BEGUM	Edge Inking	1	qrcodes/employees/employee_62.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
63	LPD11153	SHAINAN	Edge Inking	1	qrcodes/employees/employee_63.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
65	LPD11183	M. RIZWANA	Ams Stitcher	1	qrcodes/employees/employee_65.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
66	LPD11187	SUJATHA	Edge Inking	1	qrcodes/employees/employee_66.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
67	LPD11204	MAHALAKSHMI	Edge Inking	1	qrcodes/employees/employee_67.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
68	LPD11221	KANIMOZHI	Hw M/C Optr	1	qrcodes/employees/employee_68.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
69	LPD11279	M. ZEHRA	Table Worker	1	qrcodes/employees/employee_69.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
70	LPD11453	A. MUNNI	Stitcher	1	qrcodes/employees/employee_70.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
71	LPD11463	SHINAS	Edge Inking	1	qrcodes/employees/employee_71.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
72	LPD11482	S. MD. SULTAN	Hw M/C Optr	1	qrcodes/employees/employee_72.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
73	LPD11499	I. RESHMA	Table Worker	1	qrcodes/employees/employee_73.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
74	LPD11572	SHALINI	Ams Stitcher	1	qrcodes/employees/employee_74.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
75	LPD11610	JEEVA	Stitcher	1	qrcodes/employees/employee_75.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
76	LPD11677	B. LAKSHMI	Stitcher	1	qrcodes/employees/employee_76.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
77	LPD11712	P. GAYATHRI	Stitcher	1	qrcodes/employees/employee_77.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
78	LPD11959	A MEENAKSHI	Stitcher	1	qrcodes/employees/employee_78.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
80	LPD12022	K KHURSHEED BANU	Stitcher	1	qrcodes/employees/employee_80.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
18	LPD07485	R. VENNILA	Edge Inking	1	qrcodes/employees/employee_18.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
19	LPD07514	V. DHANALAKSHMI	Table Worker	1	qrcodes/employees/employee_19.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
84	LPD12239	U. SHYLAJA	Stitcher	1	qrcodes/employees/employee_84.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
85	LPD12240	M. HAJIRA	Stitcher	1	qrcodes/employees/employee_85.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
86	LPDS93008	B LATHA	Table Worker	1	qrcodes/employees/employee_86.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
87	LPDS93009	BAVANI	Table Worker	1	qrcodes/employees/employee_87.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
88	LPDS94717	AKMAL A	Hw M/C Optr	1	qrcodes/employees/employee_88.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
89	LPDS94756	UMA C	Table Worker	1	qrcodes/employees/employee_89.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
90	LPDS95161	FOUSIYA	Ams Stitcher	1	qrcodes/employees/employee_90.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
91	LPDS95252	P VENDA	Ams Stitcher	1	qrcodes/employees/employee_91.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
92	LPDS95527	REVATHI R	Table Worker	1	qrcodes/employees/employee_92.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
93	LPDS95657	A JOTHI	Ams Stitcher	1	qrcodes/employees/employee_93.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
94	LPDS95681	J KAVERI	Table Worker	1	qrcodes/employees/employee_94.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
95	LPDS95684	SELVI VENGATESAN	Table Worker	1	qrcodes/employees/employee_95.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
96	LPDS95689	S DIVYA PRABA	Stitcher	1	qrcodes/employees/employee_96.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
97	LPDS95702	M DILSHATH	Stitcher	1	qrcodes/employees/employee_97.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
98	LPDS95714	KAVITHA SURESH	Table Worker	1	qrcodes/employees/employee_98.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
99	LPDS95725	LAKSHMI JANAGIRAMAN	Table Worker	1	qrcodes/employees/employee_99.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
100	LPDS95728	CHANDHINI NASEER	Table Worker	1	qrcodes/employees/employee_100.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
101	LPDS95729	S MUNNI	Table Worker	1	qrcodes/employees/employee_101.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
102	LPDS95740	R. AMUDHA	Edge Inking	1	qrcodes/employees/employee_102.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
103	LPDS95741	N. SUMITHRA	Table Worker	1	qrcodes/employees/employee_103.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
105	LPDS95743	C. THILAGAWATHI	Table Worker	1	qrcodes/employees/employee_105.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
106	LPD08988	K. DEEPA	Associate	2	qrcodes/employees/employee_106.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
107	LPD09007	K. FAIYAZ	Hw M/C Optr	2	qrcodes/employees/employee_107.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
108	LPD09944	PARVEEN	Table Worker	2	qrcodes/employees/employee_108.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
109	LPD09951	B. SHAHEEN	Lw M/C Optr	2	qrcodes/employees/employee_109.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
110	LPD09954	SHOBANA	Table Worker	2	qrcodes/employees/employee_110.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
111	LPD09963	R. AMBIKA	Edge Inking	2	qrcodes/employees/employee_111.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
112	LPD09973	S. SIVARANJANI	Table Worker	2	qrcodes/employees/employee_112.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
113	LPD09981	K. ESWARI	Table Worker	2	qrcodes/employees/employee_113.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
114	LPD09996	A. YASEEN BEE	Edge Inking	2	qrcodes/employees/employee_114.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
115	LPD10035	REVATHI	Edge Inking	2	qrcodes/employees/employee_115.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
116	LPD10044	SHAKIRA	Table Worker	2	qrcodes/employees/employee_116.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
117	LPD10099	AMMU	Table Worker	2	qrcodes/employees/employee_117.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
118	LPD10255	MUGINA	Stitcher	2	qrcodes/employees/employee_118.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
120	LPD10701	BADRUNNISA	Table Worker	2	qrcodes/employees/employee_120.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
121	LPD11278	MD. INTAKHAB	Table Worker	2	qrcodes/employees/employee_121.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
122	LPD11358	SUMATHI	Table Worker	2	qrcodes/employees/employee_122.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
123	LPD11365	B. AMUDHA	Table Worker	2	qrcodes/employees/employee_123.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
124	LPD11504	S. SUGUNA	Ams Stitcher	2	qrcodes/employees/employee_124.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
125	LPD11567	SUMATHI	Hw M/C Optr	2	qrcodes/employees/employee_125.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
126	LPD11618	MD. NASIM	Stitcher	2	qrcodes/employees/employee_126.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
127	LPD11692	POORNIMA VIMAL	Stitcher	2	qrcodes/employees/employee_127.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
128	LPD11937	KHURSID ALI MOLLA	Table Worker	2	qrcodes/employees/employee_128.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
129	LPD11973	SHAJAN R	Stitcher	2	qrcodes/employees/employee_129.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
130	LPD12099	S AMUDHA	Table Worker	2	qrcodes/employees/employee_130.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
131	LPD12221	MD YAMIN ALI MOLLA	Table Worker	2	qrcodes/employees/employee_131.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
132	LPD12233	I RESHMA	Stitcher	2	qrcodes/employees/employee_132.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
133	LPD12243	VASIM AKARAM	Table Worker	2	qrcodes/employees/employee_133.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
134	LPD12247	MARUF HOSSAIN PIYADA	Stitcher	2	qrcodes/employees/employee_134.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
135	LPD12248	MAFIJUL MOLLA	Stitcher	2	qrcodes/employees/employee_135.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
137	LPDS94644	RAVICHITRA	Edge Inking	2	qrcodes/employees/employee_137.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
138	LPDS94648	JAYANTHI	Table Worker	2	qrcodes/employees/employee_138.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
139	LPDS95359	MOHAMMED ZAIBAS M	Lw M/C Optr	2	qrcodes/employees/employee_139.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
140	LPDS95749	HAJIMA MABOOB BASHA	Stitcher	2	qrcodes/employees/employee_140.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
141	LPDS95753	S THABASSUM	Edge Inking	2	qrcodes/employees/employee_141.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
142	LPDS95763	ABDUL VAJEETH J	Ams Stitcher	2	qrcodes/employees/employee_142.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
82	LPD12237	SALIYA BANU	Table Worker	1	qrcodes/employees/employee_82.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
83	LPD12238	MEENA S	Stitcher	1	qrcodes/employees/employee_83.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
\.


--
-- Data for Name: line_daily_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.line_daily_metrics (id, line_id, work_date, forwarded_quantity, remaining_wip, materials_issued, updated_by, updated_at, qa_output) FROM stdin;
1	2	2026-01-21	10	2	2	\N	2026-01-21 17:22:49.079668	1
\.


--
-- Data for Name: line_daily_plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.line_daily_plans (id, line_id, product_id, work_date, target_units, created_by, updated_by, created_at, updated_at, is_locked) FROM stdin;
\.


--
-- Data for Name: line_material_stock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.line_material_stock (id, line_id, work_date, opening_stock, total_issued, total_used, total_returned, closing_stock, updated_at) FROM stdin;
\.


--
-- Data for Name: line_process_hourly_progress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.line_process_hourly_progress (id, line_id, process_id, work_date, hour_slot, quantity, created_at, updated_at, employee_id, forwarded_quantity, remaining_quantity) FROM stdin;
4	3	77	2026-01-15	19	0	2026-01-15 19:24:45.325648	2026-01-15 19:24:45.325648	144	0	0
2	2	7	2026-01-15	19	1	2026-01-15 19:19:57.690835	2026-01-15 19:19:57.690835	3	0	0
3	2	8	2026-01-15	19	4	2026-01-15 19:20:00.121084	2026-01-15 19:20:00.121084	4	0	0
6	2	6	2026-01-15	18	8	2026-01-15 19:42:04.213955	2026-01-15 19:42:04.213955	69	0	0
1	2	6	2026-01-15	19	2	2026-01-15 19:19:54.708341	2026-01-15 19:56:18.025951	69	0	0
9	2	6	2026-01-15	16	2	2026-01-15 19:56:50.230825	2026-01-15 19:56:50.230825	69	0	0
10	2	6	2026-01-21	17	5	2026-01-21 17:22:27.378981	2026-01-21 17:43:11.40378	2	3	2
12	2	6	2026-01-22	18	20	2026-01-22 18:12:54.871981	2026-01-22 18:43:04.067779	2	10	10
\.


--
-- Data for Name: line_shift_closures; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.line_shift_closures (id, line_id, work_date, closed_by, closed_at, notes) FROM stdin;
\.


--
-- Data for Name: material_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.material_transactions (id, line_id, work_date, transaction_type, quantity, from_process_id, to_process_id, notes, recorded_by, created_at) FROM stdin;
1	2	2026-01-22	issued	100	\N	6	Initial materials at link	\N	2026-01-22 18:12:21.413627
3	2	2026-01-22	issued	100	\N	6	Initial materials at link	\N	2026-01-22 18:18:28.9572
5	2	2026-01-22	forwarded	10	6	7	Hourly progress 18	\N	2026-01-22 18:43:04.074374
\.


--
-- Data for Name: operations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.operations (id, operation_code, operation_name, operation_description, operation_category, is_active, created_at, updated_at, created_by, updated_by, qr_code_path) FROM stdin;
2	OP_002	1st patti  & step patt with  nonwoon  pasting & att	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_2.png
3	OP_003	stamp & step patti pasting & atttatching	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_3.png
5	OP_005	beeding & cc pkt attatching	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_5.png
6	OP_006	1st patti  & step patti with ams'lining close  side stitiching	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_6.png
7	OP_007	cc pkt with side stitching	\N	STITCHING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_7.png
9	OP_009	cc pkt recutting process	\N	CUTTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_9.png
10	OP_010	Gusset leather with recutting process	\N	CUTTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_10.png
11	OP_011	Gusset  pvc  with recutting process	\N	CUTTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_11.png
13	OP_013	Gusset leather bit recutting process	\N	CUTTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_13.png
14	OP_014	logo bit insert & lock	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_14.png
16	OP_016	Gusset leather with nonwoon pasting & attatching	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_16.png
17	OP_017	kimlon leather with pasting & attatching	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_17.png
18	OP_018	leather bit pasting attatching	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_18.png
20	OP_020	Gusset with nonwoon pasting	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_20.png
21	OP_021	Gusset pvc & nonwoon attatching	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_21.png
23	OP_023	Gusset  leather with  creasing loop bit	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_23.png
24	OP_024	Gusset leather with embossing process	\N	EMBOSSING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_24.png
26	OP_026	Gusset  leather  1st primer	\N	PRIMER	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_26.png
27	OP_027	Gusset leather  die process	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_27.png
29	OP_029	Gusset  pvc with 1st primer	\N	PRIMER	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_29.png
30	OP_030	Gusset  pvc  with die process	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_30.png
32	OP_032	interial case  with primer process	\N	PRIMER	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_32.png
33	OP_033	interial case  with  die  process	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_33.png
34	OP_034	interial  case  sulpa with die	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_34.png
36	OP_036	gusset pvc stitching  area thread  pull	\N	STITCHING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_36.png
37	OP_037	gusset pvc side stitching	\N	STITCHING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_37.png
38	OP_038	interial case  lable side stitching	\N	STITCHING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_38.png
40	OP_040	interial case side edges pasting	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_40.png
41	OP_041	interial case mold used edge folding	\N	EDGE_INKING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_41.png
43	OP_043	interial case mold used edge folding	\N	EDGE_INKING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_43.png
44	OP_044	interial case front & back side seam stitching	\N	STITCHING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_44.png
46	OP_046	Gusset leather with D-ring & zipper AMS stitching	\N	STITCHING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_46.png
47	OP_047	Gusset leather with D-ring & zipper opposite AMS stitching	\N	STITCHING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_47.png
48	OP_048	first patti & window side edges pasting	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_48.png
50	OP_050	gusset leather zipper  with side edges pasting	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_50.png
51	OP_051	zipper stitching area thread full & kimlon pasting	\N	STITCHING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_51.png
52	OP_052	kimlon & zipper mold used attatching	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_52.png
54	OP_054	kimlon & zipper mold used folding	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_54.png
55	OP_055	interial case  with cc pkt pasting & attatching	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_55.png
57	OP_057	interial case with pasting & attatching& thread pull operation	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_57.png
58	OP_058	interial case with window pkt pasting	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_58.png
59	OP_059	interial case with window pkt mold used attatching	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_59.png
61	OP_061	interial case with cc pkt  window stitching	\N	STITCHING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_61.png
62	OP_062	final case stage mold used pressing	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_62.png
63	OP_063	interial case with final case pasting &  Shape process	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_63.png
65	OP_065	interial case with final case Attatching	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_65.png
66	OP_066	final stage window side stitching	\N	STITCHING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_66.png
67	OP_067	final stage straight  stitching	\N	STITCHING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_67.png
69	OP_069	shapping process	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_69.png
70	OP_070	cleaning process	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_70.png
1	OP_001	E.I PROCESS    ( STEP & STAMP PKT), (WINDOW PKT), (CC PKT) , \n( STAMP PATTI )	\N	EDGE_INKING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_1.png
4	OP_004	cc pkt with cover lining pasting & attatching	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_4.png
8	OP_008	1st patti & stamp patti stitching	\N	STITCHING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_8.png
12	OP_012	Gusset kimlon recuting process	\N	CUTTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_12.png
15	OP_015	logo grinding process with tape attatching	\N	GRINDING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_15.png
19	OP_019	Gusset pvc pasting	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_19.png
22	OP_022	Gusset  leather with shape creasing	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_22.png
25	OP_025	Gusset leather heating process	\N	HEATING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_25.png
28	OP_028	Gusset pvc heating process	\N	HEATING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_28.png
31	OP_031	interial case heating process	\N	HEATING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_31.png
35	OP_035	interial case embossing side lable pasting & attatching	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_35.png
39	OP_039	interial case front & back side seam stitching	\N	STITCHING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_39.png
42	OP_042	interial case side edges pasting	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_42.png
45	OP_045	Gusset leather with D-ring pasting & attatching	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_45.png
49	OP_049	first patti  with cc pkt & window attatching	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_49.png
53	OP_053	kimlon & zipper mold used folding	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_53.png
56	OP_056	interial case  with cc pkt  step patti stitching	\N	STITCHING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_56.png
60	OP_060	interial case with cc pkt stamp side stitching	\N	STITCHING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_60.png
64	OP_064	interial case with final case Attatching	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_64.png
68	OP_068	final lamping	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_68.png
71	OP_071	Quality Analysys	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	qrcodes/operations/operation_71.png
\.


--
-- Data for Name: process_assignment_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.process_assignment_history (id, line_id, process_id, employee_id, start_time, end_time, quantity_completed, changed_by, created_at, materials_at_link, existing_materials) FROM stdin;
\.


--
-- Data for Name: process_material_wip; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.process_material_wip (id, line_id, process_id, work_date, materials_in, materials_out, wip_quantity, updated_at) FROM stdin;
1	2	6	2026-01-22	200	10	190	2026-01-22 18:43:04.078958
3	2	7	2026-01-22	10	0	10	2026-01-22 18:43:04.081912
\.


--
-- Data for Name: product_processes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_processes (id, product_id, operation_id, sequence_number, operation_sah, cycle_time_seconds, manpower_required, is_active, created_at, updated_at, created_by, updated_by, qr_code_path, target_units) FROM stdin;
8	1	3	3	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_8.png	0
9	1	4	4	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_9.png	0
7	1	2	2	0.0178	64	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_7.png	0
10	1	5	5	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_10.png	0
11	1	6	6	0.0069	25	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_11.png	0
12	1	7	7	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_12.png	0
13	1	8	8	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_13.png	0
14	1	9	9	0.0222	80	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_14.png	0
15	1	10	10	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_15.png	0
16	1	11	11	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_16.png	0
17	1	12	12	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_17.png	0
18	1	13	13	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_18.png	0
19	1	14	14	0.0181	65	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_19.png	0
20	1	15	15	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_20.png	0
21	1	16	16	0.0281	101	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_21.png	0
22	1	17	17	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_22.png	0
23	1	18	18	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_23.png	0
24	1	19	19	0.0111	40	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_24.png	0
25	1	20	20	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_25.png	0
26	1	21	21	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_26.png	0
27	1	22	22	0.0183	66	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_27.png	0
28	1	23	23	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_28.png	0
29	1	24	24	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_29.png	0
30	1	25	25	0.0508	183	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_30.png	0
31	1	26	26	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_31.png	0
32	1	27	27	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_32.png	0
33	1	28	28	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_33.png	0
34	1	29	29	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_34.png	0
35	1	30	30	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_35.png	0
36	1	31	31	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_36.png	0
37	1	32	32	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_37.png	0
38	1	33	33	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_38.png	0
40	1	35	35	0.0189	68	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_40.png	0
41	1	36	36	0.0072	26	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_41.png	0
43	1	38	38	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_43.png	0
44	1	44	39	0.0164	59	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_44.png	0
46	1	43	41	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_46.png	0
47	1	42	42	0.0419	151	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_47.png	0
49	1	44	44	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_49.png	0
50	1	45	45	0.0114	41	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_50.png	0
52	1	47	47	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_52.png	0
53	1	48	48	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_53.png	0
55	1	50	50	0.0269	97	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_55.png	0
56	1	51	51	0.0136	49	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_56.png	0
58	1	54	53	0.0422	152	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_58.png	0
59	1	54	54	0.0419	151	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_59.png	0
61	1	56	56	0.0094	34	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_61.png	0
62	1	57	57	0.0258	93	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_62.png	0
64	1	59	59	0.0336	121	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_64.png	0
65	1	60	60	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_65.png	0
67	1	62	62	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_67.png	0
68	1	63	63	0.0197	71	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_68.png	0
70	1	65	65	0.0297	107	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_70.png	0
71	1	66	66	0.0306	110	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_71.png	0
73	1	68	68	0.0211	76	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_73.png	0
74	1	69	69	0.0281	101	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_74.png	0
76	1	71	71	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_76.png	0
77	2	1	1	0.0122	44	1	t	2026-01-15 10:57:12.368428	2026-01-15 10:57:12.368428	\N	\N	qrcodes/processes/process_77.png	0
39	1	34	34	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_39.png	0
42	1	37	37	0.0222	80	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_42.png	0
45	1	42	40	0.0419	151	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_45.png	0
48	1	43	43	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_48.png	0
51	1	46	46	0.0203	73	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_51.png	0
54	1	49	49	0.0236	85	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_54.png	0
57	1	52	52	0.0244	88	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_57.png	0
60	1	55	55	0.0283	102	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_60.png	0
63	1	58	58	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_63.png	0
66	1	61	61	0.0336	121	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_66.png	0
69	1	65	64	0.0286	103	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_69.png	0
72	1	67	67	0.0306	110	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_72.png	0
75	1	70	70	0.0306	110	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	qrcodes/processes/process_75.png	0
6	1	1	1	0.0278	100	1	t	2026-01-15 10:27:14.50459	2026-01-15 19:40:06.736196	\N	\N	qrcodes/processes/process_6.png	10
\.


--
-- Data for Name: production_day_locks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.production_day_locks (work_date, locked_by, locked_at, notes) FROM stdin;
\.


--
-- Data for Name: production_lines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.production_lines (id, line_code, line_name, hall_location, is_active, created_at, updated_at, created_by, updated_by, current_product_id, target_units, efficiency, qr_code_path) FROM stdin;
1	RUMIYA_LINE	HALL B RUMIYA LINE	Hall B	t	2026-01-14 15:08:26.291686	2026-01-14 15:08:26.291686	\N	\N	2	0	0.00	qrcodes/lines/line_1.png
2	GAFOOR_LINE	HALL A GAFOOR LINE	Hall A	t	2026-01-14 15:08:26.291686	2026-01-14 15:08:26.291686	\N	\N	1	0	0.00	qrcodes/lines/line_2.png
3	TEST1	TEST_LINE	HALL A	t	2026-01-15 11:36:48.231643	2026-01-15 11:36:48.231643	\N	\N	2	100	0.00	qrcodes/lines/line_3.png
4	TEST2	TEST_LINE2	HALL A	f	2026-01-15 12:54:55.768573	2026-01-15 12:54:55.768573	\N	\N	\N	0	0.00	qrcodes/lines/line_4.png
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, product_code, product_name, product_description, category, is_active, created_at, updated_at, created_by, updated_by, line_id) FROM stdin;
1	CY405	ACCORDION WALLET		WALLET	t	2026-01-14 15:39:14.422357	2026-01-15 11:37:30.280252	\N	\N	2
2	AB1234	TEST 1		wallet	t	2026-01-15 10:56:31.929644	2026-01-15 11:40:58.632325	\N	\N	1
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, full_name, role, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 7, true);


--
-- Name: employee_attendance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_attendance_id_seq', 14, true);


--
-- Name: employee_process_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_process_assignments_id_seq', 248, true);


--
-- Name: employees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employees_id_seq', 144, true);


--
-- Name: line_daily_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.line_daily_metrics_id_seq', 2, true);


--
-- Name: line_daily_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.line_daily_plans_id_seq', 1, false);


--
-- Name: line_material_stock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.line_material_stock_id_seq', 1, false);


--
-- Name: line_process_hourly_progress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.line_process_hourly_progress_id_seq', 14, true);


--
-- Name: line_shift_closures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.line_shift_closures_id_seq', 1, false);


--
-- Name: material_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.material_transactions_id_seq', 5, true);


--
-- Name: operations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.operations_id_seq', 71, true);


--
-- Name: process_assignment_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.process_assignment_history_id_seq', 1, false);


--
-- Name: process_material_wip_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.process_material_wip_id_seq', 8, true);


--
-- Name: product_processes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_processes_id_seq', 77, true);


--
-- Name: production_lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.production_lines_id_seq', 4, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.products_id_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: app_settings app_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_pkey PRIMARY KEY (key);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: employee_attendance employee_attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_attendance
    ADD CONSTRAINT employee_attendance_pkey PRIMARY KEY (id);


--
-- Name: employee_process_assignments employee_process_assignments_employee_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_process_assignments
    ADD CONSTRAINT employee_process_assignments_employee_id_key UNIQUE (employee_id);


--
-- Name: employee_process_assignments employee_process_assignments_line_process_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_process_assignments
    ADD CONSTRAINT employee_process_assignments_line_process_key UNIQUE (line_id, process_id);


--
-- Name: employee_process_assignments employee_process_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_process_assignments
    ADD CONSTRAINT employee_process_assignments_pkey PRIMARY KEY (id);


--
-- Name: employees employees_emp_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_emp_code_key UNIQUE (emp_code);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: line_daily_metrics line_daily_metrics_line_id_work_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_daily_metrics
    ADD CONSTRAINT line_daily_metrics_line_id_work_date_key UNIQUE (line_id, work_date);


--
-- Name: line_daily_metrics line_daily_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_daily_metrics
    ADD CONSTRAINT line_daily_metrics_pkey PRIMARY KEY (id);


--
-- Name: line_daily_plans line_daily_plans_line_id_work_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_daily_plans
    ADD CONSTRAINT line_daily_plans_line_id_work_date_key UNIQUE (line_id, work_date);


--
-- Name: line_daily_plans line_daily_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_daily_plans
    ADD CONSTRAINT line_daily_plans_pkey PRIMARY KEY (id);


--
-- Name: line_material_stock line_material_stock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_material_stock
    ADD CONSTRAINT line_material_stock_pkey PRIMARY KEY (id);


--
-- Name: line_process_hourly_progress line_process_hourly_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_process_hourly_progress
    ADD CONSTRAINT line_process_hourly_progress_pkey PRIMARY KEY (id);


--
-- Name: line_shift_closures line_shift_closures_line_id_work_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_shift_closures
    ADD CONSTRAINT line_shift_closures_line_id_work_date_key UNIQUE (line_id, work_date);


--
-- Name: line_shift_closures line_shift_closures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_shift_closures
    ADD CONSTRAINT line_shift_closures_pkey PRIMARY KEY (id);


--
-- Name: material_transactions material_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_transactions
    ADD CONSTRAINT material_transactions_pkey PRIMARY KEY (id);


--
-- Name: operations operations_operation_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operations
    ADD CONSTRAINT operations_operation_code_key UNIQUE (operation_code);


--
-- Name: operations operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operations
    ADD CONSTRAINT operations_pkey PRIMARY KEY (id);


--
-- Name: process_assignment_history process_assignment_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_assignment_history
    ADD CONSTRAINT process_assignment_history_pkey PRIMARY KEY (id);


--
-- Name: process_material_wip process_material_wip_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_material_wip
    ADD CONSTRAINT process_material_wip_pkey PRIMARY KEY (id);


--
-- Name: product_processes product_processes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_processes
    ADD CONSTRAINT product_processes_pkey PRIMARY KEY (id);


--
-- Name: production_day_locks production_day_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_day_locks
    ADD CONSTRAINT production_day_locks_pkey PRIMARY KEY (work_date);


--
-- Name: production_lines production_lines_line_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_lines
    ADD CONSTRAINT production_lines_line_code_key UNIQUE (line_code);


--
-- Name: production_lines production_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_lines
    ADD CONSTRAINT production_lines_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: products products_product_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_product_code_key UNIQUE (product_code);


--
-- Name: employee_attendance uq_employee_attendance; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_attendance
    ADD CONSTRAINT uq_employee_attendance UNIQUE (employee_id, attendance_date);


--
-- Name: line_material_stock uq_line_material_stock; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_material_stock
    ADD CONSTRAINT uq_line_material_stock UNIQUE (line_id, work_date);


--
-- Name: line_process_hourly_progress uq_line_process_hour; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_process_hourly_progress
    ADD CONSTRAINT uq_line_process_hour UNIQUE (line_id, process_id, work_date, hour_slot);


--
-- Name: process_material_wip uq_process_material_wip; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_material_wip
    ADD CONSTRAINT uq_process_material_wip UNIQUE (line_id, process_id, work_date);


--
-- Name: product_processes uq_product_sequence; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_processes
    ADD CONSTRAINT uq_product_sequence UNIQUE (product_id, sequence_number);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_assignment_history_employee; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_assignment_history_employee ON public.process_assignment_history USING btree (employee_id);


--
-- Name: idx_assignment_history_line_process; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_assignment_history_line_process ON public.process_assignment_history USING btree (line_id, process_id);


--
-- Name: idx_assignment_history_open; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_assignment_history_open ON public.process_assignment_history USING btree (line_id, process_id) WHERE (end_time IS NULL);


--
-- Name: idx_assignment_history_start_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_assignment_history_start_time ON public.process_assignment_history USING btree (start_time);


--
-- Name: idx_attendance_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attendance_date ON public.employee_attendance USING btree (attendance_date);


--
-- Name: idx_attendance_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attendance_status ON public.employee_attendance USING btree (status);


--
-- Name: idx_audit_logs_changed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_changed_at ON public.audit_logs USING btree (changed_at);


--
-- Name: idx_audit_logs_ip; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_ip ON public.audit_logs USING btree (ip_address) WHERE (ip_address IS NOT NULL);


--
-- Name: idx_audit_logs_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_session ON public.audit_logs USING btree (session_id) WHERE (session_id IS NOT NULL);


--
-- Name: idx_audit_logs_table; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_table ON public.audit_logs USING btree (table_name);


--
-- Name: idx_audit_logs_table_record; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_table_record ON public.audit_logs USING btree (table_name, record_id);


--
-- Name: idx_audit_logs_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_user ON public.audit_logs USING btree (changed_by);


--
-- Name: idx_day_locks_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_day_locks_date ON public.production_day_locks USING btree (work_date);


--
-- Name: idx_employees_emp_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employees_emp_code ON public.employees USING btree (emp_code);


--
-- Name: idx_employees_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employees_is_active ON public.employees USING btree (is_active);


--
-- Name: idx_employees_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employees_line_id ON public.employees USING btree (default_line_id);


--
-- Name: idx_hourly_progress_employee; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hourly_progress_employee ON public.line_process_hourly_progress USING btree (employee_id) WHERE (employee_id IS NOT NULL);


--
-- Name: idx_hourly_progress_line_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hourly_progress_line_date ON public.line_process_hourly_progress USING btree (line_id, work_date);


--
-- Name: idx_hourly_progress_work_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hourly_progress_work_date ON public.line_process_hourly_progress USING btree (work_date);


--
-- Name: idx_line_daily_metrics_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_line_daily_metrics_date ON public.line_daily_metrics USING btree (work_date);


--
-- Name: idx_line_daily_metrics_line_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_line_daily_metrics_line_date ON public.line_daily_metrics USING btree (line_id, work_date);


--
-- Name: idx_line_daily_plans_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_line_daily_plans_date ON public.line_daily_plans USING btree (work_date);


--
-- Name: idx_line_daily_plans_line; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_line_daily_plans_line ON public.line_daily_plans USING btree (line_id);


--
-- Name: idx_line_daily_plans_product_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_line_daily_plans_product_date ON public.line_daily_plans USING btree (product_id, work_date);


--
-- Name: idx_line_material_stock_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_line_material_stock_date ON public.line_material_stock USING btree (work_date);


--
-- Name: idx_material_transactions_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_material_transactions_date ON public.material_transactions USING btree (work_date);


--
-- Name: idx_material_transactions_line; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_material_transactions_line ON public.material_transactions USING btree (line_id);


--
-- Name: idx_material_transactions_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_material_transactions_type ON public.material_transactions USING btree (transaction_type);


--
-- Name: idx_material_tx_line_date_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_material_tx_line_date_type ON public.material_transactions USING btree (line_id, work_date, transaction_type);


--
-- Name: idx_operations_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_operations_active ON public.operations USING btree (is_active);


--
-- Name: idx_operations_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_operations_category ON public.operations USING btree (operation_category);


--
-- Name: idx_operations_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_operations_code ON public.operations USING btree (operation_code);


--
-- Name: idx_process_material_wip_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_process_material_wip_date ON public.process_material_wip USING btree (work_date);


--
-- Name: idx_process_material_wip_line; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_process_material_wip_line ON public.process_material_wip USING btree (line_id);


--
-- Name: idx_process_wip_line_process_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_process_wip_line_process_date ON public.process_material_wip USING btree (line_id, process_id, work_date);


--
-- Name: idx_product_processes_operation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_product_processes_operation ON public.product_processes USING btree (operation_id);


--
-- Name: idx_product_processes_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_product_processes_product ON public.product_processes USING btree (product_id);


--
-- Name: idx_product_processes_sequence; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_product_processes_sequence ON public.product_processes USING btree (product_id, sequence_number);


--
-- Name: idx_products_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_active ON public.products USING btree (is_active);


--
-- Name: idx_products_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_code ON public.products USING btree (product_code);


--
-- Name: idx_shift_closures_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_shift_closures_date ON public.line_shift_closures USING btree (work_date);


--
-- Name: material_transactions material_transaction_notify; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER material_transaction_notify AFTER INSERT OR UPDATE ON public.material_transactions FOR EACH ROW EXECUTE FUNCTION public.log_material_transaction();


--
-- Name: employee_process_assignments notify_employee_process_assignments; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER notify_employee_process_assignments AFTER INSERT OR DELETE OR UPDATE ON public.employee_process_assignments FOR EACH ROW EXECUTE FUNCTION public.notify_data_change();


--
-- Name: employees notify_employees; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER notify_employees AFTER INSERT OR DELETE OR UPDATE ON public.employees FOR EACH ROW EXECUTE FUNCTION public.notify_data_change();


--
-- Name: operations notify_operations; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER notify_operations AFTER INSERT OR DELETE OR UPDATE ON public.operations FOR EACH ROW EXECUTE FUNCTION public.notify_data_change();


--
-- Name: product_processes notify_product_processes; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER notify_product_processes AFTER INSERT OR DELETE OR UPDATE ON public.product_processes FOR EACH ROW EXECUTE FUNCTION public.notify_data_change();


--
-- Name: production_lines notify_production_lines; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER notify_production_lines AFTER INSERT OR DELETE OR UPDATE ON public.production_lines FOR EACH ROW EXECUTE FUNCTION public.notify_data_change();


--
-- Name: products notify_products; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER notify_products AFTER INSERT OR DELETE OR UPDATE ON public.products FOR EACH ROW EXECUTE FUNCTION public.notify_data_change();


--
-- Name: employee_attendance employee_attendance_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_attendance
    ADD CONSTRAINT employee_attendance_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: employee_process_assignments employee_process_assignments_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_process_assignments
    ADD CONSTRAINT employee_process_assignments_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: employee_process_assignments employee_process_assignments_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_process_assignments
    ADD CONSTRAINT employee_process_assignments_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.production_lines(id) ON DELETE SET NULL;


--
-- Name: employee_process_assignments employee_process_assignments_process_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_process_assignments
    ADD CONSTRAINT employee_process_assignments_process_id_fkey FOREIGN KEY (process_id) REFERENCES public.product_processes(id) ON DELETE CASCADE;


--
-- Name: employees employees_default_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_default_line_id_fkey FOREIGN KEY (default_line_id) REFERENCES public.production_lines(id);


--
-- Name: production_lines fk_lines_current_product; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_lines
    ADD CONSTRAINT fk_lines_current_product FOREIGN KEY (current_product_id) REFERENCES public.products(id);


--
-- Name: products fk_products_line; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT fk_products_line FOREIGN KEY (line_id) REFERENCES public.production_lines(id);


--
-- Name: line_daily_metrics line_daily_metrics_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_daily_metrics
    ADD CONSTRAINT line_daily_metrics_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.production_lines(id) ON DELETE CASCADE;


--
-- Name: line_daily_metrics line_daily_metrics_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_daily_metrics
    ADD CONSTRAINT line_daily_metrics_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: line_daily_plans line_daily_plans_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_daily_plans
    ADD CONSTRAINT line_daily_plans_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: line_daily_plans line_daily_plans_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_daily_plans
    ADD CONSTRAINT line_daily_plans_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.production_lines(id) ON DELETE CASCADE;


--
-- Name: line_daily_plans line_daily_plans_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_daily_plans
    ADD CONSTRAINT line_daily_plans_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE RESTRICT;


--
-- Name: line_daily_plans line_daily_plans_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_daily_plans
    ADD CONSTRAINT line_daily_plans_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: line_material_stock line_material_stock_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_material_stock
    ADD CONSTRAINT line_material_stock_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.production_lines(id) ON DELETE CASCADE;


--
-- Name: line_process_hourly_progress line_process_hourly_progress_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_process_hourly_progress
    ADD CONSTRAINT line_process_hourly_progress_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE SET NULL;


--
-- Name: line_process_hourly_progress line_process_hourly_progress_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_process_hourly_progress
    ADD CONSTRAINT line_process_hourly_progress_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.production_lines(id) ON DELETE CASCADE;


--
-- Name: line_process_hourly_progress line_process_hourly_progress_process_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_process_hourly_progress
    ADD CONSTRAINT line_process_hourly_progress_process_id_fkey FOREIGN KEY (process_id) REFERENCES public.product_processes(id) ON DELETE CASCADE;


--
-- Name: line_shift_closures line_shift_closures_closed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_shift_closures
    ADD CONSTRAINT line_shift_closures_closed_by_fkey FOREIGN KEY (closed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: line_shift_closures line_shift_closures_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_shift_closures
    ADD CONSTRAINT line_shift_closures_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.production_lines(id) ON DELETE CASCADE;


--
-- Name: material_transactions material_transactions_from_process_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_transactions
    ADD CONSTRAINT material_transactions_from_process_id_fkey FOREIGN KEY (from_process_id) REFERENCES public.product_processes(id) ON DELETE SET NULL;


--
-- Name: material_transactions material_transactions_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_transactions
    ADD CONSTRAINT material_transactions_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.production_lines(id) ON DELETE CASCADE;


--
-- Name: material_transactions material_transactions_recorded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_transactions
    ADD CONSTRAINT material_transactions_recorded_by_fkey FOREIGN KEY (recorded_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: material_transactions material_transactions_to_process_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_transactions
    ADD CONSTRAINT material_transactions_to_process_id_fkey FOREIGN KEY (to_process_id) REFERENCES public.product_processes(id) ON DELETE SET NULL;


--
-- Name: process_assignment_history process_assignment_history_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_assignment_history
    ADD CONSTRAINT process_assignment_history_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: process_assignment_history process_assignment_history_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_assignment_history
    ADD CONSTRAINT process_assignment_history_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: process_assignment_history process_assignment_history_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_assignment_history
    ADD CONSTRAINT process_assignment_history_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.production_lines(id) ON DELETE CASCADE;


--
-- Name: process_assignment_history process_assignment_history_process_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_assignment_history
    ADD CONSTRAINT process_assignment_history_process_id_fkey FOREIGN KEY (process_id) REFERENCES public.product_processes(id) ON DELETE CASCADE;


--
-- Name: process_material_wip process_material_wip_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_material_wip
    ADD CONSTRAINT process_material_wip_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.production_lines(id) ON DELETE CASCADE;


--
-- Name: process_material_wip process_material_wip_process_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_material_wip
    ADD CONSTRAINT process_material_wip_process_id_fkey FOREIGN KEY (process_id) REFERENCES public.product_processes(id) ON DELETE CASCADE;


--
-- Name: product_processes product_processes_operation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_processes
    ADD CONSTRAINT product_processes_operation_id_fkey FOREIGN KEY (operation_id) REFERENCES public.operations(id) ON DELETE RESTRICT;


--
-- Name: product_processes product_processes_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_processes
    ADD CONSTRAINT product_processes_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE RESTRICT;


--
-- Name: production_day_locks production_day_locks_locked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_day_locks
    ADD CONSTRAINT production_day_locks_locked_by_fkey FOREIGN KEY (locked_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict ZJJ3hPJfJjF7AAnbZgQESGF4zi2Dqf8dH36dJWkJyWDrFnxNnxfLnCxFXzGI28H

