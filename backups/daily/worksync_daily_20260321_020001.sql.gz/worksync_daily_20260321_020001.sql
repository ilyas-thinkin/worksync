--
-- PostgreSQL database dump
--

\restrict EswYVbzplxp14egmXiIpTk4nAkpjfhdFVF7FRFXvLVmSTLTzdUFPFz7rsjly3f3

-- Dumped from database version 17.7 (Debian 17.7-0+deb13u1)
-- Dumped by pg_dump version 17.7 (Debian 17.7-0+deb13u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: log_material_transaction(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.log_material_transaction() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM pg_notify('worksync_changes', json_build_object(
        'table', TG_TABLE_NAME,
        'action', TG_OP,
        'id', NEW.id,
        'line_id', NEW.line_id,
        'work_date', NEW.work_date
    )::text);
    RETURN NEW;
END;
$$;


--
-- Name: notify_data_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.notify_data_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    payload jsonb;
BEGIN
    IF TG_TABLE_NAME = 'employee_process_assignments' THEN
        IF (TG_OP = 'DELETE') THEN
            payload = jsonb_build_object(
                'entity', TG_TABLE_NAME,
                'action', TG_OP,
                'process_id', OLD.process_id,
                'employee_id', OLD.employee_id,
                'line_id', OLD.line_id
            );
        ELSE
            payload = jsonb_build_object(
                'entity', TG_TABLE_NAME,
                'action', TG_OP,
                'process_id', NEW.process_id,
                'employee_id', NEW.employee_id,
                'line_id', NEW.line_id
            );
        END IF;
        PERFORM pg_notify('data_change', payload::text);
        RETURN NULL;
    END IF;

    IF (TG_OP = 'DELETE') THEN
        payload = jsonb_build_object(
            'entity', TG_TABLE_NAME,
            'action', TG_OP,
            'id', OLD.id
        );
        IF TG_TABLE_NAME = 'product_processes' THEN
            payload = payload || jsonb_build_object('product_id', OLD.product_id);
        END IF;
    ELSE
        payload = jsonb_build_object(
            'entity', TG_TABLE_NAME,
            'action', TG_OP,
            'id', NEW.id
        );
        IF TG_TABLE_NAME = 'product_processes' THEN
            payload = payload || jsonb_build_object('product_id', NEW.product_id);
        END IF;
    END IF;

    PERFORM pg_notify('data_change', payload::text);
    RETURN NULL;
END;
$$;


--
-- Name: update_modified_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_modified_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: app_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_settings (
    key character varying(50) NOT NULL,
    value character varying(100) NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    table_name character varying(50) NOT NULL,
    record_id integer NOT NULL,
    action character varying(20) NOT NULL,
    old_values jsonb,
    new_values jsonb,
    changed_by integer,
    changed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    reason text,
    ip_address character varying(50),
    user_agent text,
    session_id character varying(100),
    request_path character varying(255),
    http_method character varying(10)
);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: defect_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.defect_log (
    id integer NOT NULL,
    line_id integer NOT NULL,
    process_id integer,
    employee_id integer,
    defect_type_id integer NOT NULL,
    work_date date NOT NULL,
    hour_slot integer,
    quantity integer DEFAULT 1 NOT NULL,
    status character varying(20) DEFAULT 'detected'::character varying,
    rework_employee_id integer,
    rework_completed_at timestamp without time zone,
    notes text,
    detected_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT defect_log_hour_slot_check CHECK (((hour_slot >= 0) AND (hour_slot <= 23)))
);


--
-- Name: defect_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.defect_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: defect_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.defect_log_id_seq OWNED BY public.defect_log.id;


--
-- Name: defect_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.defect_types (
    id integer NOT NULL,
    defect_code character varying(20) NOT NULL,
    defect_name character varying(100) NOT NULL,
    defect_category character varying(50),
    severity character varying(20) DEFAULT 'minor'::character varying,
    is_reworkable boolean DEFAULT true,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: defect_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.defect_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: defect_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.defect_types_id_seq OWNED BY public.defect_types.id;


--
-- Name: downtime_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.downtime_log (
    id integer NOT NULL,
    line_id integer NOT NULL,
    reason_id integer NOT NULL,
    work_date date NOT NULL,
    start_time timestamp without time zone NOT NULL,
    end_time timestamp without time zone,
    duration_minutes integer,
    affected_processes text[],
    notes text,
    reported_by integer,
    resolved_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: downtime_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.downtime_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: downtime_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.downtime_log_id_seq OWNED BY public.downtime_log.id;


--
-- Name: downtime_reasons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.downtime_reasons (
    id integer NOT NULL,
    reason_code character varying(20) NOT NULL,
    reason_name character varying(100) NOT NULL,
    reason_category character varying(50),
    is_planned boolean DEFAULT false,
    default_duration_minutes integer,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: downtime_reasons_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.downtime_reasons_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: downtime_reasons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.downtime_reasons_id_seq OWNED BY public.downtime_reasons.id;


--
-- Name: employee_attendance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_attendance (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    attendance_date date NOT NULL,
    in_time time without time zone,
    out_time time without time zone,
    status character varying(30) DEFAULT 'present'::character varying,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: employee_attendance_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_attendance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_attendance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_attendance_id_seq OWNED BY public.employee_attendance.id;


--
-- Name: employee_process_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_process_assignments (
    id integer NOT NULL,
    process_id integer NOT NULL,
    employee_id integer NOT NULL,
    assigned_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    line_id integer
);


--
-- Name: employee_process_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_process_assignments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_process_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_process_assignments_id_seq OWNED BY public.employee_process_assignments.id;


--
-- Name: employee_workstation_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_workstation_assignments (
    id integer NOT NULL,
    line_id integer NOT NULL,
    workstation_code character varying(100) NOT NULL,
    employee_id integer NOT NULL,
    assigned_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    work_date date,
    line_plan_workstation_id integer,
    is_overtime boolean DEFAULT false NOT NULL,
    material_provided integer,
    is_linked boolean DEFAULT true NOT NULL
);


--
-- Name: COLUMN employee_workstation_assignments.material_provided; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.employee_workstation_assignments.material_provided IS 'Units of material/WIP provided to this workstation at start of day';


--
-- Name: employee_workstation_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employee_workstation_assignments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employee_workstation_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employee_workstation_assignments_id_seq OWNED BY public.employee_workstation_assignments.id;


--
-- Name: employees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employees (
    id integer NOT NULL,
    emp_code character varying(50) NOT NULL,
    emp_name character varying(100) NOT NULL,
    designation character varying(100),
    default_line_id integer,
    qr_code_path character varying(255),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by integer,
    updated_by integer,
    manpower_factor numeric DEFAULT 1 NOT NULL,
    CONSTRAINT emp_code_format CHECK (((emp_code)::text ~ '^[A-Z0-9]+$'::text)),
    CONSTRAINT employees_manpower_factor_check CHECK ((manpower_factor > (0)::numeric))
);


--
-- Name: employees_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employees_id_seq OWNED BY public.employees.id;


--
-- Name: group_wip; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.group_wip (
    id integer NOT NULL,
    line_id integer NOT NULL,
    work_date date NOT NULL,
    group_name character varying(100) NOT NULL,
    materials_in integer DEFAULT 0 NOT NULL,
    output_qty integer DEFAULT 0 NOT NULL,
    wip_quantity integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: group_wip_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.group_wip_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: group_wip_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.group_wip_id_seq OWNED BY public.group_wip.id;


--
-- Name: line_daily_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.line_daily_metrics (
    id integer NOT NULL,
    line_id integer NOT NULL,
    work_date date NOT NULL,
    forwarded_quantity integer DEFAULT 0 NOT NULL,
    remaining_wip integer DEFAULT 0 NOT NULL,
    materials_issued integer DEFAULT 0 NOT NULL,
    updated_by integer,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    qa_output integer DEFAULT 0 NOT NULL,
    CONSTRAINT line_daily_metrics_qa_check CHECK ((qa_output >= 0))
);


--
-- Name: line_daily_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.line_daily_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: line_daily_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.line_daily_metrics_id_seq OWNED BY public.line_daily_metrics.id;


--
-- Name: line_daily_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.line_daily_plans (
    id integer NOT NULL,
    line_id integer NOT NULL,
    product_id integer NOT NULL,
    work_date date NOT NULL,
    target_units integer DEFAULT 0 NOT NULL,
    created_by integer,
    updated_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    is_locked boolean DEFAULT false NOT NULL,
    incoming_product_id integer,
    incoming_target_units integer DEFAULT 0 NOT NULL,
    changeover_sequence integer DEFAULT 0 NOT NULL,
    overtime_minutes integer DEFAULT 0 NOT NULL,
    overtime_target integer DEFAULT 0 NOT NULL,
    changeover_started_at timestamp with time zone,
    ot_enabled boolean DEFAULT false NOT NULL,
    CONSTRAINT line_daily_plans_changeover_sequence_nonneg CHECK ((changeover_sequence >= 0))
);


--
-- Name: line_daily_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.line_daily_plans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: line_daily_plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.line_daily_plans_id_seq OWNED BY public.line_daily_plans.id;


--
-- Name: line_hourly_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.line_hourly_reports (
    line_id integer NOT NULL,
    work_date date NOT NULL,
    hour_slot integer NOT NULL,
    remarks text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: line_material_stock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.line_material_stock (
    id integer NOT NULL,
    line_id integer NOT NULL,
    work_date date NOT NULL,
    opening_stock integer DEFAULT 0 NOT NULL,
    total_issued integer DEFAULT 0 NOT NULL,
    total_used integer DEFAULT 0 NOT NULL,
    total_returned integer DEFAULT 0 NOT NULL,
    closing_stock integer DEFAULT 0 NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE line_material_stock; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.line_material_stock IS 'Daily material stock balance per line';


--
-- Name: line_material_stock_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.line_material_stock_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: line_material_stock_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.line_material_stock_id_seq OWNED BY public.line_material_stock.id;


--
-- Name: line_ot_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.line_ot_plans (
    id integer NOT NULL,
    line_id integer NOT NULL,
    work_date date NOT NULL,
    product_id integer NOT NULL,
    global_ot_minutes integer DEFAULT 60 NOT NULL,
    ot_target_units integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    supervisor_authorized boolean DEFAULT false NOT NULL
);


--
-- Name: COLUMN line_ot_plans.supervisor_authorized; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.line_ot_plans.supervisor_authorized IS 'IE has authorized the supervisor to assign/modify workstations and employees during OT';


--
-- Name: line_ot_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.line_ot_plans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: line_ot_plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.line_ot_plans_id_seq OWNED BY public.line_ot_plans.id;


--
-- Name: line_ot_progress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.line_ot_progress (
    id integer NOT NULL,
    line_id integer NOT NULL,
    ot_workstation_id integer NOT NULL,
    work_date date NOT NULL,
    quantity integer DEFAULT 0 NOT NULL,
    qa_rejection integer DEFAULT 0 NOT NULL,
    remarks text,
    employee_id integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: line_ot_progress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.line_ot_progress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: line_ot_progress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.line_ot_progress_id_seq OWNED BY public.line_ot_progress.id;


--
-- Name: line_ot_workstation_processes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.line_ot_workstation_processes (
    id integer NOT NULL,
    ot_workstation_id integer NOT NULL,
    product_process_id integer NOT NULL,
    sequence_in_workstation integer DEFAULT 0 NOT NULL
);


--
-- Name: line_ot_workstation_processes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.line_ot_workstation_processes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: line_ot_workstation_processes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.line_ot_workstation_processes_id_seq OWNED BY public.line_ot_workstation_processes.id;


--
-- Name: line_ot_workstations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.line_ot_workstations (
    id integer NOT NULL,
    ot_plan_id integer NOT NULL,
    workstation_code character varying(50) NOT NULL,
    workstation_number integer,
    group_name character varying(100),
    is_active boolean DEFAULT true NOT NULL,
    ot_minutes integer DEFAULT 0 NOT NULL,
    actual_sam_seconds numeric(10,2) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: line_ot_workstations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.line_ot_workstations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: line_ot_workstations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.line_ot_workstations_id_seq OWNED BY public.line_ot_workstations.id;


--
-- Name: line_plan_workstation_processes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.line_plan_workstation_processes (
    id integer NOT NULL,
    workstation_id integer NOT NULL,
    product_process_id integer NOT NULL,
    sequence_in_workstation integer DEFAULT 1 NOT NULL,
    osm_checked boolean DEFAULT false NOT NULL
);


--
-- Name: line_plan_workstation_processes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.line_plan_workstation_processes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: line_plan_workstation_processes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.line_plan_workstation_processes_id_seq OWNED BY public.line_plan_workstation_processes.id;


--
-- Name: line_plan_workstations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.line_plan_workstations (
    id integer NOT NULL,
    line_id integer NOT NULL,
    work_date date NOT NULL,
    product_id integer NOT NULL,
    workstation_number integer NOT NULL,
    workstation_code character varying(20) NOT NULL,
    takt_time_seconds numeric(10,2),
    actual_sam_seconds numeric(10,2),
    workload_pct numeric(5,2),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    group_name character varying(100),
    is_ot_skipped boolean DEFAULT false NOT NULL,
    ws_changeover_active boolean DEFAULT false NOT NULL,
    ws_changeover_started_at timestamp with time zone,
    co_employee_id integer
);


--
-- Name: COLUMN line_plan_workstations.co_employee_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.line_plan_workstations.co_employee_id IS 'IE-pre-assigned changeover employee for this workstation (suggestion for supervisor to confirm or override)';


--
-- Name: line_plan_workstations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.line_plan_workstations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: line_plan_workstations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.line_plan_workstations_id_seq OWNED BY public.line_plan_workstations.id;


--
-- Name: line_process_hourly_progress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.line_process_hourly_progress (
    id integer NOT NULL,
    line_id integer NOT NULL,
    process_id integer NOT NULL,
    work_date date NOT NULL,
    hour_slot integer NOT NULL,
    quantity integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    employee_id integer,
    forwarded_quantity integer DEFAULT 0 NOT NULL,
    remaining_quantity integer DEFAULT 0 NOT NULL,
    qa_rejection integer DEFAULT 0 NOT NULL,
    remarks text,
    shortfall_reason character varying(100),
    CONSTRAINT line_process_hourly_progress_forwarded_check CHECK ((forwarded_quantity >= 0)),
    CONSTRAINT line_process_hourly_progress_hour_slot_check CHECK (((hour_slot >= 8) AND (hour_slot <= 19))),
    CONSTRAINT line_process_hourly_progress_remaining_check CHECK ((remaining_quantity >= 0))
);


--
-- Name: line_process_hourly_progress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.line_process_hourly_progress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: line_process_hourly_progress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.line_process_hourly_progress_id_seq OWNED BY public.line_process_hourly_progress.id;


--
-- Name: line_shift_closures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.line_shift_closures (
    id integer NOT NULL,
    line_id integer NOT NULL,
    work_date date NOT NULL,
    closed_by integer,
    closed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    notes text
);


--
-- Name: line_shift_closures_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.line_shift_closures_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: line_shift_closures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.line_shift_closures_id_seq OWNED BY public.line_shift_closures.id;


--
-- Name: line_workstations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.line_workstations (
    id integer NOT NULL,
    line_id integer NOT NULL,
    workstation_number integer NOT NULL,
    workstation_code character varying(10) NOT NULL,
    qr_code_path character varying(500),
    created_at timestamp without time zone DEFAULT now(),
    CONSTRAINT line_workstations_workstation_number_check CHECK (((workstation_number >= 1) AND (workstation_number <= 100)))
);


--
-- Name: line_workstations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.line_workstations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: line_workstations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.line_workstations_id_seq OWNED BY public.line_workstations.id;


--
-- Name: material_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.material_transactions (
    id integer NOT NULL,
    line_id integer NOT NULL,
    work_date date NOT NULL,
    transaction_type character varying(50) NOT NULL,
    quantity integer NOT NULL,
    from_process_id integer,
    to_process_id integer,
    notes text,
    recorded_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE material_transactions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.material_transactions IS 'Tracks all material movements in the production line';


--
-- Name: material_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.material_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: material_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.material_transactions_id_seq OWNED BY public.material_transactions.id;


--
-- Name: operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.operations (
    id integer NOT NULL,
    operation_code character varying(50) NOT NULL,
    operation_name character varying(200) NOT NULL,
    operation_description text,
    operation_category character varying(100),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by integer,
    updated_by integer,
    qr_code_path character varying(255)
);


--
-- Name: TABLE operations; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.operations IS 'Master list of all manufacturing operations';


--
-- Name: operations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.operations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: operations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.operations_id_seq OWNED BY public.operations.id;


--
-- Name: process_assignment_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.process_assignment_history (
    id integer NOT NULL,
    line_id integer NOT NULL,
    process_id integer NOT NULL,
    employee_id integer NOT NULL,
    start_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    end_time timestamp without time zone,
    quantity_completed integer DEFAULT 0 NOT NULL,
    changed_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    materials_at_link integer DEFAULT 0 NOT NULL,
    existing_materials integer DEFAULT 0 NOT NULL,
    CONSTRAINT process_assignment_history_existing_materials_check CHECK ((existing_materials >= 0)),
    CONSTRAINT process_assignment_history_materials_check CHECK ((materials_at_link >= 0))
);


--
-- Name: process_assignment_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.process_assignment_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: process_assignment_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.process_assignment_history_id_seq OWNED BY public.process_assignment_history.id;


--
-- Name: process_material_wip; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.process_material_wip (
    id integer NOT NULL,
    line_id integer NOT NULL,
    process_id integer NOT NULL,
    work_date date NOT NULL,
    materials_in integer DEFAULT 0 NOT NULL,
    materials_out integer DEFAULT 0 NOT NULL,
    wip_quantity integer DEFAULT 0 NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE process_material_wip; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.process_material_wip IS 'Work-in-progress materials at each process step';


--
-- Name: process_material_wip_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.process_material_wip_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: process_material_wip_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.process_material_wip_id_seq OWNED BY public.process_material_wip.id;


--
-- Name: product_processes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_processes (
    id integer NOT NULL,
    product_id integer NOT NULL,
    operation_id integer NOT NULL,
    sequence_number integer NOT NULL,
    operation_sah numeric(10,4) NOT NULL,
    cycle_time_seconds integer,
    manpower_required integer DEFAULT 1,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by integer,
    updated_by integer,
    qr_code_path character varying(255),
    target_units integer DEFAULT 0 NOT NULL,
    workspace_id integer,
    group_name character varying(50),
    workstation_code character varying(50),
    worker_input_mapping character varying(50) DEFAULT 'CONT'::character varying,
    osm_checked boolean DEFAULT false NOT NULL,
    CONSTRAINT chk_sah_positive CHECK ((operation_sah > (0)::numeric)),
    CONSTRAINT chk_sequence_positive CHECK ((sequence_number > 0)),
    CONSTRAINT chk_target_units_nonnegative CHECK ((target_units >= 0))
);


--
-- Name: TABLE product_processes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.product_processes IS 'Product-specific operation sequences with SAH and workspace assignments';


--
-- Name: COLUMN product_processes.sequence_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_processes.sequence_number IS 'Order of operation in the process flow (1, 2, 3, ...)';


--
-- Name: COLUMN product_processes.operation_sah; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_processes.operation_sah IS 'SAH for this specific operation on this product';


--
-- Name: COLUMN product_processes.cycle_time_seconds; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_processes.cycle_time_seconds IS 'Cycle time in seconds';


--
-- Name: product_processes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_processes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_processes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_processes_id_seq OWNED BY public.product_processes.id;


--
-- Name: production_day_locks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.production_day_locks (
    work_date date NOT NULL,
    locked_by integer,
    locked_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    notes text
);


--
-- Name: production_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.production_lines (
    id integer NOT NULL,
    line_code character varying(50) NOT NULL,
    line_name character varying(100) NOT NULL,
    hall_location character varying(50),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by integer,
    updated_by integer,
    current_product_id integer,
    target_units integer DEFAULT 0 NOT NULL,
    efficiency numeric(5,2) DEFAULT 0 NOT NULL,
    qr_code_path character varying(255),
    line_leader character varying(100)
);


--
-- Name: production_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.production_lines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: production_lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.production_lines_id_seq OWNED BY public.production_lines.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id integer NOT NULL,
    product_code character varying(50) NOT NULL,
    product_name character varying(200) NOT NULL,
    product_description text,
    category character varying(100),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by integer,
    updated_by integer,
    line_id integer,
    buyer_name character varying(200),
    target_qty integer DEFAULT 0 NOT NULL
);


--
-- Name: TABLE products; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.products IS 'Master table for products/styles manufactured';


--
-- Name: COLUMN products.product_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.products.product_code IS 'Unique product identifier (e.g., CY405)';


--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    full_name character varying(100) NOT NULL,
    role character varying(20) NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['admin'::character varying, 'ie'::character varying, 'supervisor'::character varying])::text[])))
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: v_audit_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_audit_summary AS
 SELECT date(changed_at) AS audit_date,
    table_name,
    action,
    count(*) AS action_count,
    count(DISTINCT changed_by) AS unique_users
   FROM public.audit_logs
  WHERE (changed_at >= (CURRENT_DATE - '30 days'::interval))
  GROUP BY (date(changed_at)), table_name, action
  ORDER BY (date(changed_at)) DESC, table_name, action;


--
-- Name: v_daily_defect_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_daily_defect_summary AS
 SELECT dl.work_date,
    dl.line_id,
    pl.line_name,
    dt.defect_category,
    dt.defect_code,
    dt.defect_name,
    dt.severity,
    count(*) AS defect_count,
    sum(dl.quantity) AS total_quantity,
    sum(
        CASE
            WHEN ((dl.status)::text = 'reworked'::text) THEN dl.quantity
            ELSE 0
        END) AS reworked_quantity,
    sum(
        CASE
            WHEN ((dl.status)::text = 'rejected'::text) THEN dl.quantity
            ELSE 0
        END) AS rejected_quantity
   FROM ((public.defect_log dl
     JOIN public.production_lines pl ON ((dl.line_id = pl.id)))
     JOIN public.defect_types dt ON ((dl.defect_type_id = dt.id)))
  GROUP BY dl.work_date, dl.line_id, pl.line_name, dt.defect_category, dt.defect_code, dt.defect_name, dt.severity
  ORDER BY dl.work_date DESC, (sum(dl.quantity)) DESC;


--
-- Name: v_daily_downtime_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_daily_downtime_summary AS
 SELECT dl.work_date,
    dl.line_id,
    pl.line_name,
    dr.reason_category,
    dr.reason_code,
    dr.reason_name,
    dr.is_planned,
    count(*) AS incident_count,
    sum(COALESCE((dl.duration_minutes)::numeric, (EXTRACT(epoch FROM (COALESCE((dl.end_time)::timestamp with time zone, now()) - (dl.start_time)::timestamp with time zone)) / (60)::numeric))) AS total_minutes
   FROM ((public.downtime_log dl
     JOIN public.production_lines pl ON ((dl.line_id = pl.id)))
     JOIN public.downtime_reasons dr ON ((dl.reason_id = dr.id)))
  GROUP BY dl.work_date, dl.line_id, pl.line_name, dr.reason_category, dr.reason_code, dr.reason_name, dr.is_planned
  ORDER BY dl.work_date DESC, (sum(COALESCE((dl.duration_minutes)::numeric, (EXTRACT(epoch FROM (COALESCE((dl.end_time)::timestamp with time zone, now()) - (dl.start_time)::timestamp with time zone)) / (60)::numeric)))) DESC;


--
-- Name: v_daily_material_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_daily_material_summary AS
 SELECT line_id,
    work_date,
    COALESCE(sum(
        CASE
            WHEN ((transaction_type)::text = 'issued'::text) THEN quantity
            ELSE 0
        END), (0)::bigint) AS total_issued,
    COALESCE(sum(
        CASE
            WHEN ((transaction_type)::text = 'used'::text) THEN quantity
            ELSE 0
        END), (0)::bigint) AS total_used,
    COALESCE(sum(
        CASE
            WHEN ((transaction_type)::text = 'returned'::text) THEN quantity
            ELSE 0
        END), (0)::bigint) AS total_returned,
    COALESCE(sum(
        CASE
            WHEN ((transaction_type)::text = 'forwarded'::text) THEN quantity
            ELSE 0
        END), (0)::bigint) AS total_forwarded,
    COALESCE(sum(
        CASE
            WHEN ((transaction_type)::text = 'received'::text) THEN quantity
            ELSE 0
        END), (0)::bigint) AS total_received
   FROM public.material_transactions
  GROUP BY line_id, work_date;


--
-- Name: v_recent_critical_changes; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_recent_critical_changes AS
 SELECT al.id,
    al.table_name,
    al.record_id,
    al.action,
    al.changed_at,
    al.ip_address,
    u.username AS changed_by_user,
    al.old_values,
    al.new_values,
    al.reason
   FROM (public.audit_logs al
     LEFT JOIN public.users u ON ((al.changed_by = u.id)))
  WHERE (((al.table_name)::text = ANY ((ARRAY['users'::character varying, 'production_lines'::character varying, 'products'::character varying, 'employees'::character varying])::text[])) AND ((al.action)::text = ANY ((ARRAY['delete'::character varying, 'update'::character varying])::text[])) AND (al.changed_at >= (CURRENT_TIMESTAMP - '7 days'::interval)))
  ORDER BY al.changed_at DESC
 LIMIT 100;


--
-- Name: worker_adjustments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.worker_adjustments (
    id integer NOT NULL,
    line_id integer NOT NULL,
    work_date date NOT NULL,
    departure_id integer NOT NULL,
    vacant_workstation_code character varying(100) NOT NULL,
    from_employee_id integer NOT NULL,
    from_workstation_code character varying(100) NOT NULL,
    adjustment_type character varying(10) NOT NULL,
    reassignment_time timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT worker_adjustments_adjustment_type_check CHECK (((adjustment_type)::text = ANY ((ARRAY['assign'::character varying, 'combine'::character varying])::text[])))
);


--
-- Name: worker_adjustments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.worker_adjustments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: worker_adjustments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.worker_adjustments_id_seq OWNED BY public.worker_adjustments.id;


--
-- Name: worker_departures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.worker_departures (
    id integer NOT NULL,
    line_id integer NOT NULL,
    work_date date NOT NULL,
    employee_id integer NOT NULL,
    workstation_code character varying(100) NOT NULL,
    departure_time timestamp with time zone DEFAULT now() NOT NULL,
    departure_reason character varying(20) NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT worker_departures_departure_reason_check CHECK (((departure_reason)::text = ANY ((ARRAY['sick'::character varying, 'personal'::character varying, 'operational'::character varying, 'other'::character varying])::text[])))
);


--
-- Name: worker_departures_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.worker_departures_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: worker_departures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.worker_departures_id_seq OWNED BY public.worker_departures.id;


--
-- Name: workspaces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspaces (
    id integer NOT NULL,
    workspace_code character varying(50) NOT NULL,
    workspace_name character varying(100) NOT NULL,
    workspace_type character varying(50),
    line_id integer,
    qr_code_path character varying(255),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by integer,
    updated_by integer,
    group_name character varying(50),
    worker_input_mapping character varying(50) DEFAULT 'CONT'::character varying
);


--
-- Name: workspaces_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.workspaces_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: workspaces_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.workspaces_id_seq OWNED BY public.workspaces.id;


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: defect_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.defect_log ALTER COLUMN id SET DEFAULT nextval('public.defect_log_id_seq'::regclass);


--
-- Name: defect_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.defect_types ALTER COLUMN id SET DEFAULT nextval('public.defect_types_id_seq'::regclass);


--
-- Name: downtime_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.downtime_log ALTER COLUMN id SET DEFAULT nextval('public.downtime_log_id_seq'::regclass);


--
-- Name: downtime_reasons id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.downtime_reasons ALTER COLUMN id SET DEFAULT nextval('public.downtime_reasons_id_seq'::regclass);


--
-- Name: employee_attendance id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_attendance ALTER COLUMN id SET DEFAULT nextval('public.employee_attendance_id_seq'::regclass);


--
-- Name: employee_process_assignments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_process_assignments ALTER COLUMN id SET DEFAULT nextval('public.employee_process_assignments_id_seq'::regclass);


--
-- Name: employee_workstation_assignments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_workstation_assignments ALTER COLUMN id SET DEFAULT nextval('public.employee_workstation_assignments_id_seq'::regclass);


--
-- Name: employees id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees ALTER COLUMN id SET DEFAULT nextval('public.employees_id_seq'::regclass);


--
-- Name: group_wip id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_wip ALTER COLUMN id SET DEFAULT nextval('public.group_wip_id_seq'::regclass);


--
-- Name: line_daily_metrics id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_daily_metrics ALTER COLUMN id SET DEFAULT nextval('public.line_daily_metrics_id_seq'::regclass);


--
-- Name: line_daily_plans id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_daily_plans ALTER COLUMN id SET DEFAULT nextval('public.line_daily_plans_id_seq'::regclass);


--
-- Name: line_material_stock id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_material_stock ALTER COLUMN id SET DEFAULT nextval('public.line_material_stock_id_seq'::regclass);


--
-- Name: line_ot_plans id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_ot_plans ALTER COLUMN id SET DEFAULT nextval('public.line_ot_plans_id_seq'::regclass);


--
-- Name: line_ot_progress id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_ot_progress ALTER COLUMN id SET DEFAULT nextval('public.line_ot_progress_id_seq'::regclass);


--
-- Name: line_ot_workstation_processes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_ot_workstation_processes ALTER COLUMN id SET DEFAULT nextval('public.line_ot_workstation_processes_id_seq'::regclass);


--
-- Name: line_ot_workstations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_ot_workstations ALTER COLUMN id SET DEFAULT nextval('public.line_ot_workstations_id_seq'::regclass);


--
-- Name: line_plan_workstation_processes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_plan_workstation_processes ALTER COLUMN id SET DEFAULT nextval('public.line_plan_workstation_processes_id_seq'::regclass);


--
-- Name: line_plan_workstations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_plan_workstations ALTER COLUMN id SET DEFAULT nextval('public.line_plan_workstations_id_seq'::regclass);


--
-- Name: line_process_hourly_progress id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_process_hourly_progress ALTER COLUMN id SET DEFAULT nextval('public.line_process_hourly_progress_id_seq'::regclass);


--
-- Name: line_shift_closures id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_shift_closures ALTER COLUMN id SET DEFAULT nextval('public.line_shift_closures_id_seq'::regclass);


--
-- Name: line_workstations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_workstations ALTER COLUMN id SET DEFAULT nextval('public.line_workstations_id_seq'::regclass);


--
-- Name: material_transactions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_transactions ALTER COLUMN id SET DEFAULT nextval('public.material_transactions_id_seq'::regclass);


--
-- Name: operations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operations ALTER COLUMN id SET DEFAULT nextval('public.operations_id_seq'::regclass);


--
-- Name: process_assignment_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_assignment_history ALTER COLUMN id SET DEFAULT nextval('public.process_assignment_history_id_seq'::regclass);


--
-- Name: process_material_wip id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_material_wip ALTER COLUMN id SET DEFAULT nextval('public.process_material_wip_id_seq'::regclass);


--
-- Name: product_processes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_processes ALTER COLUMN id SET DEFAULT nextval('public.product_processes_id_seq'::regclass);


--
-- Name: production_lines id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_lines ALTER COLUMN id SET DEFAULT nextval('public.production_lines_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: worker_adjustments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.worker_adjustments ALTER COLUMN id SET DEFAULT nextval('public.worker_adjustments_id_seq'::regclass);


--
-- Name: worker_departures id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.worker_departures ALTER COLUMN id SET DEFAULT nextval('public.worker_departures_id_seq'::regclass);


--
-- Name: workspaces id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspaces ALTER COLUMN id SET DEFAULT nextval('public.workspaces_id_seq'::regclass);


--
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app_settings (key, value, updated_at) FROM stdin;
default_in_time	08:00	2026-01-15 20:03:32.287665
default_out_time	17:00	2026-01-15 20:03:32.287665
lunch_break_minutes	60	2026-02-19 20:19:56.103851
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, table_name, record_id, action, old_values, new_values, changed_by, changed_at, reason, ip_address, user_agent, session_id, request_path, http_method) FROM stdin;
1	production_day_locks	0	unlock	\N	\N	\N	2026-01-19 18:51:06.700983	\N	\N	\N	\N	\N	\N
2	production_day_locks	0	lock	\N	{"work_date": "2026-01-19"}	\N	2026-01-19 18:51:07.738577	\N	\N	\N	\N	\N	\N
3	production_day_locks	0	unlock	{"notes": null, "locked_at": "2026-01-19T13:21:07.735Z", "locked_by": null, "work_date": "2026-01-18T18:30:00.000Z"}	\N	\N	2026-01-19 18:51:08.595144	\N	\N	\N	\N	\N	\N
4	production_day_locks	0	lock	\N	{"work_date": "2026-01-19"}	\N	2026-01-19 19:10:55.18531	\N	\N	\N	\N	\N	\N
5	production_day_locks	0	unlock	{"notes": null, "locked_at": "2026-01-19T13:40:55.182Z", "locked_by": null, "work_date": "2026-01-18T18:30:00.000Z"}	\N	\N	2026-01-19 19:10:55.831846	\N	\N	\N	\N	\N	\N
6	line_daily_metrics	1	create	\N	{"id": 1, "line_id": 2, "qa_output": 0, "work_date": "2026-01-20T18:30:00.000Z", "updated_at": "2026-01-21T11:07:19.172Z", "updated_by": null, "remaining_wip": 0, "materials_issued": 0, "forwarded_quantity": 0}	\N	2026-01-21 16:37:19.186615	\N	\N	\N	\N	\N	\N
7	line_daily_metrics	1	update	{"id": 1, "line_id": 2, "qa_output": 0, "work_date": "2026-01-20T18:30:00.000Z", "updated_at": "2026-01-21T11:07:19.172Z", "updated_by": null, "remaining_wip": 0, "materials_issued": 0, "forwarded_quantity": 0}	{"id": 1, "line_id": 2, "qa_output": 1, "work_date": "2026-01-20T18:30:00.000Z", "updated_at": "2026-01-21T11:52:49.079Z", "updated_by": null, "remaining_wip": 2, "materials_issued": 2, "forwarded_quantity": 10}	\N	2026-01-21 17:22:49.081887	\N	\N	\N	\N	\N	\N
8	line_daily_plans	2	create	\N	{"id": 2, "line_id": 1, "is_locked": false, "work_date": "2026-02-07T18:30:00.000Z", "created_at": "2026-02-08T06:35:50.308Z", "created_by": null, "product_id": 1, "updated_at": "2026-02-08T06:35:50.308Z", "updated_by": null, "target_units": 500, "incoming_product_id": 2, "incoming_target_units": 200}	\N	2026-02-08 12:05:50.340643	\N	\N	\N	\N	\N	\N
9	line_daily_plans	2	update	{"id": 2, "line_id": 1, "is_locked": false, "work_date": "2026-02-07T18:30:00.000Z", "created_at": "2026-02-08T06:35:50.308Z", "created_by": null, "product_id": 1, "updated_at": "2026-02-08T06:35:50.308Z", "updated_by": null, "target_units": 500, "changeover_sequence": 0, "incoming_product_id": 2, "incoming_target_units": 200}	{"id": 2, "line_id": 1, "is_locked": false, "work_date": "2026-02-07T18:30:00.000Z", "created_at": "2026-02-08T06:35:50.308Z", "created_by": null, "product_id": 1, "updated_at": "2026-02-08T07:26:14.121Z", "updated_by": null, "target_units": 500, "changeover_sequence": 1, "incoming_product_id": 2, "incoming_target_units": 200}	\N	2026-02-08 12:56:14.128034	\N	\N	\N	\N	\N	\N
10	line_daily_plans	4	create	\N	{"id": 4, "line_id": 2, "is_locked": false, "work_date": "2026-02-07T18:30:00.000Z", "created_at": "2026-02-08T07:49:54.944Z", "created_by": null, "product_id": 3, "updated_at": "2026-02-08T07:49:54.944Z", "updated_by": null, "target_units": 200, "changeover_sequence": 0, "incoming_product_id": 1, "incoming_target_units": 0}	\N	2026-02-08 13:19:54.951844	\N	\N	\N	\N	\N	\N
11	line_daily_plans	5	create	\N	{"id": 5, "line_id": 3, "is_locked": false, "work_date": "2026-02-07T18:30:00.000Z", "created_at": "2026-02-08T07:56:28.675Z", "created_by": null, "product_id": 3, "updated_at": "2026-02-08T07:56:28.675Z", "updated_by": null, "target_units": 100, "changeover_sequence": 0, "incoming_product_id": 2, "incoming_target_units": 0}	\N	2026-02-08 13:26:28.684052	\N	\N	\N	\N	\N	\N
12	line_daily_plans	9	create	\N	{"id": 9, "line_id": 2, "is_locked": false, "work_date": "2026-02-09T18:30:00.000Z", "created_at": "2026-02-10T09:40:46.438Z", "created_by": null, "product_id": 1, "updated_at": "2026-02-10T09:40:46.438Z", "updated_by": null, "target_units": 200, "changeover_sequence": 0, "incoming_product_id": null, "incoming_target_units": 0}	\N	2026-02-10 15:10:46.445841	\N	\N	\N	\N	\N	\N
13	line_daily_plans	9	update	{"id": 9, "line_id": 2, "is_locked": false, "work_date": "2026-02-09T18:30:00.000Z", "created_at": "2026-02-10T09:40:46.438Z", "created_by": null, "product_id": 1, "updated_at": "2026-02-10T09:40:46.438Z", "updated_by": null, "target_units": 200, "changeover_sequence": 0, "incoming_product_id": null, "incoming_target_units": 0}	{"id": 9, "line_id": 2, "is_locked": false, "work_date": "2026-02-09T18:30:00.000Z", "created_at": "2026-02-10T09:40:46.438Z", "created_by": null, "product_id": 1, "updated_at": "2026-02-10T09:41:03.012Z", "updated_by": null, "target_units": 200, "changeover_sequence": 0, "incoming_product_id": 2, "incoming_target_units": 0}	\N	2026-02-10 15:11:03.015992	\N	\N	\N	\N	\N	\N
14	line_daily_plans	11	create	\N	{"id": 11, "line_id": 1, "is_locked": false, "work_date": "2026-02-09T18:30:00.000Z", "created_at": "2026-02-10T09:54:49.217Z", "created_by": null, "product_id": 3, "updated_at": "2026-02-10T09:54:49.217Z", "updated_by": null, "target_units": 500, "changeover_sequence": 0, "incoming_product_id": 2, "incoming_target_units": 0}	\N	2026-02-10 15:24:49.223708	\N	\N	\N	\N	\N	\N
15	line_daily_plans	11	update	{"id": 11, "line_id": 1, "is_locked": false, "work_date": "2026-02-09T18:30:00.000Z", "created_at": "2026-02-10T09:54:49.217Z", "created_by": null, "product_id": 3, "updated_at": "2026-02-10T09:54:49.217Z", "updated_by": null, "target_units": 500, "changeover_sequence": 0, "incoming_product_id": 2, "incoming_target_units": 0}	{"id": 11, "line_id": 1, "is_locked": false, "work_date": "2026-02-09T18:30:00.000Z", "created_at": "2026-02-10T09:54:49.217Z", "created_by": null, "product_id": 3, "updated_at": "2026-02-10T09:55:00.574Z", "updated_by": null, "target_units": 1, "changeover_sequence": 0, "incoming_product_id": 2, "incoming_target_units": 1}	\N	2026-02-10 15:25:00.578109	\N	\N	\N	\N	\N	\N
16	line_daily_plans	9	update	{"id": 9, "line_id": 2, "is_locked": false, "work_date": "2026-02-09T18:30:00.000Z", "created_at": "2026-02-10T09:40:46.438Z", "created_by": null, "product_id": 1, "updated_at": "2026-02-10T09:41:03.012Z", "updated_by": null, "target_units": 200, "changeover_sequence": 0, "incoming_product_id": 2, "incoming_target_units": 0}	{"id": 9, "line_id": 2, "is_locked": false, "work_date": "2026-02-09T18:30:00.000Z", "created_at": "2026-02-10T09:40:46.438Z", "created_by": null, "product_id": 1, "updated_at": "2026-02-10T09:55:06.856Z", "updated_by": null, "target_units": 2, "changeover_sequence": 0, "incoming_product_id": 2, "incoming_target_units": 0}	\N	2026-02-10 15:25:06.859605	\N	\N	\N	\N	\N	\N
17	line_daily_plans	22	create	\N	{"id": 22, "line_id": 3, "is_locked": false, "work_date": "2026-02-09T18:30:00.000Z", "created_at": "2026-02-10T10:10:00.557Z", "created_by": null, "product_id": 2, "updated_at": "2026-02-10T10:10:00.557Z", "updated_by": null, "target_units": 1, "changeover_sequence": 0, "incoming_product_id": null, "incoming_target_units": 0}	\N	2026-02-10 15:40:00.565213	\N	\N	\N	\N	\N	\N
18	line_daily_plans	23	create	\N	{"id": 23, "line_id": 2, "is_locked": false, "work_date": "2026-02-12T18:30:00.000Z", "created_at": "2026-02-13T10:51:38.989Z", "created_by": null, "product_id": 4, "updated_at": "2026-02-13T10:51:38.989Z", "updated_by": null, "target_units": 500, "changeover_sequence": 0, "incoming_product_id": 1, "incoming_target_units": 100}	\N	2026-02-13 16:21:38.998305	\N	\N	\N	\N	\N	\N
19	line_daily_plans	26	create	\N	{"id": 26, "line_id": 1, "is_locked": false, "work_date": "2026-02-18T18:30:00.000Z", "created_at": "2026-02-19T14:46:47.202Z", "created_by": null, "product_id": 5, "updated_at": "2026-02-19T14:46:47.202Z", "updated_by": null, "target_units": 500, "changeover_sequence": 0, "incoming_product_id": null, "incoming_target_units": 0}	\N	2026-02-19 20:16:47.211155	\N	\N	\N	\N	\N	\N
20	line_daily_plans	26	update	{"id": 26, "line_id": 1, "is_locked": false, "work_date": "2026-02-18T18:30:00.000Z", "created_at": "2026-02-19T14:46:47.202Z", "created_by": null, "product_id": 5, "updated_at": "2026-02-19T14:46:47.202Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": null, "incoming_target_units": 0}	{"id": 26, "line_id": 1, "is_locked": false, "work_date": "2026-02-18T18:30:00.000Z", "created_at": "2026-02-19T14:46:47.202Z", "created_by": null, "product_id": 5, "updated_at": "2026-02-19T15:26:00.926Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": 1, "incoming_target_units": 100}	\N	2026-02-19 20:56:00.938118	\N	\N	\N	\N	\N	\N
21	line_daily_plans	28	create	\N	{"id": 28, "line_id": 2, "is_locked": false, "work_date": "2026-02-18T18:30:00.000Z", "created_at": "2026-02-19T15:26:39.542Z", "created_by": null, "product_id": 1, "updated_at": "2026-02-19T15:26:39.542Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": null, "incoming_target_units": 0}	\N	2026-02-19 20:56:39.549785	\N	\N	\N	\N	\N	\N
22	line_daily_plans	26	set_overtime	{"id": 26, "line_id": 1, "is_locked": false, "work_date": "2026-02-18T18:30:00.000Z", "created_at": "2026-02-19T14:46:47.202Z", "created_by": null, "product_id": 5, "updated_at": "2026-02-19T15:39:07.886Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 60, "changeover_sequence": 0, "incoming_product_id": 1, "incoming_target_units": 100}	\N	\N	2026-02-19 21:09:07.89804	\N	\N	\N	\N	\N	\N
23	line_daily_plans	26	set_overtime	{"id": 26, "line_id": 1, "is_locked": false, "work_date": "2026-02-18T18:30:00.000Z", "created_at": "2026-02-19T14:46:47.202Z", "created_by": null, "product_id": 5, "updated_at": "2026-02-19T15:39:20.599Z", "updated_by": null, "target_units": 500, "overtime_target": 50, "overtime_minutes": 60, "changeover_sequence": 0, "incoming_product_id": 1, "incoming_target_units": 100}	\N	\N	2026-02-19 21:09:20.602049	\N	\N	\N	\N	\N	\N
24	line_daily_plans	29	create	\N	{"id": 29, "line_id": 1, "is_locked": false, "work_date": "2026-02-21T18:30:00.000Z", "created_at": "2026-02-22T09:01:07.093Z", "created_by": null, "product_id": 5, "updated_at": "2026-02-22T09:01:07.093Z", "updated_by": null, "target_units": 100, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": null, "changeover_started_at": null, "incoming_target_units": 0}	\N	2026-02-22 14:31:07.112931	\N	\N	\N	\N	\N	\N
25	line_daily_plans	29	update	{"id": 29, "line_id": 1, "is_locked": false, "work_date": "2026-02-21T18:30:00.000Z", "created_at": "2026-02-22T09:01:07.093Z", "created_by": null, "product_id": 5, "updated_at": "2026-02-22T09:01:07.093Z", "updated_by": null, "target_units": 100, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": null, "changeover_started_at": null, "incoming_target_units": 0}	{"id": 29, "line_id": 1, "is_locked": false, "work_date": "2026-02-21T18:30:00.000Z", "created_at": "2026-02-22T09:01:07.093Z", "created_by": null, "product_id": 5, "updated_at": "2026-02-22T09:01:14.830Z", "updated_by": null, "target_units": 100, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": null, "changeover_started_at": null, "incoming_target_units": 0}	\N	2026-02-22 14:31:14.834212	\N	\N	\N	\N	\N	\N
26	line_daily_plans	29	set_overtime	{"id": 29, "line_id": 1, "is_locked": false, "work_date": "2026-02-21T18:30:00.000Z", "created_at": "2026-02-22T09:01:07.093Z", "created_by": null, "product_id": 5, "updated_at": "2026-02-22T09:01:35.884Z", "updated_by": null, "target_units": 100, "overtime_target": 100, "overtime_minutes": 60, "changeover_sequence": 0, "incoming_product_id": null, "changeover_started_at": null, "incoming_target_units": 0}	\N	\N	2026-02-22 14:31:35.886682	\N	\N	\N	\N	\N	\N
27	line_daily_plans	31	create	\N	{"id": 31, "line_id": 2, "is_locked": false, "work_date": "2026-02-27T18:30:00.000Z", "created_at": "2026-02-28T14:02:47.214Z", "created_by": null, "product_id": 1, "updated_at": "2026-02-28T14:02:47.214Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": null, "changeover_started_at": null, "incoming_target_units": 0}	\N	2026-02-28 19:32:47.245077	\N	\N	\N	\N	\N	\N
28	line_daily_plans	32	create	\N	{"id": 32, "line_id": 1, "is_locked": false, "work_date": "2026-02-27T18:30:00.000Z", "created_at": "2026-02-28T14:03:08.164Z", "created_by": null, "product_id": 5, "updated_at": "2026-02-28T14:03:08.164Z", "updated_by": null, "target_units": 100, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": null, "changeover_started_at": null, "incoming_target_units": 0}	\N	2026-02-28 19:33:08.170773	\N	\N	\N	\N	\N	\N
29	line_daily_plans	33	create	\N	{"id": 33, "line_id": 3, "is_locked": false, "work_date": "2026-02-27T18:30:00.000Z", "created_at": "2026-02-28T14:03:11.046Z", "created_by": null, "product_id": 2, "updated_at": "2026-02-28T14:03:11.046Z", "updated_by": null, "target_units": 1, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": null, "changeover_started_at": null, "incoming_target_units": 0}	\N	2026-02-28 19:33:11.051712	\N	\N	\N	\N	\N	\N
41	line_daily_plans	43	create	\N	{"id": 43, "line_id": 1, "is_locked": false, "work_date": "2026-03-08T18:30:00.000Z", "created_at": "2026-03-09T08:57:27.247Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-09T08:57:27.247Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": 1, "changeover_started_at": null, "incoming_target_units": 100}	\N	2026-03-09 14:27:27.270891	\N	\N	\N	\N	\N	\N
30	line_daily_plans	31	update	{"id": 31, "line_id": 2, "is_locked": false, "work_date": "2026-02-27T18:30:00.000Z", "created_at": "2026-02-28T14:02:47.214Z", "created_by": null, "product_id": 1, "updated_at": "2026-02-28T14:02:47.214Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": null, "changeover_started_at": null, "incoming_target_units": 0}	{"id": 31, "line_id": 2, "is_locked": false, "work_date": "2026-02-27T18:30:00.000Z", "created_at": "2026-02-28T14:02:47.214Z", "created_by": null, "product_id": 1, "updated_at": "2026-02-28T14:59:47.744Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": null, "changeover_started_at": null, "incoming_target_units": 0}	\N	2026-02-28 20:29:47.751461	\N	\N	\N	\N	\N	\N
31	line_daily_plans	32	update	{"id": 32, "line_id": 1, "is_locked": false, "work_date": "2026-02-27T18:30:00.000Z", "created_at": "2026-02-28T14:03:08.164Z", "created_by": null, "product_id": 5, "updated_at": "2026-02-28T14:03:08.164Z", "updated_by": null, "target_units": 100, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": null, "changeover_started_at": null, "incoming_target_units": 0}	{"id": 32, "line_id": 1, "is_locked": false, "work_date": "2026-02-27T18:30:00.000Z", "created_at": "2026-02-28T14:03:08.164Z", "created_by": null, "product_id": 5, "updated_at": "2026-02-28T15:09:02.955Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": null, "changeover_started_at": null, "incoming_target_units": 0}	\N	2026-02-28 20:39:02.961979	\N	\N	\N	\N	\N	\N
32	line_daily_plans	32	set_overtime	{"id": 32, "line_id": 1, "is_locked": false, "work_date": "2026-02-27T18:30:00.000Z", "created_at": "2026-02-28T14:03:08.164Z", "created_by": null, "product_id": 5, "updated_at": "2026-02-28T15:23:31.175Z", "updated_by": null, "target_units": 500, "overtime_target": 50, "overtime_minutes": 60, "changeover_sequence": 0, "incoming_product_id": null, "changeover_started_at": null, "incoming_target_units": 0}	\N	\N	2026-02-28 20:53:31.17924	\N	\N	\N	\N	\N	\N
33	line_daily_plans	32	update	{"id": 32, "line_id": 1, "is_locked": false, "work_date": "2026-02-27T18:30:00.000Z", "created_at": "2026-02-28T14:03:08.164Z", "created_by": null, "product_id": 5, "updated_at": "2026-02-28T15:23:31.175Z", "updated_by": null, "target_units": 500, "overtime_target": 50, "overtime_minutes": 60, "changeover_sequence": 0, "incoming_product_id": null, "changeover_started_at": null, "incoming_target_units": 0}	{"id": 32, "line_id": 1, "is_locked": false, "work_date": "2026-02-27T18:30:00.000Z", "created_at": "2026-02-28T14:03:08.164Z", "created_by": null, "product_id": 5, "updated_at": "2026-02-28T15:24:25.067Z", "updated_by": null, "target_units": 500, "overtime_target": 50, "overtime_minutes": 60, "changeover_sequence": 0, "incoming_product_id": 1, "changeover_started_at": null, "incoming_target_units": 50}	\N	2026-02-28 20:54:25.074352	\N	\N	\N	\N	\N	\N
34	line_daily_plans	32	set_overtime	{"id": 32, "line_id": 1, "is_locked": false, "work_date": "2026-02-27T18:30:00.000Z", "created_at": "2026-02-28T14:03:08.164Z", "created_by": null, "product_id": 5, "updated_at": "2026-02-28T15:24:35.286Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": 1, "changeover_started_at": null, "incoming_target_units": 50}	\N	\N	2026-02-28 20:54:35.288438	\N	\N	\N	\N	\N	\N
35	line_daily_plans	37	create	\N	{"id": 37, "line_id": 1, "is_locked": false, "work_date": "2026-03-01T18:30:00.000Z", "created_at": "2026-03-02T09:16:59.194Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-02T09:16:59.194Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": null, "changeover_started_at": null, "incoming_target_units": 0}	\N	2026-03-02 14:46:59.221607	\N	\N	\N	\N	\N	\N
36	line_daily_plans	38	create	\N	{"id": 38, "line_id": 2, "is_locked": false, "work_date": "2026-03-01T18:30:00.000Z", "created_at": "2026-03-02T12:34:17.467Z", "created_by": null, "ot_enabled": false, "product_id": 1, "updated_at": "2026-03-02T12:34:17.467Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": null, "changeover_started_at": null, "incoming_target_units": 0}	\N	2026-03-02 18:04:17.474835	\N	\N	\N	\N	\N	\N
37	line_daily_plans	37	update	{"id": 37, "line_id": 1, "is_locked": false, "work_date": "2026-03-01T18:30:00.000Z", "created_at": "2026-03-02T09:16:59.194Z", "created_by": null, "ot_enabled": true, "product_id": 5, "updated_at": "2026-03-02T12:06:18.853Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": null, "changeover_started_at": null, "incoming_target_units": 0}	{"id": 37, "line_id": 1, "is_locked": false, "work_date": "2026-03-01T18:30:00.000Z", "created_at": "2026-03-02T09:16:59.194Z", "created_by": null, "ot_enabled": true, "product_id": 5, "updated_at": "2026-03-02T12:34:18.289Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": null, "changeover_started_at": null, "incoming_target_units": 0}	\N	2026-03-02 18:04:18.294544	\N	\N	\N	\N	\N	\N
38	line_daily_plans	40	create	\N	{"id": 40, "line_id": 3, "is_locked": false, "work_date": "2026-03-01T18:30:00.000Z", "created_at": "2026-03-02T12:34:19.044Z", "created_by": null, "ot_enabled": false, "product_id": 2, "updated_at": "2026-03-02T12:34:19.044Z", "updated_by": null, "target_units": 1, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": null, "changeover_started_at": null, "incoming_target_units": 0}	\N	2026-03-02 18:04:19.049323	\N	\N	\N	\N	\N	\N
39	line_daily_plans	41	create	\N	{"id": 41, "line_id": 1, "is_locked": false, "work_date": "2026-03-05T18:30:00.000Z", "created_at": "2026-03-06T08:37:05.590Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-06T08:37:05.590Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": null, "changeover_started_at": null, "incoming_target_units": 0}	\N	2026-03-06 14:07:05.649467	\N	\N	\N	\N	\N	\N
40	line_daily_plans	42	create	\N	{"id": 42, "line_id": 2, "is_locked": false, "work_date": "2026-03-05T18:30:00.000Z", "created_at": "2026-03-06T08:45:00.058Z", "created_by": null, "ot_enabled": false, "product_id": 1, "updated_at": "2026-03-06T08:45:00.058Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": 5, "changeover_started_at": null, "incoming_target_units": 50}	\N	2026-03-06 14:15:00.066341	\N	\N	\N	\N	\N	\N
42	line_daily_plans	43	update	{"id": 43, "line_id": 1, "is_locked": false, "work_date": "2026-03-08T18:30:00.000Z", "created_at": "2026-03-09T08:57:27.247Z", "created_by": null, "ot_enabled": true, "product_id": 5, "updated_at": "2026-03-09T16:06:47.400Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": 1, "changeover_started_at": null, "incoming_target_units": 100}	{"id": 43, "line_id": 1, "is_locked": false, "work_date": "2026-03-08T18:30:00.000Z", "created_at": "2026-03-09T08:57:27.247Z", "created_by": null, "ot_enabled": true, "product_id": 5, "updated_at": "2026-03-09T16:35:21.742Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": 1, "changeover_started_at": null, "incoming_target_units": 100}	\N	2026-03-09 22:05:21.749817	\N	\N	\N	\N	\N	\N
43	line_daily_plans	43	update	{"id": 43, "line_id": 1, "is_locked": false, "work_date": "2026-03-08T18:30:00.000Z", "created_at": "2026-03-09T08:57:27.247Z", "created_by": null, "ot_enabled": true, "product_id": 5, "updated_at": "2026-03-09T16:35:21.742Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": 1, "changeover_started_at": null, "incoming_target_units": 100}	{"id": 43, "line_id": 1, "is_locked": false, "work_date": "2026-03-08T18:30:00.000Z", "created_at": "2026-03-09T08:57:27.247Z", "created_by": null, "ot_enabled": true, "product_id": 5, "updated_at": "2026-03-09T16:47:02.585Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": 1, "changeover_started_at": null, "incoming_target_units": 100}	\N	2026-03-09 22:17:02.592188	\N	\N	\N	\N	\N	\N
44	line_daily_plans	46	create	\N	{"id": 46, "line_id": 2, "is_locked": false, "work_date": "2026-03-08T18:30:00.000Z", "created_at": "2026-03-09T17:24:07.476Z", "created_by": null, "ot_enabled": false, "product_id": 1, "updated_at": "2026-03-09T17:24:07.476Z", "updated_by": null, "target_units": 200, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": null, "changeover_started_at": null, "incoming_target_units": 0}	\N	2026-03-09 22:54:07.482446	\N	\N	\N	\N	\N	\N
45	line_daily_plans	43	update	{"id": 43, "line_id": 1, "is_locked": false, "work_date": "2026-03-08T18:30:00.000Z", "created_at": "2026-03-09T08:57:27.247Z", "created_by": null, "ot_enabled": true, "product_id": 5, "updated_at": "2026-03-09T16:47:02.585Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": 1, "changeover_started_at": null, "incoming_target_units": 100}	{"id": 43, "line_id": 1, "is_locked": false, "work_date": "2026-03-08T18:30:00.000Z", "created_at": "2026-03-09T08:57:27.247Z", "created_by": null, "ot_enabled": true, "product_id": 5, "updated_at": "2026-03-09T17:28:55.363Z", "updated_by": null, "target_units": 100, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": 1, "changeover_started_at": null, "incoming_target_units": 100}	\N	2026-03-09 22:58:55.37027	\N	\N	\N	\N	\N	\N
46	line_daily_plans	48	create	\N	{"id": 48, "line_id": 1, "is_locked": false, "work_date": "2026-03-09T18:30:00.000Z", "created_at": "2026-03-10T07:32:01.645Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-10T07:32:01.645Z", "updated_by": null, "target_units": 100, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": null, "changeover_started_at": null, "incoming_target_units": 0}	\N	2026-03-10 13:02:01.685142	\N	\N	\N	\N	\N	\N
47	line_daily_plans	48	update	{"id": 48, "line_id": 1, "is_locked": false, "work_date": "2026-03-09T18:30:00.000Z", "created_at": "2026-03-10T07:32:01.645Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-10T07:32:01.645Z", "updated_by": null, "target_units": 100, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": null, "changeover_started_at": null, "incoming_target_units": 0}	{"id": 48, "line_id": 1, "is_locked": false, "work_date": "2026-03-09T18:30:00.000Z", "created_at": "2026-03-10T07:32:01.645Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-10T08:20:58.714Z", "updated_by": null, "target_units": 100, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": null, "changeover_started_at": null, "incoming_target_units": 0}	\N	2026-03-10 13:50:58.721361	\N	\N	\N	\N	\N	\N
48	line_daily_plans	50	create	\N	{"id": 50, "line_id": 1, "is_locked": false, "work_date": "2026-03-15T18:30:00.000Z", "created_at": "2026-03-16T11:33:32.997Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-16T11:33:32.997Z", "updated_by": null, "target_units": 100, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": null, "changeover_started_at": null, "incoming_target_units": 0}	\N	2026-03-16 17:03:33.054749	\N	\N	\N	\N	\N	\N
49	line_daily_plans	51	create	\N	{"id": 51, "line_id": 1, "is_locked": false, "work_date": "2026-03-16T18:30:00.000Z", "created_at": "2026-03-17T14:11:41.756Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-17T14:11:41.756Z", "updated_by": null, "target_units": 100, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": 1, "changeover_started_at": null, "incoming_target_units": 100}	\N	2026-03-17 19:41:41.78848	\N	\N	\N	\N	\N	\N
50	line_daily_plans	52	create	\N	{"id": 52, "line_id": 1, "is_locked": false, "work_date": "2026-03-17T18:30:00.000Z", "created_at": "2026-03-18T11:03:56.101Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-18T11:03:56.101Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": null, "changeover_started_at": null, "incoming_target_units": 0}	\N	2026-03-18 16:33:56.131612	\N	\N	\N	\N	\N	\N
51	line_daily_plans	52	update	{"id": 52, "line_id": 1, "is_locked": false, "work_date": "2026-03-17T18:30:00.000Z", "created_at": "2026-03-18T11:03:56.101Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-18T11:03:56.101Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": null, "changeover_started_at": null, "incoming_target_units": 0}	{"id": 52, "line_id": 1, "is_locked": false, "work_date": "2026-03-17T18:30:00.000Z", "created_at": "2026-03-18T11:03:56.101Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-18T11:15:45.467Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": 1, "changeover_started_at": null, "incoming_target_units": 0}	\N	2026-03-18 16:45:45.475902	\N	\N	\N	\N	\N	\N
52	line_daily_plans	52	update	{"id": 52, "line_id": 1, "is_locked": false, "work_date": "2026-03-17T18:30:00.000Z", "created_at": "2026-03-18T11:03:56.101Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-18T11:15:45.467Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": 1, "changeover_started_at": null, "incoming_target_units": 0}	{"id": 52, "line_id": 1, "is_locked": false, "work_date": "2026-03-17T18:30:00.000Z", "created_at": "2026-03-18T11:03:56.101Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-18T11:19:40.141Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": 1, "changeover_started_at": null, "incoming_target_units": 200}	\N	2026-03-18 16:49:40.148542	\N	\N	\N	\N	\N	\N
53	line_daily_plans	52	update	{"id": 52, "line_id": 1, "is_locked": false, "work_date": "2026-03-17T18:30:00.000Z", "created_at": "2026-03-18T11:03:56.101Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-18T11:19:40.141Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": 1, "changeover_started_at": null, "incoming_target_units": 200}	{"id": 52, "line_id": 1, "is_locked": false, "work_date": "2026-03-17T18:30:00.000Z", "created_at": "2026-03-18T11:03:56.101Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-18T11:20:02.054Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": 1, "changeover_started_at": null, "incoming_target_units": 200}	\N	2026-03-18 16:50:02.058697	\N	\N	\N	\N	\N	\N
54	line_daily_plans	52	update	{"id": 52, "line_id": 1, "is_locked": false, "work_date": "2026-03-17T18:30:00.000Z", "created_at": "2026-03-18T11:03:56.101Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-18T11:20:02.054Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": 1, "changeover_started_at": null, "incoming_target_units": 200}	{"id": 52, "line_id": 1, "is_locked": false, "work_date": "2026-03-17T18:30:00.000Z", "created_at": "2026-03-18T11:03:56.101Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-18T11:20:04.046Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": 1, "changeover_started_at": null, "incoming_target_units": 200}	\N	2026-03-18 16:50:04.051963	\N	\N	\N	\N	\N	\N
55	line_daily_plans	57	create	\N	{"id": 57, "line_id": 1, "is_locked": false, "work_date": "2026-03-18T18:30:00.000Z", "created_at": "2026-03-19T06:59:21.425Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-19T06:59:21.425Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": null, "changeover_started_at": null, "incoming_target_units": 300}	\N	2026-03-19 12:29:21.470839	\N	\N	\N	\N	\N	\N
56	line_daily_plans	57	update	{"id": 57, "line_id": 1, "is_locked": false, "work_date": "2026-03-18T18:30:00.000Z", "created_at": "2026-03-19T06:59:21.425Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-19T06:59:21.425Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": null, "changeover_started_at": null, "incoming_target_units": 300}	{"id": 57, "line_id": 1, "is_locked": false, "work_date": "2026-03-18T18:30:00.000Z", "created_at": "2026-03-19T06:59:21.425Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-19T06:59:33.424Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": 1, "changeover_started_at": null, "incoming_target_units": 300}	\N	2026-03-19 12:29:33.429456	\N	\N	\N	\N	\N	\N
57	line_daily_plans	57	update	{"id": 57, "line_id": 1, "is_locked": false, "work_date": "2026-03-18T18:30:00.000Z", "created_at": "2026-03-19T06:59:21.425Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-19T06:59:33.424Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": 1, "changeover_started_at": null, "incoming_target_units": 300}	{"id": 57, "line_id": 1, "is_locked": false, "work_date": "2026-03-18T18:30:00.000Z", "created_at": "2026-03-19T06:59:21.425Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-19T06:59:35.121Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": 1, "changeover_started_at": null, "incoming_target_units": 300}	\N	2026-03-19 12:29:35.126333	\N	\N	\N	\N	\N	\N
58	line_daily_plans	57	update	{"id": 57, "line_id": 1, "is_locked": false, "work_date": "2026-03-18T18:30:00.000Z", "created_at": "2026-03-19T06:59:21.425Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-19T06:59:35.121Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": 1, "changeover_started_at": null, "incoming_target_units": 300}	{"id": 57, "line_id": 1, "is_locked": false, "work_date": "2026-03-18T18:30:00.000Z", "created_at": "2026-03-19T06:59:21.425Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-19T07:16:02.898Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": 4, "changeover_started_at": null, "incoming_target_units": 300}	\N	2026-03-19 12:46:02.918562	\N	\N	\N	\N	\N	\N
59	line_daily_plans	57	update	{"id": 57, "line_id": 1, "is_locked": false, "work_date": "2026-03-18T18:30:00.000Z", "created_at": "2026-03-19T06:59:21.425Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-19T07:16:02.898Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": 4, "changeover_started_at": null, "incoming_target_units": 300}	{"id": 57, "line_id": 1, "is_locked": false, "work_date": "2026-03-18T18:30:00.000Z", "created_at": "2026-03-19T06:59:21.425Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-19T07:16:15.414Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": 2, "changeover_started_at": null, "incoming_target_units": 300}	\N	2026-03-19 12:46:15.428958	\N	\N	\N	\N	\N	\N
60	line_daily_plans	57	update	{"id": 57, "line_id": 1, "is_locked": false, "work_date": "2026-03-18T18:30:00.000Z", "created_at": "2026-03-19T06:59:21.425Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-19T07:16:15.414Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": 2, "changeover_started_at": null, "incoming_target_units": 300}	{"id": 57, "line_id": 1, "is_locked": false, "work_date": "2026-03-18T18:30:00.000Z", "created_at": "2026-03-19T06:59:21.425Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-19T07:19:37.590Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": 3, "changeover_started_at": null, "incoming_target_units": 300}	\N	2026-03-19 12:49:37.617148	\N	\N	\N	\N	\N	\N
61	line_daily_plans	57	update	{"id": 57, "line_id": 1, "is_locked": false, "work_date": "2026-03-18T18:30:00.000Z", "created_at": "2026-03-19T06:59:21.425Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-19T07:19:37.590Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": 3, "changeover_started_at": null, "incoming_target_units": 300}	{"id": 57, "line_id": 1, "is_locked": false, "work_date": "2026-03-18T18:30:00.000Z", "created_at": "2026-03-19T06:59:21.425Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-19T07:19:45.856Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": 2, "changeover_started_at": null, "incoming_target_units": 300}	\N	2026-03-19 12:49:45.908813	\N	\N	\N	\N	\N	\N
62	line_daily_plans	57	update	{"id": 57, "line_id": 1, "is_locked": false, "work_date": "2026-03-18T18:30:00.000Z", "created_at": "2026-03-19T06:59:21.425Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-19T07:19:45.856Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": 2, "changeover_started_at": null, "incoming_target_units": 300}	{"id": 57, "line_id": 1, "is_locked": false, "work_date": "2026-03-18T18:30:00.000Z", "created_at": "2026-03-19T06:59:21.425Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-19T07:35:01.307Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": 2, "changeover_started_at": null, "incoming_target_units": 300}	\N	2026-03-19 13:05:01.314926	\N	\N	\N	\N	\N	\N
63	line_daily_plans	67	create	\N	{"id": 67, "line_id": 1, "is_locked": false, "work_date": "2026-03-19T18:30:00.000Z", "created_at": "2026-03-20T08:58:07.019Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-20T08:58:07.019Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": null, "changeover_started_at": null, "incoming_target_units": 0}	\N	2026-03-20 14:28:07.026807	\N	\N	\N	\N	\N	\N
64	line_daily_plans	67	update	{"id": 67, "line_id": 1, "is_locked": false, "work_date": "2026-03-19T18:30:00.000Z", "created_at": "2026-03-20T08:58:07.019Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-20T08:58:07.019Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": null, "changeover_started_at": null, "incoming_target_units": 0}	{"id": 67, "line_id": 1, "is_locked": false, "work_date": "2026-03-19T18:30:00.000Z", "created_at": "2026-03-20T08:58:07.019Z", "created_by": null, "ot_enabled": false, "product_id": 5, "updated_at": "2026-03-20T16:19:57.400Z", "updated_by": null, "target_units": 500, "overtime_target": 0, "overtime_minutes": 0, "changeover_sequence": 0, "incoming_product_id": null, "changeover_started_at": null, "incoming_target_units": 0}	\N	2026-03-20 21:49:57.407055	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: defect_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.defect_log (id, line_id, process_id, employee_id, defect_type_id, work_date, hour_slot, quantity, status, rework_employee_id, rework_completed_at, notes, detected_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: defect_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.defect_types (id, defect_code, defect_name, defect_category, severity, is_reworkable, description, is_active, created_at, updated_at) FROM stdin;
1	ST001	Broken Stitch	stitching	minor	t	\N	t	2026-02-04 17:19:42.345194	2026-02-04 17:19:42.345194
2	ST002	Skip Stitch	stitching	minor	t	\N	t	2026-02-04 17:19:42.345194	2026-02-04 17:19:42.345194
3	ST003	Loose Stitch	stitching	minor	t	\N	t	2026-02-04 17:19:42.345194	2026-02-04 17:19:42.345194
4	ST004	Wrong Thread Color	stitching	major	t	\N	t	2026-02-04 17:19:42.345194	2026-02-04 17:19:42.345194
5	ST005	Uneven Stitch Line	stitching	minor	t	\N	t	2026-02-04 17:19:42.345194	2026-02-04 17:19:42.345194
6	MT001	Material Tear	material	major	f	\N	t	2026-02-04 17:19:42.345194	2026-02-04 17:19:42.345194
7	MT002	Material Stain	material	minor	t	\N	t	2026-02-04 17:19:42.345194	2026-02-04 17:19:42.345194
8	MT003	Wrong Material	material	critical	f	\N	t	2026-02-04 17:19:42.345194	2026-02-04 17:19:42.345194
9	MT004	Color Variation	material	major	f	\N	t	2026-02-04 17:19:42.345194	2026-02-04 17:19:42.345194
10	FN001	Edge Damage	finishing	minor	t	\N	t	2026-02-04 17:19:42.345194	2026-02-04 17:19:42.345194
11	FN002	Improper Folding	finishing	minor	t	\N	t	2026-02-04 17:19:42.345194	2026-02-04 17:19:42.345194
12	FN003	Glue Marks	finishing	minor	t	\N	t	2026-02-04 17:19:42.345194	2026-02-04 17:19:42.345194
13	FN004	Misalignment	finishing	minor	t	\N	t	2026-02-04 17:19:42.345194	2026-02-04 17:19:42.345194
14	QA001	Dimension Error	quality	major	t	\N	t	2026-02-04 17:19:42.345194	2026-02-04 17:19:42.345194
15	QA002	Missing Component	quality	critical	t	\N	t	2026-02-04 17:19:42.345194	2026-02-04 17:19:42.345194
16	QA003	Wrong Specification	quality	critical	f	\N	t	2026-02-04 17:19:42.345194	2026-02-04 17:19:42.345194
\.


--
-- Data for Name: downtime_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.downtime_log (id, line_id, reason_id, work_date, start_time, end_time, duration_minutes, affected_processes, notes, reported_by, resolved_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: downtime_reasons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.downtime_reasons (id, reason_code, reason_name, reason_category, is_planned, default_duration_minutes, description, is_active, created_at, updated_at) FROM stdin;
1	MC001	Machine Breakdown	machine	f	30	\N	t	2026-02-04 17:19:42.347664	2026-02-04 17:19:42.347664
2	MC002	Machine Maintenance	machine	t	60	\N	t	2026-02-04 17:19:42.347664	2026-02-04 17:19:42.347664
3	MC003	Needle Change	machine	f	5	\N	t	2026-02-04 17:19:42.347664	2026-02-04 17:19:42.347664
4	MC004	Thread Break	machine	f	5	\N	t	2026-02-04 17:19:42.347664	2026-02-04 17:19:42.347664
5	MC005	Machine Setup	machine	t	15	\N	t	2026-02-04 17:19:42.347664	2026-02-04 17:19:42.347664
6	MT001	Material Shortage	material	f	30	\N	t	2026-02-04 17:19:42.347664	2026-02-04 17:19:42.347664
7	MT002	Material Quality Issue	material	f	20	\N	t	2026-02-04 17:19:42.347664	2026-02-04 17:19:42.347664
8	MT003	Waiting for Material	material	f	15	\N	t	2026-02-04 17:19:42.347664	2026-02-04 17:19:42.347664
9	MP001	Operator Absent	manpower	f	\N	\N	t	2026-02-04 17:19:42.347664	2026-02-04 17:19:42.347664
10	MP002	Operator Training	manpower	t	60	\N	t	2026-02-04 17:19:42.347664	2026-02-04 17:19:42.347664
11	MP003	Break Time	manpower	t	15	\N	t	2026-02-04 17:19:42.347664	2026-02-04 17:19:42.347664
12	MP004	Meeting	manpower	t	30	\N	t	2026-02-04 17:19:42.347664	2026-02-04 17:19:42.347664
13	PL001	No Production Plan	planning	f	\N	\N	t	2026-02-04 17:19:42.347664	2026-02-04 17:19:42.347664
14	PL002	Style Change	planning	t	30	\N	t	2026-02-04 17:19:42.347664	2026-02-04 17:19:42.347664
15	PL003	Line Balancing	planning	t	20	\N	t	2026-02-04 17:19:42.347664	2026-02-04 17:19:42.347664
16	OT001	Power Outage	other	f	\N	\N	t	2026-02-04 17:19:42.347664	2026-02-04 17:19:42.347664
17	OT002	Quality Hold	other	f	\N	\N	t	2026-02-04 17:19:42.347664	2026-02-04 17:19:42.347664
18	OT003	Other	other	f	\N	\N	t	2026-02-04 17:19:42.347664	2026-02-04 17:19:42.347664
\.


--
-- Data for Name: employee_attendance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_attendance (id, employee_id, attendance_date, in_time, out_time, status, notes, created_at, updated_at) FROM stdin;
1	2	2026-01-15	19:17:00	17:00:00	present	Supervisor scan	2026-01-15 19:17:25.090225	2026-01-15 19:17:43.915993
5	69	2026-01-15	19:18:00	17:00:00	present	Supervisor scan	2026-01-15 19:18:30.616213	2026-01-15 19:18:30.616213
6	69	2026-01-21	17:14:00	17:00:00	present	Supervisor scan	2026-01-21 17:14:43.642547	2026-01-21 17:14:43.642547
7	2	2026-01-21	17:20:00	17:00:00	present	Supervisor scan	2026-01-21 17:20:39.886451	2026-01-21 17:42:50.768353
13	2	2026-01-22	18:12:00	17:00:00	present	Supervisor scan	2026-01-22 18:12:21.442881	2026-01-22 18:18:28.963088
15	8	2026-02-04	20:39:00	17:00:00	present	Supervisor scan	2026-02-04 20:39:30.28758	2026-02-04 20:39:30.28758
16	61	2026-02-05	14:26:00	17:00:00	present	Supervisor scan	2026-02-05 14:26:51.47733	2026-02-05 14:26:51.47733
17	64	2026-02-05	14:29:00	17:00:00	present	Supervisor scan	2026-02-05 14:29:42.720202	2026-02-05 14:29:42.720202
18	120	2026-02-10	15:29:00	17:00:00	present	Supervisor scan	2026-02-10 15:29:26.152107	2026-02-10 15:29:26.152107
19	67	2026-02-13	16:32:00	17:00:00	present	Supervisor scan	2026-02-13 16:32:39.592351	2026-02-13 16:32:39.592351
\.


--
-- Data for Name: employee_process_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_process_assignments (id, process_id, employee_id, assigned_at, line_id) FROM stdin;
250	6	2	2026-02-05 14:12:22.239835	1
253	78	120	2026-02-10 15:09:17.421026	1
254	78	60	2026-02-10 15:09:25.021165	2
256	80	67	2026-02-13 16:26:16.323642	2
240	77	144	2026-01-15 14:17:49.930071	\N
252	6	58	2026-02-05 14:58:06.096837	\N
255	78	62	2026-02-10 15:09:30.962496	\N
251	6	64	2026-02-05 14:29:42.720202	2
163	77	1	2026-01-15 13:38:23.96625	1
165	7	3	2026-01-15 13:38:30.529735	2
166	8	4	2026-01-15 13:39:30.154719	2
167	9	5	2026-01-15 13:39:31.617343	2
168	10	6	2026-01-15 13:39:33.370279	2
169	11	7	2026-01-15 13:39:35.51379	2
170	12	9	2026-01-15 13:39:39.865374	2
171	13	8	2026-01-15 13:39:42.083569	2
173	14	11	2026-01-15 13:39:46.930149	2
174	15	10	2026-01-15 13:39:48.320966	2
175	16	12	2026-01-15 13:39:49.914512	2
176	17	13	2026-01-15 13:39:51.433232	2
177	18	14	2026-01-15 13:39:53.169544	2
178	19	15	2026-01-15 13:39:55.806912	2
179	20	16	2026-01-15 13:39:57.081813	2
180	21	17	2026-01-15 13:39:58.394292	2
181	22	18	2026-01-15 13:39:59.963183	2
182	23	19	2026-01-15 13:40:01.248901	2
185	24	20	2026-01-15 13:40:05.584784	2
187	25	21	2026-01-15 13:40:08.060883	2
188	26	22	2026-01-15 13:40:09.890208	2
189	27	23	2026-01-15 13:40:11.37747	2
190	28	24	2026-01-15 13:40:13.7303	2
191	29	25	2026-01-15 13:40:15.577528	2
192	30	26	2026-01-15 13:40:18.023101	2
193	31	27	2026-01-15 13:40:19.453374	2
194	32	28	2026-01-15 13:40:20.665068	2
195	33	29	2026-01-15 13:40:22.065827	2
196	34	30	2026-01-15 13:40:26.082791	2
197	35	31	2026-01-15 13:40:27.529421	2
198	36	32	2026-01-15 13:40:29.313358	2
199	37	33	2026-01-15 13:40:31.987128	2
200	38	34	2026-01-15 13:40:33.913239	2
201	39	35	2026-01-15 13:40:35.273751	2
202	40	36	2026-01-15 13:40:36.602593	2
203	41	37	2026-01-15 13:40:37.798827	2
204	42	38	2026-01-15 13:40:39.320909	2
205	43	39	2026-01-15 13:40:40.657208	2
206	44	40	2026-01-15 13:40:49.628646	2
207	45	41	2026-01-15 13:40:51.385288	2
208	46	42	2026-01-15 13:40:53.369432	2
209	47	106	2026-01-15 13:40:54.937788	2
210	48	107	2026-01-15 13:40:56.169218	2
211	49	43	2026-01-15 13:40:57.753334	2
212	50	44	2026-01-15 13:41:00.001063	2
213	51	45	2026-01-15 13:41:02.863768	2
214	52	46	2026-01-15 13:41:06.016245	2
215	53	47	2026-01-15 13:41:09.631818	2
216	54	48	2026-01-15 13:41:11.453831	2
217	55	49	2026-01-15 13:41:12.898036	2
218	56	50	2026-01-15 13:41:15.986052	2
219	57	108	2026-01-15 13:41:18.449738	2
220	58	109	2026-01-15 13:41:20.619563	2
221	59	110	2026-01-15 13:41:22.092783	2
222	60	111	2026-01-15 13:41:24.201446	2
223	61	112	2026-01-15 13:41:26.738302	2
224	62	113	2026-01-15 13:41:29.835744	2
225	63	114	2026-01-15 13:41:32.062413	2
226	64	115	2026-01-15 13:41:33.865993	2
227	65	116	2026-01-15 13:41:35.433314	2
228	66	117	2026-01-15 13:41:37.249491	2
229	67	51	2026-01-15 13:41:39.033259	2
230	68	52	2026-01-15 13:41:41.688247	2
231	69	53	2026-01-15 13:41:43.369239	2
232	70	54	2026-01-15 13:41:54.405603	2
233	71	118	2026-01-15 13:41:56.241208	2
234	72	55	2026-01-15 13:41:58.56986	2
235	73	119	2026-01-15 13:42:00.20832	2
236	74	56	2026-01-15 13:42:01.64186	2
237	75	57	2026-01-15 13:42:05.83455	2
238	76	59	2026-01-15 13:42:09.761262	2
\.


--
-- Data for Name: employee_workstation_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_workstation_assignments (id, line_id, workstation_code, employee_id, assigned_at, work_date, line_plan_workstation_id, is_overtime, material_provided, is_linked) FROM stdin;
338	1	W1	1	2026-03-19 13:15:46.433876	2026-03-19	333	f	\N	f
347	1	W10	10	2026-03-19 13:15:46.482655	2026-03-19	342	f	\N	f
339	1	W2	2	2026-03-19 13:15:46.441613	2026-03-19	334	f	\N	f
340	1	W3	3	2026-03-19 13:15:46.446292	2026-03-19	335	f	\N	f
341	1	W4	4	2026-03-19 13:15:46.451322	2026-03-19	336	f	\N	f
342	1	W5	5	2026-03-19 13:15:46.456178	2026-03-19	337	f	\N	f
343	1	W6	6	2026-03-19 13:15:46.461047	2026-03-19	338	f	\N	f
344	1	W7	7	2026-03-19 13:15:46.466374	2026-03-19	339	f	\N	f
345	1	W8	8	2026-03-19 13:15:46.473733	2026-03-19	340	f	\N	f
346	1	W9	9	2026-03-19 13:15:46.478236	2026-03-19	341	f	\N	f
318	1	W1	1	2026-03-18 17:04:39.276363	2026-03-18	311	f	\N	f
319	1	W2	2	2026-03-18 17:04:39.284487	2026-03-18	312	f	\N	f
320	1	W3	3	2026-03-18 17:04:39.289336	2026-03-18	313	f	\N	f
321	1	W4	4	2026-03-18 17:04:39.293556	2026-03-18	314	f	\N	f
322	1	W5	5	2026-03-18 17:04:39.298075	2026-03-18	315	f	\N	f
323	1	W6	6	2026-03-18 17:04:39.303376	2026-03-18	316	f	\N	f
324	1	W7	7	2026-03-18 17:04:39.308134	2026-03-18	317	f	\N	f
325	1	W8	8	2026-03-18 17:04:39.31503	2026-03-18	318	f	\N	f
326	1	W9	9	2026-03-18 17:04:39.32028	2026-03-18	319	f	\N	f
327	1	W10	10	2026-03-18 17:04:39.32482	2026-03-18	320	f	\N	f
237	1	W2	2	2026-03-16 17:03:33.167134	2026-03-16	204	f	\N	f
238	1	W3	3	2026-03-16 17:03:33.189943	2026-03-16	205	f	\N	f
239	1	W4	4	2026-03-16 17:03:33.219314	2026-03-16	206	f	\N	f
240	1	W5	5	2026-03-16 17:03:33.242004	2026-03-16	207	f	\N	f
241	1	W6	6	2026-03-16 17:03:33.2651	2026-03-16	208	f	\N	f
242	1	W7	7	2026-03-16 17:03:33.286334	2026-03-16	209	f	\N	f
243	1	W8	8	2026-03-16 17:03:33.307638	2026-03-16	210	f	\N	f
244	1	W9	9	2026-03-16 17:03:33.329379	2026-03-16	211	f	\N	f
245	1	W10	10	2026-03-16 17:03:33.354086	2026-03-16	212	f	\N	f
236	1	W1	1	2026-03-16 17:06:16.853927	2026-03-16	203	f	100	f
267	1	W1	1	2026-03-17 19:54:26.484289	2026-03-17	223	t	\N	f
268	1	W10	10	2026-03-17 19:54:26.484289	2026-03-17	232	t	\N	f
269	1	W2	2	2026-03-17 19:54:26.484289	2026-03-17	224	t	\N	f
270	1	W3	3	2026-03-17 19:54:26.484289	2026-03-17	225	t	\N	f
271	1	W4	4	2026-03-17 19:54:26.484289	2026-03-17	226	t	\N	f
272	1	W5	5	2026-03-17 19:54:26.484289	2026-03-17	227	t	\N	f
273	1	W6	6	2026-03-17 19:54:26.484289	2026-03-17	228	t	\N	f
274	1	W7	7	2026-03-17 19:54:26.484289	2026-03-17	229	t	\N	f
275	1	W8	8	2026-03-17 19:54:26.484289	2026-03-17	230	t	\N	f
276	1	W9	9	2026-03-17 19:54:26.484289	2026-03-17	231	t	\N	f
371	15	WS01	93	2026-03-20 21:09:44.355815	2026-03-20	401	f	\N	f
95	1	W1	1	2026-03-06 14:07:05.716334	2026-03-06	87	f	\N	f
96	1	W2	2	2026-03-06 14:07:05.746726	2026-03-06	88	f	\N	f
97	1	W3	3	2026-03-06 14:07:05.77361	2026-03-06	89	f	\N	f
98	1	W4	4	2026-03-06 14:07:05.797284	2026-03-06	90	f	\N	f
99	1	W5	5	2026-03-06 14:07:05.822294	2026-03-06	91	f	\N	f
100	1	W6	6	2026-03-06 14:07:05.832801	2026-03-06	92	f	\N	f
101	1	W7	7	2026-03-06 14:07:05.860988	2026-03-06	93	f	\N	f
102	1	W8	8	2026-03-06 14:07:05.928476	2026-03-06	94	f	\N	f
103	1	W9	9	2026-03-06 14:07:06.001285	2026-03-06	95	f	\N	f
104	1	W10	10	2026-03-06 14:07:06.06429	2026-03-06	96	f	\N	f
105	1	W1	1	2026-03-06 14:07:21.293914	2026-03-06	87	t	\N	f
106	1	W2	2	2026-03-06 14:07:21.293914	2026-03-06	88	t	\N	f
107	1	W3	3	2026-03-06 14:07:21.293914	2026-03-06	89	t	\N	f
108	1	W4	4	2026-03-06 14:07:21.293914	2026-03-06	90	t	\N	f
109	1	W5	5	2026-03-06 14:07:21.293914	2026-03-06	91	t	\N	f
110	1	W6	6	2026-03-06 14:07:21.293914	2026-03-06	92	t	\N	f
111	1	W7	7	2026-03-06 14:07:21.293914	2026-03-06	93	t	\N	f
112	1	W8	8	2026-03-06 14:07:21.293914	2026-03-06	94	t	\N	f
113	1	W9	9	2026-03-06 14:07:21.293914	2026-03-06	95	t	\N	f
114	1	W10	10	2026-03-06 14:07:21.293914	2026-03-06	96	t	\N	f
28	1	W1	1	2026-02-19 21:25:32.440232	2026-02-19	28	f	\N	f
29	1	W2	3	2026-02-19 21:25:32.446503	2026-02-19	29	f	\N	f
30	1	W3	2	2026-02-19 21:25:32.452742	2026-02-19	30	f	\N	f
31	1	W4	4	2026-02-19 21:25:32.458643	2026-02-19	31	f	\N	f
33	1	W6	6	2026-02-19 21:25:32.476856	2026-02-19	33	f	\N	f
34	1	W7	8	2026-02-19 21:25:32.481514	2026-02-19	34	f	\N	f
36	1	W1	1	2026-02-22 14:46:10.829617	2026-02-22	50	f	\N	f
37	1	W2	2	2026-02-22 14:46:10.837264	2026-02-22	51	f	\N	f
38	1	W1	3	2026-02-22 14:46:28.895668	2026-02-22	50	t	\N	f
39	1	W2	1	2026-02-22 14:46:28.900045	2026-02-22	51	t	\N	f
32	1	W5	5	2026-02-19 21:25:32.472087	2026-02-19	32	f	\N	f
40	1	W1	1	2026-02-28 20:52:54.796634	2026-02-28	57	f	\N	f
41	1	W2	2	2026-02-28 20:52:54.804883	2026-02-28	58	f	\N	f
42	1	W3	3	2026-02-28 20:52:54.810276	2026-02-28	59	f	\N	f
43	1	W4	4	2026-02-28 20:52:54.823483	2026-02-28	60	f	\N	f
44	1	W5	5	2026-02-28 20:52:54.828821	2026-02-28	61	f	\N	f
45	1	W6	6	2026-02-28 20:52:54.834278	2026-02-28	62	f	\N	f
46	1	W7	7	2026-02-28 20:52:54.839239	2026-02-28	63	f	\N	f
47	1	W8	8	2026-02-28 20:52:54.846976	2026-02-28	64	f	\N	f
48	1	W9	9	2026-02-28 20:52:54.851289	2026-02-28	65	f	\N	f
49	1	W10	10	2026-02-28 20:52:54.855899	2026-02-28	66	f	\N	f
50	1	W1	1	2026-03-02 14:46:59.278165	2026-03-02	\N	f	\N	f
51	1	W2	2	2026-03-02 14:46:59.280864	2026-03-02	\N	f	\N	f
52	1	W3	3	2026-03-02 14:46:59.282796	2026-03-02	\N	f	\N	f
53	1	W4	4	2026-03-02 14:46:59.284593	2026-03-02	\N	f	\N	f
54	1	W5	5	2026-03-02 14:46:59.286404	2026-03-02	\N	f	\N	f
55	1	W6	6	2026-03-02 14:46:59.2883	2026-03-02	\N	f	\N	f
56	1	W7	7	2026-03-02 14:46:59.289912	2026-03-02	\N	f	\N	f
57	1	W8	8	2026-03-02 14:46:59.291592	2026-03-02	\N	f	\N	f
58	1	W9	9	2026-03-02 14:46:59.2931	2026-03-02	\N	f	\N	f
59	1	W10	10	2026-03-02 14:46:59.294584	2026-03-02	\N	f	\N	f
360	1	W1	1	2026-03-20 14:28:07.046201	2026-03-20	367	f	\N	f
72	1	W3	3	2026-03-02 17:36:18.853978	2026-03-02	79	t	\N	f
73	1	W4	4	2026-03-02 17:36:18.853978	2026-03-02	80	t	\N	f
74	1	W5	5	2026-03-02 17:36:18.853978	2026-03-02	81	t	\N	f
75	1	W6	6	2026-03-02 17:36:18.853978	2026-03-02	82	t	\N	f
76	1	W7	7	2026-03-02 17:36:18.853978	2026-03-02	83	t	\N	f
77	1	W8	8	2026-03-02 17:36:18.853978	2026-03-02	84	t	\N	f
78	1	W9	9	2026-03-02 17:36:18.853978	2026-03-02	85	t	\N	f
79	1	W10	10	2026-03-02 17:36:18.853978	2026-03-02	86	t	\N	f
93	1	W1	78	2026-03-02 18:06:16.468386	2026-03-02	\N	t	\N	f
94	1	W2	93	2026-03-02 18:06:21.758743	2026-03-02	\N	t	\N	f
361	1	W2	2	2026-03-20 14:28:07.052384	2026-03-20	368	f	\N	f
362	1	W3	3	2026-03-20 14:28:07.057664	2026-03-20	369	f	\N	f
363	1	W4	4	2026-03-20 14:28:07.064419	2026-03-20	370	f	\N	f
175	1	W1	1	2026-03-09 22:30:37.9012	2026-03-09	150	f	\N	f
176	1	W2	2	2026-03-09 22:30:37.907728	2026-03-09	151	f	\N	f
177	1	W3	3	2026-03-09 22:30:37.912624	2026-03-09	152	f	\N	f
178	1	W4	4	2026-03-09 22:30:37.919438	2026-03-09	153	f	\N	f
179	1	W5	5	2026-03-09 22:30:37.926517	2026-03-09	154	f	\N	f
180	1	W6	6	2026-03-09 22:30:37.932027	2026-03-09	155	f	\N	f
181	1	W7	7	2026-03-09 22:30:37.936658	2026-03-09	156	f	\N	f
182	1	W8	8	2026-03-09 22:30:37.946199	2026-03-09	157	f	\N	f
183	1	W9	9	2026-03-09 22:30:37.952205	2026-03-09	158	f	\N	f
184	1	W10	10	2026-03-09 22:30:37.956759	2026-03-09	159	f	\N	f
364	1	W5	5	2026-03-20 14:28:07.07004	2026-03-20	371	f	\N	f
365	1	W6	6	2026-03-20 14:28:07.077177	2026-03-20	372	f	\N	f
226	1	W1	1	2026-03-10 14:58:50.812007	2026-03-10	193	f	\N	f
227	1	W2	2	2026-03-10 14:58:50.819167	2026-03-10	194	f	\N	f
228	1	W3	3	2026-03-10 14:58:50.824523	2026-03-10	195	f	\N	f
229	1	W4	4	2026-03-10 14:58:50.830111	2026-03-10	196	f	\N	f
230	1	W5	5	2026-03-10 14:58:50.835371	2026-03-10	197	f	\N	f
231	1	W6	6	2026-03-10 14:58:50.840504	2026-03-10	198	f	\N	f
232	1	W7	7	2026-03-10 14:58:50.845755	2026-03-10	199	f	\N	f
233	1	W8	8	2026-03-10 14:58:50.85375	2026-03-10	200	f	\N	f
234	1	W9	9	2026-03-10 14:58:50.858343	2026-03-10	201	f	\N	f
235	1	W10	10	2026-03-10 14:58:50.863123	2026-03-10	202	f	\N	f
258	1	W2	2	2026-03-17 19:48:02.017837	2026-03-17	224	f	\N	f
259	1	W3	3	2026-03-17 19:48:02.022738	2026-03-17	225	f	\N	f
260	1	W4	4	2026-03-17 19:48:02.028303	2026-03-17	226	f	\N	f
261	1	W5	5	2026-03-17 19:48:02.033092	2026-03-17	227	f	\N	f
262	1	W6	6	2026-03-17 19:48:02.037988	2026-03-17	228	f	\N	f
263	1	W7	7	2026-03-17 19:48:02.042737	2026-03-17	229	f	\N	f
264	1	W8	8	2026-03-17 19:48:02.050055	2026-03-17	230	f	\N	f
265	1	W9	9	2026-03-17 19:48:02.054406	2026-03-17	231	f	\N	f
266	1	W10	10	2026-03-17 19:48:02.059283	2026-03-17	232	f	\N	f
257	1	W1	1	2026-03-17 20:14:59.812621	2026-03-17	223	f	100	f
366	1	W7	7	2026-03-20 14:28:07.082034	2026-03-20	373	f	\N	f
367	1	W8	8	2026-03-20 14:28:07.08699	2026-03-20	374	f	\N	f
368	1	W9	9	2026-03-20 14:28:07.092033	2026-03-20	375	f	\N	f
369	1	W10	10	2026-03-20 14:28:07.096764	2026-03-20	376	f	\N	f
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employees (id, emp_code, emp_name, designation, default_line_id, qr_code_path, is_active, created_at, updated_at, created_by, updated_by, manpower_factor) FROM stdin;
144	LPD9801	ILYAS	NONE	\N	qrcodes/employees/employee_144.png	t	2026-01-15 14:05:29.041393	2026-01-15 14:16:54.785923	\N	\N	1
145	LPD123456	Test Name	\N	\N	qrcodes/employees/employee_145.png	t	2026-02-05 14:54:34.907287	2026-02-05 14:54:34.907287	\N	\N	1
81	LPD12236	S. UMA	Associate	1	qrcodes/employees/employee_81.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
104	LPDS95742	SUGUNA	Table Worker	1	qrcodes/employees/employee_104.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
119	LPD10281	MD. SHAMIM AHAMAD	Stitcher	2	qrcodes/employees/employee_119.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
136	LPD12254	RABIUL MOLLA	Table Worker	2	qrcodes/employees/employee_136.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
1	LPD00059	A. NOORUN	Lw M/C Optr	1	qrcodes/employees/employee_1.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
2	LPD00334	R. VASANTHI	Stitcher	1	qrcodes/employees/employee_2.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
3	LPD00601	A. SADIKHA	Table Worker	1	qrcodes/employees/employee_3.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
4	LPD01253	G. SARASWATHI	Table Worker	1	qrcodes/employees/employee_4.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
5	LPD02946	A. ALEMELU	Lw M/C Optr	1	qrcodes/employees/employee_5.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
6	LPD03298	G. PADMINI	Table Worker	1	qrcodes/employees/employee_6.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
7	LPD04519	G. MANIMALA	Stitcher	1	qrcodes/employees/employee_7.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
8	LPD04803	S. RAJASHWARI	Table Worker	1	qrcodes/employees/employee_8.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
9	LPD04804	V. MEENATCHI	Table Worker	1	qrcodes/employees/employee_9.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
10	LPD04824	P. LOGANAYAGI	Stitcher	1	qrcodes/employees/employee_10.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
11	LPD05183	R. SRI DEVI	Table Worker	1	qrcodes/employees/employee_11.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
12	LPD05609	M. GOWRI	Table Worker	1	qrcodes/employees/employee_12.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
13	LPD05920	S. PARMESHWARI	Table Worker	1	qrcodes/employees/employee_13.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
14	LPD06518	M. ANITHA	Table Worker	1	qrcodes/employees/employee_14.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
15	LPD07392	V.P. MUBARAK	Lw M/C Optr	1	qrcodes/employees/employee_15.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
16	LPD07459	S. VIJAYA	Edge Inking	1	qrcodes/employees/employee_16.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
17	LPD07479	A. CHANMA	Table Worker	1	qrcodes/employees/employee_17.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
29	LPD08204	P. ANITHA	Edge Inking	1	qrcodes/employees/employee_29.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
46	LPD09683	GIRIJA	Table Worker	1	qrcodes/employees/employee_46.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
64	LPD11181	SALLUBANU	Hw M/C Optr	1	qrcodes/employees/employee_64.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
79	LPD11988	F GULZAR	Edge Inking	1	qrcodes/employees/employee_79.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
20	LPD07590	D. LATHA	Stitcher	1	qrcodes/employees/employee_20.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
21	LPD07628	GNANAMMAL	Edge Inking	1	qrcodes/employees/employee_21.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
22	LPD07785	S. RANI	Table Worker	1	qrcodes/employees/employee_22.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
23	LPD07789	R. KAVITHA	Edge Inking	1	qrcodes/employees/employee_23.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
24	LPD07870	M. NIROSHA	Edge Inking	1	qrcodes/employees/employee_24.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
25	LPD07950	S. RAHIMUNNISA	Lw M/C Optr	1	qrcodes/employees/employee_25.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
26	LPD08048	S. RIYAZ	Hw M/C Optr	1	qrcodes/employees/employee_26.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
27	LPD08118	D. SUREKA	Stitcher	1	qrcodes/employees/employee_27.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
28	LPD08142	M. MUMTAJ	Stitcher	1	qrcodes/employees/employee_28.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
30	LPD08268	VASANTHI	Edge Inking	1	qrcodes/employees/employee_30.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
31	LPD08305	S. SUDHA	Table Worker	1	qrcodes/employees/employee_31.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
32	LPD08346	M. KHADAR BEE	Table Worker	1	qrcodes/employees/employee_32.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
33	LPD08372	JAYANTHI	Edge Inking	1	qrcodes/employees/employee_33.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
34	LPD08441	ESWARI	Hw M/C Optr	1	qrcodes/employees/employee_34.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
35	LPD08486	SASIKALA	Edge Inking	1	qrcodes/employees/employee_35.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
36	LPD08506	AYESHA	Table Worker	1	qrcodes/employees/employee_36.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
37	LPD08523	DEVI	Table Worker	1	qrcodes/employees/employee_37.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
38	LPD08619	SHARFUDDIN	Ams Stitcher	1	qrcodes/employees/employee_38.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
39	LPD08664	ANITHA	Table Worker	1	qrcodes/employees/employee_39.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
40	LPD08685	Z. NAYEEMUNNISA	Stitcher	1	qrcodes/employees/employee_40.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
41	LPD08744	S.L. LAKSHMI	Table Worker	1	qrcodes/employees/employee_41.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
42	LPD08891	UMA MAHESWARI	Table Worker	1	qrcodes/employees/employee_42.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
43	LPD09146	ALAMELU	Edge Inking	1	qrcodes/employees/employee_43.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
44	LPD09393	M. USHA RANI	Table Worker	1	qrcodes/employees/employee_44.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
45	LPD09605	REKHA	Stitcher	1	qrcodes/employees/employee_45.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
47	LPD09689	SARANYA	Stitcher	1	qrcodes/employees/employee_47.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
48	LPD09702	DEVI	Stitcher	1	qrcodes/employees/employee_48.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
49	LPD09907	RIZWAN	Hw M/C Optr	1	qrcodes/employees/employee_49.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
50	LPD09910	JABINA BANU	Ams Stitcher	1	qrcodes/employees/employee_50.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
51	LPD10183	M. KALAIMATHI	Stitcher	1	qrcodes/employees/employee_51.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
52	LPD10197	M. GIRIJA	Stitcher	1	qrcodes/employees/employee_52.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
53	LPD10209	HAJEERA	Stitcher	1	qrcodes/employees/employee_53.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
54	LPD10251	JAYACHITRA	Table Worker	1	qrcodes/employees/employee_54.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
55	LPD10276	PARVEEN	Stitcher	1	qrcodes/employees/employee_55.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
56	LPD10419	A. FARHANA BEGAM	Stitcher	1	qrcodes/employees/employee_56.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
57	LPD10455	THAMRIN	Edge Inking	1	qrcodes/employees/employee_57.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
58	LPD10561	G. SELVARANI	Table Worker	1	qrcodes/employees/employee_58.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
59	LPD10617	ANJALI	Table Worker	1	qrcodes/employees/employee_59.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
60	LPD10916	N. JAYACHITRA	Table Worker	1	qrcodes/employees/employee_60.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
61	LPD10967	K. SHANTHI	Table Worker	1	qrcodes/employees/employee_61.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
62	LPD11088	Y. ALMAS BEGUM	Edge Inking	1	qrcodes/employees/employee_62.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
63	LPD11153	SHAINAN	Edge Inking	1	qrcodes/employees/employee_63.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
65	LPD11183	M. RIZWANA	Ams Stitcher	1	qrcodes/employees/employee_65.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
66	LPD11187	SUJATHA	Edge Inking	1	qrcodes/employees/employee_66.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
67	LPD11204	MAHALAKSHMI	Edge Inking	1	qrcodes/employees/employee_67.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
68	LPD11221	KANIMOZHI	Hw M/C Optr	1	qrcodes/employees/employee_68.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
69	LPD11279	M. ZEHRA	Table Worker	1	qrcodes/employees/employee_69.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
70	LPD11453	A. MUNNI	Stitcher	1	qrcodes/employees/employee_70.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
71	LPD11463	SHINAS	Edge Inking	1	qrcodes/employees/employee_71.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
72	LPD11482	S. MD. SULTAN	Hw M/C Optr	1	qrcodes/employees/employee_72.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
73	LPD11499	I. RESHMA	Table Worker	1	qrcodes/employees/employee_73.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
74	LPD11572	SHALINI	Ams Stitcher	1	qrcodes/employees/employee_74.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
75	LPD11610	JEEVA	Stitcher	1	qrcodes/employees/employee_75.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
76	LPD11677	B. LAKSHMI	Stitcher	1	qrcodes/employees/employee_76.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
77	LPD11712	P. GAYATHRI	Stitcher	1	qrcodes/employees/employee_77.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
78	LPD11959	A MEENAKSHI	Stitcher	1	qrcodes/employees/employee_78.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
80	LPD12022	K KHURSHEED BANU	Stitcher	1	qrcodes/employees/employee_80.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
18	LPD07485	R. VENNILA	Edge Inking	1	qrcodes/employees/employee_18.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
19	LPD07514	V. DHANALAKSHMI	Table Worker	1	qrcodes/employees/employee_19.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
84	LPD12239	U. SHYLAJA	Stitcher	1	qrcodes/employees/employee_84.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
85	LPD12240	M. HAJIRA	Stitcher	1	qrcodes/employees/employee_85.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
86	LPDS93008	B LATHA	Table Worker	1	qrcodes/employees/employee_86.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
87	LPDS93009	BAVANI	Table Worker	1	qrcodes/employees/employee_87.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
88	LPDS94717	AKMAL A	Hw M/C Optr	1	qrcodes/employees/employee_88.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
89	LPDS94756	UMA C	Table Worker	1	qrcodes/employees/employee_89.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
90	LPDS95161	FOUSIYA	Ams Stitcher	1	qrcodes/employees/employee_90.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
91	LPDS95252	P VENDA	Ams Stitcher	1	qrcodes/employees/employee_91.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
92	LPDS95527	REVATHI R	Table Worker	1	qrcodes/employees/employee_92.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
93	LPDS95657	A JOTHI	Ams Stitcher	1	qrcodes/employees/employee_93.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
94	LPDS95681	J KAVERI	Table Worker	1	qrcodes/employees/employee_94.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
95	LPDS95684	SELVI VENGATESAN	Table Worker	1	qrcodes/employees/employee_95.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
96	LPDS95689	S DIVYA PRABA	Stitcher	1	qrcodes/employees/employee_96.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
97	LPDS95702	M DILSHATH	Stitcher	1	qrcodes/employees/employee_97.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
98	LPDS95714	KAVITHA SURESH	Table Worker	1	qrcodes/employees/employee_98.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
99	LPDS95725	LAKSHMI JANAGIRAMAN	Table Worker	1	qrcodes/employees/employee_99.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
100	LPDS95728	CHANDHINI NASEER	Table Worker	1	qrcodes/employees/employee_100.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
101	LPDS95729	S MUNNI	Table Worker	1	qrcodes/employees/employee_101.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
102	LPDS95740	R. AMUDHA	Edge Inking	1	qrcodes/employees/employee_102.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
103	LPDS95741	N. SUMITHRA	Table Worker	1	qrcodes/employees/employee_103.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
105	LPDS95743	C. THILAGAWATHI	Table Worker	1	qrcodes/employees/employee_105.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
106	LPD08988	K. DEEPA	Associate	2	qrcodes/employees/employee_106.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
107	LPD09007	K. FAIYAZ	Hw M/C Optr	2	qrcodes/employees/employee_107.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
108	LPD09944	PARVEEN	Table Worker	2	qrcodes/employees/employee_108.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
109	LPD09951	B. SHAHEEN	Lw M/C Optr	2	qrcodes/employees/employee_109.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
110	LPD09954	SHOBANA	Table Worker	2	qrcodes/employees/employee_110.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
111	LPD09963	R. AMBIKA	Edge Inking	2	qrcodes/employees/employee_111.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
112	LPD09973	S. SIVARANJANI	Table Worker	2	qrcodes/employees/employee_112.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
113	LPD09981	K. ESWARI	Table Worker	2	qrcodes/employees/employee_113.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
114	LPD09996	A. YASEEN BEE	Edge Inking	2	qrcodes/employees/employee_114.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
115	LPD10035	REVATHI	Edge Inking	2	qrcodes/employees/employee_115.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
116	LPD10044	SHAKIRA	Table Worker	2	qrcodes/employees/employee_116.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
117	LPD10099	AMMU	Table Worker	2	qrcodes/employees/employee_117.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
118	LPD10255	MUGINA	Stitcher	2	qrcodes/employees/employee_118.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
120	LPD10701	BADRUNNISA	Table Worker	2	qrcodes/employees/employee_120.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
121	LPD11278	MD. INTAKHAB	Table Worker	2	qrcodes/employees/employee_121.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
122	LPD11358	SUMATHI	Table Worker	2	qrcodes/employees/employee_122.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
123	LPD11365	B. AMUDHA	Table Worker	2	qrcodes/employees/employee_123.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
124	LPD11504	S. SUGUNA	Ams Stitcher	2	qrcodes/employees/employee_124.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
125	LPD11567	SUMATHI	Hw M/C Optr	2	qrcodes/employees/employee_125.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
126	LPD11618	MD. NASIM	Stitcher	2	qrcodes/employees/employee_126.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
127	LPD11692	POORNIMA VIMAL	Stitcher	2	qrcodes/employees/employee_127.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
128	LPD11937	KHURSID ALI MOLLA	Table Worker	2	qrcodes/employees/employee_128.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
129	LPD11973	SHAJAN R	Stitcher	2	qrcodes/employees/employee_129.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
130	LPD12099	S AMUDHA	Table Worker	2	qrcodes/employees/employee_130.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
131	LPD12221	MD YAMIN ALI MOLLA	Table Worker	2	qrcodes/employees/employee_131.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
132	LPD12233	I RESHMA	Stitcher	2	qrcodes/employees/employee_132.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
133	LPD12243	VASIM AKARAM	Table Worker	2	qrcodes/employees/employee_133.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
134	LPD12247	MARUF HOSSAIN PIYADA	Stitcher	2	qrcodes/employees/employee_134.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
135	LPD12248	MAFIJUL MOLLA	Stitcher	2	qrcodes/employees/employee_135.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
137	LPDS94644	RAVICHITRA	Edge Inking	2	qrcodes/employees/employee_137.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
138	LPDS94648	JAYANTHI	Table Worker	2	qrcodes/employees/employee_138.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
139	LPDS95359	MOHAMMED ZAIBAS M	Lw M/C Optr	2	qrcodes/employees/employee_139.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
140	LPDS95749	HAJIMA MABOOB BASHA	Stitcher	2	qrcodes/employees/employee_140.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
141	LPDS95753	S THABASSUM	Edge Inking	2	qrcodes/employees/employee_141.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
142	LPDS95763	ABDUL VAJEETH J	Ams Stitcher	2	qrcodes/employees/employee_142.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
82	LPD12237	SALIYA BANU	Table Worker	1	qrcodes/employees/employee_82.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
83	LPD12238	MEENA S	Stitcher	1	qrcodes/employees/employee_83.png	t	2026-01-14 15:09:29.857417	2026-01-14 15:09:29.857417	\N	\N	1
\.


--
-- Data for Name: group_wip; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.group_wip (id, line_id, work_date, group_name, materials_in, output_qty, wip_quantity, updated_at) FROM stdin;
\.


--
-- Data for Name: line_daily_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.line_daily_metrics (id, line_id, work_date, forwarded_quantity, remaining_wip, materials_issued, updated_by, updated_at, qa_output) FROM stdin;
1	2	2026-01-21	10	2	2	\N	2026-01-21 17:22:49.079668	1
\.


--
-- Data for Name: line_daily_plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.line_daily_plans (id, line_id, product_id, work_date, target_units, created_by, updated_by, created_at, updated_at, is_locked, incoming_product_id, incoming_target_units, changeover_sequence, overtime_minutes, overtime_target, changeover_started_at, ot_enabled) FROM stdin;
2	1	1	2026-02-08	500	\N	\N	2026-02-08 12:05:50.308087	2026-02-08 12:56:14.12135	f	2	200	1	0	0	\N	f
4	2	3	2026-02-08	200	\N	\N	2026-02-08 13:19:54.944437	2026-02-08 13:19:54.944437	f	1	0	0	0	0	\N	f
11	1	3	2026-02-10	1	\N	\N	2026-02-10 15:24:49.217915	2026-02-10 15:25:00.574371	f	2	1	0	0	0	\N	f
9	2	1	2026-02-10	2	\N	\N	2026-02-10 15:10:46.438735	2026-02-10 15:25:06.856034	f	2	0	0	0	0	\N	f
23	2	4	2026-02-13	500	\N	\N	2026-02-13 16:21:38.989607	2026-02-13 16:21:38.989607	f	1	100	0	0	0	\N	f
24	1	5	2026-02-17	1	\N	\N	2026-02-17 15:54:48.264965	2026-02-17 15:54:48.264965	f	\N	0	0	0	0	\N	f
25	1	5	2026-02-18	100	\N	\N	2026-02-18 17:27:20.590833	2026-02-18 17:27:20.590833	f	\N	0	0	0	0	\N	f
57	1	5	2026-03-19	500	\N	\N	2026-03-19 12:29:21.425968	2026-03-19 13:05:01.307741	f	2	300	0	0	0	\N	f
28	2	1	2026-02-19	500	\N	\N	2026-02-19 20:56:39.542652	2026-02-19 20:56:39.542652	f	\N	0	0	0	0	\N	f
26	1	5	2026-02-19	500	\N	\N	2026-02-19 20:16:47.202647	2026-02-19 21:09:20.599811	f	1	100	0	60	50	\N	f
29	1	5	2026-02-22	100	\N	\N	2026-02-22 14:31:07.093301	2026-02-22 14:31:35.884488	f	\N	0	0	60	100	\N	f
31	2	1	2026-02-28	500	\N	\N	2026-02-28 19:32:47.214923	2026-02-28 20:29:47.744588	f	\N	0	0	0	0	\N	f
32	1	5	2026-02-28	500	\N	\N	2026-02-28 19:33:08.164984	2026-02-28 20:54:35.286258	f	1	50	0	0	0	\N	f
69	13	5	2026-03-20	500	\N	\N	2026-03-20 20:50:04.94559	2026-03-20 20:52:54.718933	f	\N	0	0	0	0	\N	f
71	15	5	2026-03-20	500	\N	\N	2026-03-20 21:09:44.355815	2026-03-20 21:09:44.355815	f	\N	0	0	0	0	\N	f
67	1	5	2026-03-20	500	\N	\N	2026-03-20 14:28:07.019935	2026-03-20 21:49:57.400379	f	\N	0	0	0	0	\N	f
37	1	5	2026-03-02	500	\N	\N	2026-03-02 14:46:59.194006	2026-03-02 18:06:06.953716	f	\N	0	0	0	0	\N	t
38	2	1	2026-03-02	500	\N	\N	2026-03-02 18:04:17.467522	2026-03-02 19:29:27.301313	f	\N	0	0	0	0	\N	f
41	1	5	2026-03-06	500	\N	\N	2026-03-06 14:07:05.590167	2026-03-06 14:07:21.293914	f	\N	0	0	0	0	\N	t
42	2	1	2026-03-06	500	\N	\N	2026-03-06 14:15:00.058907	2026-03-06 14:15:00.058907	f	5	50	0	0	0	\N	f
46	2	1	2026-03-09	200	\N	\N	2026-03-09 22:54:07.476655	2026-03-09 22:54:07.476655	f	\N	0	0	0	0	\N	f
43	1	5	2026-03-09	100	\N	\N	2026-03-09 14:27:27.247343	2026-03-09 22:58:55.363809	f	1	100	0	0	0	\N	t
48	1	5	2026-03-10	100	\N	\N	2026-03-10 13:02:01.645484	2026-03-10 13:50:58.714928	f	\N	0	0	0	0	\N	f
50	1	5	2026-03-16	100	\N	\N	2026-03-16 17:03:32.997749	2026-03-16 17:03:32.997749	f	\N	0	0	0	0	\N	f
51	1	5	2026-03-17	100	\N	\N	2026-03-17 19:41:41.756862	2026-03-17 19:54:26.484289	f	1	100	0	0	0	\N	t
52	1	5	2026-03-18	500	\N	\N	2026-03-18 16:33:56.101318	2026-03-18 16:50:04.046162	f	1	200	0	0	0	\N	f
\.


--
-- Data for Name: line_hourly_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.line_hourly_reports (line_id, work_date, hour_slot, remarks, created_at, updated_at) FROM stdin;
1	2026-02-10	15	Done good	2026-02-10 15:29:50.963554	2026-02-10 15:29:50.963554
2	2026-02-13	16	\N	2026-02-13 16:34:42.344082	2026-02-13 16:34:42.344082
2	2026-02-17	15	\N	2026-02-17 15:52:19.007025	2026-02-17 15:52:19.007025
\.


--
-- Data for Name: line_material_stock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.line_material_stock (id, line_id, work_date, opening_stock, total_issued, total_used, total_returned, closing_stock, updated_at) FROM stdin;
\.


--
-- Data for Name: line_ot_plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.line_ot_plans (id, line_id, work_date, product_id, global_ot_minutes, ot_target_units, created_at, updated_at, supervisor_authorized) FROM stdin;
1	1	2026-03-02	5	60	0	2026-03-02 17:36:18.853978+05:30	2026-03-02 18:06:35.13855+05:30	f
2	2	2026-03-02	1	60	0	2026-03-02 18:04:23.612015+05:30	2026-03-02 19:29:23.317975+05:30	f
5	1	2026-03-06	5	60	0	2026-03-06 14:07:21.293914+05:30	2026-03-06 14:13:24.460786+05:30	f
6	1	2026-03-09	5	60	0	2026-03-09 14:27:30.821212+05:30	2026-03-09 21:36:47.400808+05:30	f
11	1	2026-03-17	5	60	0	2026-03-17 19:54:26.484289+05:30	2026-03-17 19:54:26.484289+05:30	f
\.


--
-- Data for Name: line_ot_progress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.line_ot_progress (id, line_id, ot_workstation_id, work_date, quantity, qa_rejection, remarks, employee_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: line_ot_workstation_processes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.line_ot_workstation_processes (id, ot_workstation_id, product_process_id, sequence_in_workstation) FROM stdin;
16	11	83	1
17	11	84	2
18	11	85	3
19	12	86	1
20	12	87	2
21	13	88	1
22	14	89	1
23	15	90	1
24	16	91	1
25	17	92	1
26	18	93	1
27	18	94	2
28	18	95	3
29	19	96	1
30	20	97	1
31	21	83	1
32	21	84	2
33	21	85	3
34	22	86	1
35	22	87	2
36	23	88	1
37	24	89	1
38	25	90	1
39	26	91	1
40	27	92	1
41	28	93	1
42	28	94	2
43	28	95	3
44	29	96	1
45	30	97	1
46	31	83	1
47	31	84	2
48	31	85	3
49	32	86	1
50	32	87	2
51	33	88	1
52	34	89	1
53	35	90	1
54	36	91	1
55	37	92	1
56	38	93	1
57	38	94	2
58	38	95	3
59	39	96	1
60	40	97	1
61	41	83	1
62	41	84	2
63	41	85	3
64	42	86	1
65	42	87	2
66	43	88	1
67	44	89	1
68	45	90	1
69	46	91	1
70	47	92	1
71	48	93	1
72	48	94	2
73	48	95	3
74	49	96	1
75	50	97	1
\.


--
-- Data for Name: line_ot_workstations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.line_ot_workstations (id, ot_plan_id, workstation_code, workstation_number, group_name, is_active, ot_minutes, actual_sam_seconds, created_at, updated_at) FROM stdin;
12	1	W2	2	G1	t	0	50.04	2026-03-02 18:06:06.953716+05:30	2026-03-02 18:06:06.953716+05:30
13	1	W3	3	G2	t	0	50.04	2026-03-02 18:06:06.953716+05:30	2026-03-02 18:06:06.953716+05:30
14	1	W4	4	G2	t	0	42.12	2026-03-02 18:06:06.953716+05:30	2026-03-02 18:06:06.953716+05:30
15	1	W5	5	G2	t	0	43.92	2026-03-02 18:06:06.953716+05:30	2026-03-02 18:06:06.953716+05:30
16	1	W6	6	G2	t	0	43.92	2026-03-02 18:06:06.953716+05:30	2026-03-02 18:06:06.953716+05:30
17	1	W7	7	G2	t	0	47.88	2026-03-02 18:06:06.953716+05:30	2026-03-02 18:06:06.953716+05:30
18	1	W8	8	G2	t	0	54.36	2026-03-02 18:06:06.953716+05:30	2026-03-02 18:06:06.953716+05:30
19	1	W9	9	G3	t	0	45.00	2026-03-02 18:06:06.953716+05:30	2026-03-02 18:06:06.953716+05:30
20	1	W10	10	G3	t	0	55.08	2026-03-02 18:06:06.953716+05:30	2026-03-02 18:06:06.953716+05:30
11	1	W1	1	G1	t	0	53.64	2026-03-02 18:06:06.953716+05:30	2026-03-02 19:28:31.93633+05:30
23	5	W3	3	G2	t	0	50.04	2026-03-06 14:07:21.293914+05:30	2026-03-06 14:07:21.293914+05:30
24	5	W4	4	G2	t	0	42.12	2026-03-06 14:07:21.293914+05:30	2026-03-06 14:07:21.293914+05:30
25	5	W5	5	G2	t	0	43.92	2026-03-06 14:07:21.293914+05:30	2026-03-06 14:07:21.293914+05:30
26	5	W6	6	G2	t	0	43.92	2026-03-06 14:07:21.293914+05:30	2026-03-06 14:07:21.293914+05:30
27	5	W7	7	G2	t	0	47.88	2026-03-06 14:07:21.293914+05:30	2026-03-06 14:07:21.293914+05:30
28	5	W8	8	G2	t	0	54.36	2026-03-06 14:07:21.293914+05:30	2026-03-06 14:07:21.293914+05:30
29	5	W9	9	G3	t	0	45.00	2026-03-06 14:07:21.293914+05:30	2026-03-06 14:07:21.293914+05:30
30	5	W10	10	G3	t	0	55.08	2026-03-06 14:07:21.293914+05:30	2026-03-06 14:07:21.293914+05:30
21	5	W1	1	G1	f	0	53.64	2026-03-06 14:07:21.293914+05:30	2026-03-06 14:07:26.618349+05:30
22	5	W2	2	G1	f	0	50.04	2026-03-06 14:07:21.293914+05:30	2026-03-06 14:07:27.355582+05:30
32	6	W2	2	G1	t	0	50.04	2026-03-09 14:27:30.821212+05:30	2026-03-09 14:27:30.821212+05:30
33	6	W3	3	G2	t	0	50.04	2026-03-09 14:27:30.821212+05:30	2026-03-09 14:27:30.821212+05:30
34	6	W4	4	G2	t	0	42.12	2026-03-09 14:27:30.821212+05:30	2026-03-09 14:27:30.821212+05:30
35	6	W5	5	G2	t	0	43.92	2026-03-09 14:27:30.821212+05:30	2026-03-09 14:27:30.821212+05:30
36	6	W6	6	G2	t	0	43.92	2026-03-09 14:27:30.821212+05:30	2026-03-09 14:27:30.821212+05:30
37	6	W7	7	G2	t	0	47.88	2026-03-09 14:27:30.821212+05:30	2026-03-09 14:27:30.821212+05:30
38	6	W8	8	G2	t	0	54.36	2026-03-09 14:27:30.821212+05:30	2026-03-09 14:27:30.821212+05:30
39	6	W9	9	G3	t	0	45.00	2026-03-09 14:27:30.821212+05:30	2026-03-09 14:27:30.821212+05:30
40	6	W10	10	G3	t	0	55.08	2026-03-09 14:27:30.821212+05:30	2026-03-09 14:27:30.821212+05:30
31	6	W1	1	G1	t	0	53.64	2026-03-09 14:27:30.821212+05:30	2026-03-09 21:38:10.182414+05:30
41	11	W1	1	G1	t	0	53.64	2026-03-17 19:54:26.484289+05:30	2026-03-17 19:54:26.484289+05:30
43	11	W3	3	G2	t	0	50.04	2026-03-17 19:54:26.484289+05:30	2026-03-17 19:54:26.484289+05:30
44	11	W4	4	G2	t	0	42.12	2026-03-17 19:54:26.484289+05:30	2026-03-17 19:54:26.484289+05:30
45	11	W5	5	G2	t	0	43.92	2026-03-17 19:54:26.484289+05:30	2026-03-17 19:54:26.484289+05:30
46	11	W6	6	G2	t	0	43.92	2026-03-17 19:54:26.484289+05:30	2026-03-17 19:54:26.484289+05:30
47	11	W7	7	G2	t	0	47.88	2026-03-17 19:54:26.484289+05:30	2026-03-17 19:54:26.484289+05:30
48	11	W8	8	G2	t	0	54.36	2026-03-17 19:54:26.484289+05:30	2026-03-17 19:54:26.484289+05:30
49	11	W9	9	G3	t	0	45.00	2026-03-17 19:54:26.484289+05:30	2026-03-17 19:54:26.484289+05:30
50	11	W10	10	G3	t	0	55.08	2026-03-17 19:54:26.484289+05:30	2026-03-17 19:54:26.484289+05:30
42	11	W2	2	G1	t	0	50.04	2026-03-17 19:54:26.484289+05:30	2026-03-17 19:54:44.065356+05:30
\.


--
-- Data for Name: line_plan_workstation_processes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.line_plan_workstation_processes (id, workstation_id, product_process_id, sequence_in_workstation, osm_checked) FROM stdin;
87	28	84	2	f
96	32	93	1	f
98	32	95	3	f
16	1	84	1	f
25	2	93	2	f
27	2	95	4	f
194	87	84	2	f
203	94	93	1	f
205	94	95	3	f
208	97	6	1	f
209	97	7	2	f
210	97	8	3	f
211	98	9	1	f
212	98	10	2	f
213	99	11	1	f
214	99	12	2	f
305	160	6	1	f
306	160	7	2	f
307	160	8	3	f
308	161	9	1	f
309	161	10	2	f
310	162	11	1	f
311	162	12	2	f
134	50	84	2	f
86	28	83	1	t
30	2	83	7	t
193	87	83	1	t
133	50	83	1	t
148	57	83	1	t
372	203	83	1	t
178	77	83	1	t
357	193	83	1	t
90	29	87	1	t
19	1	87	4	t
143	54	93	2	f
145	55	95	2	f
149	57	84	2	f
158	64	93	1	f
160	64	95	3	f
197	88	87	2	t
137	51	87	2	t
152	58	87	2	t
182	78	87	2	t
376	204	87	2	t
361	194	87	2	t
294	151	87	2	t
91	29	88	2	t
88	28	85	3	f
17	1	85	2	f
195	87	85	3	f
135	50	85	3	f
373	203	84	2	f
179	77	84	2	f
188	84	93	1	f
190	84	95	3	f
150	57	85	3	f
374	203	85	3	f
180	77	85	3	f
359	193	85	3	f
292	150	85	3	f
20	1	88	5	t
198	89	88	1	t
138	52	88	1	t
153	59	88	1	t
183	79	88	1	t
377	205	88	1	t
362	195	88	1	t
295	152	88	1	t
92	30	89	1	t
21	1	89	6	t
358	193	84	2	f
367	200	93	1	t
369	200	95	3	f
382	210	93	1	f
384	210	95	3	f
199	90	89	1	t
291	150	84	2	f
300	157	93	1	f
139	52	89	2	t
302	157	95	3	t
154	60	89	1	t
184	80	89	1	t
378	206	89	1	t
363	196	89	1	t
296	153	89	1	t
93	30	90	2	t
22	1	90	7	t
200	91	90	1	t
140	53	90	1	t
155	61	90	1	t
185	81	90	1	t
364	197	90	1	t
379	207	90	1	t
94	31	91	1	t
23	1	91	8	t
201	92	91	1	t
141	53	91	2	t
156	62	91	1	t
186	82	91	1	t
365	198	91	1	t
380	208	91	1	t
95	31	92	2	t
24	2	92	1	t
202	93	92	1	t
142	54	92	1	t
403	223	84	2	t
89	28	86	4	f
18	1	86	3	f
196	88	86	1	f
136	51	86	1	f
151	58	86	1	f
181	78	86	1	f
375	204	86	1	f
157	63	92	1	t
187	83	92	1	t
366	199	92	1	t
381	209	92	1	t
299	156	92	1	t
97	32	94	2	t
26	2	94	3	t
204	94	94	2	t
144	55	94	1	t
159	64	94	2	t
189	84	94	2	t
368	200	94	2	t
383	210	94	2	t
99	33	96	1	t
28	2	96	5	t
206	95	96	1	t
146	55	96	3	t
161	65	96	1	t
191	85	96	1	t
370	201	96	1	t
385	211	96	1	t
100	34	97	1	t
29	2	97	6	t
207	96	97	1	t
147	56	97	1	t
162	66	97	1	t
192	86	97	1	t
371	202	97	1	t
386	212	97	1	t
412	230	93	1	f
414	230	95	3	t
581	331	77	1	t
582	332	79	1	t
583	333	83	1	t
584	333	84	2	t
585	333	85	3	f
587	334	87	2	t
588	335	88	1	t
589	336	89	1	t
409	227	90	1	t
590	337	90	1	t
591	338	91	1	t
592	339	92	1	t
593	340	93	1	t
594	340	94	2	t
595	340	95	3	t
596	341	96	1	t
597	342	97	1	t
642	367	83	1	f
643	367	84	2	t
644	367	85	3	f
646	368	87	2	t
647	369	88	1	f
648	370	89	1	f
649	371	90	1	t
650	372	91	1	f
651	373	92	1	t
652	374	93	1	t
653	374	94	2	f
654	374	95	3	t
655	375	96	1	t
656	376	97	1	t
405	224	86	1	f
586	334	86	1	f
645	368	86	1	f
360	194	86	1	f
293	151	86	1	f
554	312	86	1	f
290	150	83	1	t
402	223	83	1	t
404	223	85	3	f
406	224	87	2	t
683	393	83	1	f
407	225	88	1	t
684	393	84	2	t
408	226	89	1	t
685	393	85	3	f
297	154	90	1	t
298	155	91	1	t
686	393	86	4	f
687	394	87	1	t
688	394	88	2	f
410	228	91	1	t
689	395	89	1	f
411	229	92	1	t
690	395	90	2	t
413	230	94	2	t
301	157	94	2	t
691	396	91	1	f
303	158	96	1	t
415	231	96	1	t
692	397	92	1	t
416	232	97	1	t
304	159	97	1	t
693	398	94	1	f
551	311	83	1	t
552	311	84	2	f
553	311	85	3	f
555	312	87	2	t
556	313	88	1	t
557	314	89	1	t
558	315	90	1	t
559	316	91	1	t
560	317	92	1	t
561	318	93	1	f
562	318	94	2	t
563	318	95	3	f
564	319	96	1	t
565	320	97	1	t
694	399	95	1	f
695	400	97	1	t
696	401	83	1	f
697	401	84	2	t
698	401	85	3	f
699	401	86	4	f
700	402	87	1	t
701	402	88	2	f
702	403	89	1	f
703	403	90	2	t
704	404	91	1	f
705	405	92	1	t
706	406	94	1	f
707	407	95	1	f
708	408	97	1	t
\.


--
-- Data for Name: line_plan_workstations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.line_plan_workstations (id, line_id, work_date, product_id, workstation_number, workstation_code, takt_time_seconds, actual_sam_seconds, workload_pct, created_at, updated_at, group_name, is_ot_skipped, ws_changeover_active, ws_changeover_started_at, co_employee_id) FROM stdin;
1	1	2026-02-18	5	1	WS01	324.00	271.80	83.89	2026-02-18 17:28:22.422953	2026-02-18 17:28:44.751795	\N	f	f	\N	\N
2	1	2026-02-18	5	2	WS02	324.00	214.20	66.11	2026-02-18 17:28:22.442498	2026-02-18 17:28:44.785858	\N	f	f	\N	\N
160	2	2026-03-09	1	1	W1	57.60	224.28	389.38	2026-03-09 22:54:07.489151	2026-03-09 22:54:07.489151	\N	f	f	\N	\N
161	2	2026-03-09	1	2	W2	57.60	120.24	208.75	2026-03-09 22:54:07.493736	2026-03-09 22:54:07.493736	\N	f	f	\N	\N
162	2	2026-03-09	1	3	W3	57.60	84.96	147.50	2026-03-09 22:54:07.497326	2026-03-09 22:54:07.497326	\N	f	f	\N	\N
28	1	2026-02-19	5	1	W1	57.60	83.52	145.00	2026-02-19 21:25:32.43026	2026-02-19 21:25:32.43026	G1	f	f	\N	\N
29	1	2026-02-19	5	2	W2	57.60	70.20	121.88	2026-02-19 21:25:32.441972	2026-02-19 21:25:32.441972	G1	f	f	\N	\N
30	1	2026-02-19	5	3	W3	57.60	86.04	149.38	2026-02-19 21:25:32.448201	2026-02-19 21:25:32.448201	G1	f	f	\N	\N
31	1	2026-02-19	5	4	W4	57.60	91.80	159.38	2026-02-19 21:25:32.454398	2026-02-19 21:25:32.454398	G2	f	f	\N	\N
32	1	2026-02-19	5	5	W5	57.60	54.36	94.38	2026-02-19 21:25:32.463711	2026-02-19 21:25:32.463711	G2	f	f	\N	\N
33	1	2026-02-19	5	6	W6	57.60	45.00	78.13	2026-02-19 21:25:32.473681	2026-02-19 21:25:32.473681	G3	f	f	\N	\N
34	1	2026-02-19	5	7	W7	57.60	55.08	95.63	2026-02-19 21:25:32.478641	2026-02-19 21:25:32.478641	G3	f	f	\N	\N
193	1	2026-03-10	5	1	W1	288.00	53.64	18.63	2026-03-10 14:58:50.804141	2026-03-10 14:58:50.804141	G1	f	f	\N	\N
194	1	2026-03-10	5	2	W2	288.00	50.04	17.38	2026-03-10 14:58:50.814275	2026-03-10 14:58:50.814275	G1	f	f	\N	\N
195	1	2026-03-10	5	3	W3	288.00	50.04	17.38	2026-03-10 14:58:50.821093	2026-03-10 14:58:50.821093	G2	f	f	\N	\N
196	1	2026-03-10	5	4	W4	288.00	42.12	14.63	2026-03-10 14:58:50.826357	2026-03-10 14:58:50.826357	G2	f	f	\N	\N
197	1	2026-03-10	5	5	W5	288.00	43.92	15.25	2026-03-10 14:58:50.831927	2026-03-10 14:58:50.831927	G2	f	f	\N	\N
198	1	2026-03-10	5	6	W6	288.00	43.92	15.25	2026-03-10 14:58:50.837264	2026-03-10 14:58:50.837264	G2	f	f	\N	\N
199	1	2026-03-10	5	7	W7	288.00	47.88	16.62	2026-03-10 14:58:50.842782	2026-03-10 14:58:50.842782	G2	f	f	\N	\N
50	1	2026-02-22	5	1	W1	288.00	53.64	18.63	2026-02-22 14:46:10.821928	2026-02-22 14:46:10.821928	\N	f	f	\N	\N
51	1	2026-02-22	5	2	W2	288.00	50.04	17.38	2026-02-22 14:46:10.83215	2026-02-22 14:46:10.83215	\N	f	f	\N	\N
52	1	2026-02-22	5	3	W3	288.00	92.16	32.00	2026-02-22 14:46:10.838974	2026-02-22 14:46:10.838974	\N	f	f	\N	\N
53	1	2026-02-22	5	4	W4	288.00	87.84	30.50	2026-02-22 14:46:10.84363	2026-02-22 14:46:10.84363	\N	f	f	\N	\N
54	1	2026-02-22	5	5	W5	288.00	68.04	23.62	2026-02-22 14:46:10.84789	2026-02-22 14:46:10.84789	\N	f	f	\N	\N
55	1	2026-02-22	5	6	W6	288.00	79.20	27.50	2026-02-22 14:46:10.852027	2026-02-22 14:46:10.852027	\N	f	f	\N	\N
56	1	2026-02-22	5	7	W7	288.00	55.08	19.13	2026-02-22 14:46:10.857881	2026-02-22 14:46:10.857881	\N	f	f	\N	\N
57	1	2026-02-28	5	1	W1	57.60	53.64	93.13	2026-02-28 20:52:54.786068	2026-02-28 20:52:54.786068	G1	f	f	\N	\N
58	1	2026-02-28	5	2	W2	57.60	50.04	86.87	2026-02-28 20:52:54.80003	2026-02-28 20:52:54.80003	G1	f	f	\N	\N
59	1	2026-02-28	5	3	W3	57.60	50.04	86.87	2026-02-28 20:52:54.806899	2026-02-28 20:52:54.806899	G2	f	f	\N	\N
60	1	2026-02-28	5	4	W4	57.60	42.12	73.13	2026-02-28 20:52:54.812415	2026-02-28 20:52:54.812415	G2	f	f	\N	\N
61	1	2026-02-28	5	5	W5	57.60	43.92	76.25	2026-02-28 20:52:54.825291	2026-02-28 20:52:54.825291	G2	f	f	\N	\N
62	1	2026-02-28	5	6	W6	57.60	43.92	76.25	2026-02-28 20:52:54.831052	2026-02-28 20:52:54.831052	G2	f	f	\N	\N
63	1	2026-02-28	5	7	W7	57.60	47.88	83.13	2026-02-28 20:52:54.83617	2026-02-28 20:52:54.83617	G2	f	f	\N	\N
64	1	2026-02-28	5	8	W8	57.60	54.36	94.38	2026-02-28 20:52:54.840983	2026-02-28 20:52:54.840983	G2	f	f	\N	\N
65	1	2026-02-28	5	9	W9	57.60	45.00	78.13	2026-02-28 20:52:54.848547	2026-02-28 20:52:54.848547	G3	f	f	\N	\N
66	1	2026-02-28	5	10	W10	57.60	55.08	95.63	2026-02-28 20:52:54.852915	2026-02-28 20:52:54.852915	G3	f	f	\N	\N
200	1	2026-03-10	5	8	W8	288.00	54.36	18.88	2026-03-10 14:58:50.847463	2026-03-10 14:58:50.847463	G2	f	f	\N	\N
201	1	2026-03-10	5	9	W9	288.00	45.00	15.63	2026-03-10 14:58:50.855375	2026-03-10 14:58:50.855375	G3	f	f	\N	\N
202	1	2026-03-10	5	10	W10	288.00	55.08	19.13	2026-03-10 14:58:50.860046	2026-03-10 14:58:50.860046	G3	f	f	\N	\N
203	1	2026-03-16	5	1	W1	288.00	53.64	18.63	2026-03-16 17:03:33.097968	2026-03-16 17:03:33.097968	G1	f	f	\N	\N
204	1	2026-03-16	5	2	W2	288.00	50.04	17.38	2026-03-16 17:03:33.147396	2026-03-16 17:03:33.147396	G1	f	f	\N	\N
205	1	2026-03-16	5	3	W3	288.00	50.04	17.38	2026-03-16 17:03:33.173127	2026-03-16 17:03:33.173127	G2	f	f	\N	\N
77	1	2026-03-02	5	1	W1	57.60	53.64	93.13	2026-03-02 14:47:10.466633	2026-03-02 14:47:10.466633	G1	f	f	\N	\N
78	1	2026-03-02	5	2	W2	57.60	50.04	86.87	2026-03-02 14:47:10.470054	2026-03-02 14:47:10.470054	G1	f	f	\N	\N
79	1	2026-03-02	5	3	W3	57.60	50.04	86.87	2026-03-02 14:47:10.474531	2026-03-02 14:47:10.474531	G2	f	f	\N	\N
80	1	2026-03-02	5	4	W4	57.60	42.12	73.13	2026-03-02 14:47:10.478148	2026-03-02 14:47:10.478148	G2	f	f	\N	\N
81	1	2026-03-02	5	5	W5	57.60	43.92	76.25	2026-03-02 14:47:10.481566	2026-03-02 14:47:10.481566	G2	f	f	\N	\N
82	1	2026-03-02	5	6	W6	57.60	43.92	76.25	2026-03-02 14:47:10.484862	2026-03-02 14:47:10.484862	G2	f	f	\N	\N
83	1	2026-03-02	5	7	W7	57.60	47.88	83.13	2026-03-02 14:47:10.487993	2026-03-02 14:47:10.487993	G2	f	f	\N	\N
84	1	2026-03-02	5	8	W8	57.60	54.36	94.38	2026-03-02 14:47:10.49123	2026-03-02 14:47:10.49123	G2	f	f	\N	\N
85	1	2026-03-02	5	9	W9	57.60	45.00	78.13	2026-03-02 14:47:10.494985	2026-03-02 14:47:10.494985	G3	f	f	\N	\N
86	1	2026-03-02	5	10	W10	57.60	55.08	95.63	2026-03-02 14:47:10.498344	2026-03-02 14:47:10.498344	G3	f	f	\N	\N
87	1	2026-03-06	5	1	W1	57.60	53.64	93.13	2026-03-06 14:07:05.680777	2026-03-06 14:07:05.680777	G1	f	f	\N	\N
88	1	2026-03-06	5	2	W2	57.60	50.04	86.87	2026-03-06 14:07:05.729839	2026-03-06 14:07:05.729839	G1	f	f	\N	\N
89	1	2026-03-06	5	3	W3	57.60	50.04	86.87	2026-03-06 14:07:05.753282	2026-03-06 14:07:05.753282	G2	f	f	\N	\N
90	1	2026-03-06	5	4	W4	57.60	42.12	73.13	2026-03-06 14:07:05.780394	2026-03-06 14:07:05.780394	G2	f	f	\N	\N
91	1	2026-03-06	5	5	W5	57.60	43.92	76.25	2026-03-06 14:07:05.808198	2026-03-06 14:07:05.808198	G2	f	f	\N	\N
92	1	2026-03-06	5	6	W6	57.60	43.92	76.25	2026-03-06 14:07:05.826119	2026-03-06 14:07:05.826119	G2	f	f	\N	\N
93	1	2026-03-06	5	7	W7	57.60	47.88	83.13	2026-03-06 14:07:05.836204	2026-03-06 14:07:05.836204	G2	f	f	\N	\N
94	1	2026-03-06	5	8	W8	57.60	54.36	94.38	2026-03-06 14:07:05.883394	2026-03-06 14:07:05.883394	G2	f	f	\N	\N
95	1	2026-03-06	5	9	W9	57.60	45.00	78.13	2026-03-06 14:07:05.957032	2026-03-06 14:07:05.957032	G3	f	f	\N	\N
96	1	2026-03-06	5	10	W10	57.60	55.08	95.63	2026-03-06 14:07:06.023444	2026-03-06 14:07:06.023444	G3	f	f	\N	\N
97	2	2026-03-06	1	1	W1	57.60	224.28	389.38	2026-03-06 14:46:05.667318	2026-03-06 14:46:05.667318	\N	f	f	\N	\N
98	2	2026-03-06	1	2	W2	57.60	120.24	208.75	2026-03-06 14:46:05.676166	2026-03-06 14:46:05.676166	\N	f	f	\N	\N
99	2	2026-03-06	1	3	W3	57.60	84.96	147.50	2026-03-06 14:46:05.680792	2026-03-06 14:46:05.680792	\N	f	f	\N	\N
150	1	2026-03-09	5	1	W1	57.60	53.64	93.13	2026-03-09 22:30:37.894969	2026-03-09 22:30:37.894969	G1	f	f	\N	\N
151	1	2026-03-09	5	2	W2	57.60	50.04	86.87	2026-03-09 22:30:37.902869	2026-03-09 22:30:37.902869	G1	f	f	\N	\N
152	1	2026-03-09	5	3	W3	57.60	50.04	86.87	2026-03-09 22:30:37.909566	2026-03-09 22:30:37.909566	G2	f	f	\N	\N
153	1	2026-03-09	5	4	W4	57.60	42.12	73.13	2026-03-09 22:30:37.914352	2026-03-09 22:30:37.914352	G2	f	f	\N	\N
154	1	2026-03-09	5	5	W5	57.60	43.92	76.25	2026-03-09 22:30:37.922403	2026-03-09 22:30:37.922403	G2	f	f	\N	\N
155	1	2026-03-09	5	6	W6	57.60	43.92	76.25	2026-03-09 22:30:37.928517	2026-03-09 22:30:37.928517	G2	f	f	\N	\N
156	1	2026-03-09	5	7	W7	57.60	47.88	83.13	2026-03-09 22:30:37.933578	2026-03-09 22:30:37.933578	G2	f	f	\N	\N
157	1	2026-03-09	5	8	W8	57.60	54.36	94.38	2026-03-09 22:30:37.93819	2026-03-09 22:30:37.93819	G2	f	f	\N	\N
158	1	2026-03-09	5	9	W9	57.60	45.00	78.13	2026-03-09 22:30:37.948301	2026-03-09 22:30:37.948301	G3	f	f	\N	\N
159	1	2026-03-09	5	10	W10	57.60	55.08	95.63	2026-03-09 22:30:37.953724	2026-03-09 22:30:37.953724	G3	f	f	\N	\N
206	1	2026-03-16	5	4	W4	288.00	42.12	14.63	2026-03-16 17:03:33.196335	2026-03-16 17:03:33.196335	G2	f	f	\N	\N
207	1	2026-03-16	5	5	W5	288.00	43.92	15.25	2026-03-16 17:03:33.230529	2026-03-16 17:03:33.230529	G2	f	f	\N	\N
208	1	2026-03-16	5	6	W6	288.00	43.92	15.25	2026-03-16 17:03:33.25361	2026-03-16 17:03:33.25361	G2	f	f	\N	\N
209	1	2026-03-16	5	7	W7	288.00	47.88	16.62	2026-03-16 17:03:33.270589	2026-03-16 17:03:33.270589	G2	f	f	\N	\N
210	1	2026-03-16	5	8	W8	288.00	54.36	18.88	2026-03-16 17:03:33.291709	2026-03-16 17:03:33.291709	G2	f	f	\N	\N
211	1	2026-03-16	5	9	W9	288.00	45.00	15.63	2026-03-16 17:03:33.313696	2026-03-16 17:03:33.313696	G3	f	f	\N	\N
212	1	2026-03-16	5	10	W10	288.00	55.08	19.13	2026-03-16 17:03:33.334559	2026-03-16 17:03:33.334559	G3	f	f	\N	\N
223	1	2026-03-17	5	1	W1	288.00	53.64	18.63	2026-03-17 19:48:02.002048	2026-03-17 19:48:02.002048	G1	f	f	\N	\N
224	1	2026-03-17	5	2	W2	288.00	50.04	17.38	2026-03-17 19:48:02.012694	2026-03-17 19:48:02.012694	G1	f	f	\N	\N
225	1	2026-03-17	5	3	W3	288.00	50.04	17.38	2026-03-17 19:48:02.019633	2026-03-17 19:48:02.019633	G2	f	f	\N	\N
226	1	2026-03-17	5	4	W4	288.00	42.12	14.63	2026-03-17 19:48:02.024939	2026-03-17 19:48:02.024939	G2	f	f	\N	\N
227	1	2026-03-17	5	5	W5	288.00	43.92	15.25	2026-03-17 19:48:02.030004	2026-03-17 19:48:02.030004	G2	f	f	\N	\N
228	1	2026-03-17	5	6	W6	288.00	43.92	15.25	2026-03-17 19:48:02.034823	2026-03-17 19:48:02.034823	G2	f	f	\N	\N
229	1	2026-03-17	5	7	W7	288.00	47.88	16.62	2026-03-17 19:48:02.039765	2026-03-17 19:48:02.039765	G2	f	f	\N	\N
230	1	2026-03-17	5	8	W8	288.00	54.36	18.88	2026-03-17 19:48:02.044294	2026-03-17 19:48:02.044294	G2	f	f	\N	\N
231	1	2026-03-17	5	9	W9	288.00	45.00	15.63	2026-03-17 19:48:02.051617	2026-03-17 19:48:02.051617	G3	f	f	\N	\N
232	1	2026-03-17	5	10	W10	288.00	55.08	19.13	2026-03-17 19:48:02.055979	2026-03-17 19:48:02.055979	G3	f	f	\N	\N
331	1	2026-03-19	2	1	W1	96.00	43.92	45.75	2026-03-19 12:55:39.853978	2026-03-19 12:55:39.853978	G1	f	f	\N	2
332	1	2026-03-19	2	2	W2	96.00	10.08	10.50	2026-03-19 12:55:39.884397	2026-03-19 12:55:39.884397	G2	f	f	\N	1
333	1	2026-03-19	5	1	W1	57.60	53.64	93.13	2026-03-19 13:15:46.424618	2026-03-19 13:15:46.424618	G1	f	f	\N	\N
334	1	2026-03-19	5	2	W2	57.60	50.04	86.87	2026-03-19 13:15:46.436649	2026-03-19 13:15:46.436649	G1	f	f	\N	\N
335	1	2026-03-19	5	3	W3	57.60	50.04	86.87	2026-03-19 13:15:46.443296	2026-03-19 13:15:46.443296	G2	f	f	\N	\N
336	1	2026-03-19	5	4	W4	57.60	42.12	73.13	2026-03-19 13:15:46.448093	2026-03-19 13:15:46.448093	G2	f	f	\N	\N
337	1	2026-03-19	5	5	W5	57.60	43.92	76.25	2026-03-19 13:15:46.453055	2026-03-19 13:15:46.453055	G1	f	f	\N	\N
338	1	2026-03-19	5	6	W6	57.60	43.92	76.25	2026-03-19 13:15:46.457902	2026-03-19 13:15:46.457902	G2	f	f	\N	\N
339	1	2026-03-19	5	7	W7	57.60	47.88	83.13	2026-03-19 13:15:46.46302	2026-03-19 13:15:46.46302	G2	f	f	\N	\N
340	1	2026-03-19	5	8	W8	57.60	54.36	94.38	2026-03-19 13:15:46.4679	2026-03-19 13:15:46.4679	G2	f	f	\N	\N
341	1	2026-03-19	5	9	W9	57.60	45.00	78.13	2026-03-19 13:15:46.475277	2026-03-19 13:15:46.475277	G3	f	f	\N	\N
342	1	2026-03-19	5	10	W10	57.60	55.08	95.63	2026-03-19 13:15:46.479808	2026-03-19 13:15:46.479808	G3	f	f	\N	\N
367	1	2026-03-20	5	1	W1	57.60	53.64	93.13	2026-03-20 14:28:07.039087	2026-03-20 14:28:07.039087	G1	f	f	\N	\N
368	1	2026-03-20	5	2	W2	57.60	50.04	86.87	2026-03-20 14:28:07.048646	2026-03-20 14:28:07.048646	G1	f	f	\N	\N
369	1	2026-03-20	5	3	W3	57.60	50.04	86.87	2026-03-20 14:28:07.05403	2026-03-20 14:28:07.05403	G2	f	f	\N	\N
370	1	2026-03-20	5	4	W4	57.60	42.12	73.13	2026-03-20 14:28:07.059413	2026-03-20 14:28:07.059413	G2	f	f	\N	\N
371	1	2026-03-20	5	5	W5	57.60	43.92	76.25	2026-03-20 14:28:07.066318	2026-03-20 14:28:07.066318	G1	f	f	\N	\N
372	1	2026-03-20	5	6	W6	57.60	43.92	76.25	2026-03-20 14:28:07.073349	2026-03-20 14:28:07.073349	G2	f	f	\N	\N
373	1	2026-03-20	5	7	W7	57.60	47.88	83.13	2026-03-20 14:28:07.078764	2026-03-20 14:28:07.078764	G2	f	f	\N	\N
374	1	2026-03-20	5	8	W8	57.60	54.36	94.38	2026-03-20 14:28:07.083509	2026-03-20 14:28:07.083509	G2	f	f	\N	\N
375	1	2026-03-20	5	9	W9	57.60	45.00	78.13	2026-03-20 14:28:07.088487	2026-03-20 14:28:07.088487	G3	f	f	\N	\N
376	1	2026-03-20	5	10	W10	57.60	55.08	95.63	2026-03-20 14:28:07.093519	2026-03-20 14:28:07.093519	G3	f	f	\N	\N
393	13	2026-03-20	5	1	WS01	64.80	84.00	129.63	2026-03-20 20:52:54.718933	2026-03-20 20:52:54.718933	G1	f	f	\N	\N
394	13	2026-03-20	5	2	WS02	64.80	36.00	55.56	2026-03-20 20:52:54.718933	2026-03-20 20:52:54.718933	G1	f	f	\N	\N
395	13	2026-03-20	5	3	WS03	64.80	30.00	46.30	2026-03-20 20:52:54.718933	2026-03-20 20:52:54.718933	G2	f	f	\N	\N
396	13	2026-03-20	5	4	WS04	64.80	20.00	30.86	2026-03-20 20:52:54.718933	2026-03-20 20:52:54.718933	G2	f	f	\N	\N
397	13	2026-03-20	5	5	WS05	64.80	10.00	15.43	2026-03-20 20:52:54.718933	2026-03-20 20:52:54.718933	G3	f	f	\N	\N
398	13	2026-03-20	5	6	WS06	64.80	15.00	23.15	2026-03-20 20:52:54.718933	2026-03-20 20:52:54.718933	G3	f	f	\N	\N
399	13	2026-03-20	5	7	WS07	64.80	16.00	24.69	2026-03-20 20:52:54.718933	2026-03-20 20:52:54.718933	G4	f	f	\N	\N
400	13	2026-03-20	5	8	WS08	64.80	10.00	15.43	2026-03-20 20:52:54.718933	2026-03-20 20:52:54.718933	G4	f	f	\N	\N
401	15	2026-03-20	5	1	WS01	64.80	84.00	129.63	2026-03-20 21:09:44.355815	2026-03-20 21:09:44.355815	G1	f	f	\N	\N
402	15	2026-03-20	5	2	WS02	64.80	36.00	55.56	2026-03-20 21:09:44.355815	2026-03-20 21:09:44.355815	G1	f	f	\N	\N
403	15	2026-03-20	5	3	WS03	64.80	30.00	46.30	2026-03-20 21:09:44.355815	2026-03-20 21:09:44.355815	G2	f	f	\N	\N
404	15	2026-03-20	5	4	WS04	64.80	20.00	30.86	2026-03-20 21:09:44.355815	2026-03-20 21:09:44.355815	G2	f	f	\N	\N
405	15	2026-03-20	5	5	WS05	64.80	10.00	15.43	2026-03-20 21:09:44.355815	2026-03-20 21:09:44.355815	G3	f	f	\N	\N
406	15	2026-03-20	5	6	WS06	64.80	15.00	23.15	2026-03-20 21:09:44.355815	2026-03-20 21:09:44.355815	G3	f	f	\N	\N
311	1	2026-03-18	5	1	W1	57.60	53.64	93.13	2026-03-18 17:04:39.265204	2026-03-18 17:04:39.265204	G1	f	f	\N	\N
312	1	2026-03-18	5	2	W2	57.60	50.04	86.87	2026-03-18 17:04:39.278463	2026-03-18 17:04:39.278463	G1	f	f	\N	\N
313	1	2026-03-18	5	3	W3	57.60	50.04	86.87	2026-03-18 17:04:39.286297	2026-03-18 17:04:39.286297	G2	f	f	\N	\N
314	1	2026-03-18	5	4	W4	57.60	42.12	73.13	2026-03-18 17:04:39.290849	2026-03-18 17:04:39.290849	G2	f	f	\N	\N
315	1	2026-03-18	5	5	W5	57.60	43.92	76.25	2026-03-18 17:04:39.295158	2026-03-18 17:04:39.295158	G1	f	f	\N	\N
316	1	2026-03-18	5	6	W6	57.60	43.92	76.25	2026-03-18 17:04:39.299898	2026-03-18 17:04:39.299898	G2	f	f	\N	\N
317	1	2026-03-18	5	7	W7	57.60	47.88	83.13	2026-03-18 17:04:39.304979	2026-03-18 17:04:39.304979	G2	f	f	\N	\N
318	1	2026-03-18	5	8	W8	57.60	54.36	94.38	2026-03-18 17:04:39.309629	2026-03-18 17:04:39.309629	G2	f	f	\N	\N
319	1	2026-03-18	5	9	W9	57.60	45.00	78.13	2026-03-18 17:04:39.31677	2026-03-18 17:04:39.31677	G3	f	f	\N	\N
320	1	2026-03-18	5	10	W10	57.60	55.08	95.63	2026-03-18 17:04:39.321826	2026-03-18 17:04:39.321826	G3	f	f	\N	\N
407	15	2026-03-20	5	7	WS07	64.80	16.00	24.69	2026-03-20 21:09:44.355815	2026-03-20 21:09:44.355815	G4	f	f	\N	\N
408	15	2026-03-20	5	8	WS08	64.80	10.00	15.43	2026-03-20 21:09:44.355815	2026-03-20 21:09:44.355815	G4	f	f	\N	\N
\.


--
-- Data for Name: line_process_hourly_progress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.line_process_hourly_progress (id, line_id, process_id, work_date, hour_slot, quantity, created_at, updated_at, employee_id, forwarded_quantity, remaining_quantity, qa_rejection, remarks, shortfall_reason) FROM stdin;
2	2	7	2026-01-15	19	1	2026-01-15 19:19:57.690835	2026-01-15 19:19:57.690835	3	0	0	0	\N	\N
3	2	8	2026-01-15	19	4	2026-01-15 19:20:00.121084	2026-01-15 19:20:00.121084	4	0	0	0	\N	\N
6	2	6	2026-01-15	18	8	2026-01-15 19:42:04.213955	2026-01-15 19:42:04.213955	69	0	0	0	\N	\N
1	2	6	2026-01-15	19	2	2026-01-15 19:19:54.708341	2026-01-15 19:56:18.025951	69	0	0	0	\N	\N
9	2	6	2026-01-15	16	2	2026-01-15 19:56:50.230825	2026-01-15 19:56:50.230825	69	0	0	0	\N	\N
10	2	6	2026-01-21	17	5	2026-01-21 17:22:27.378981	2026-01-21 17:43:11.40378	2	3	2	0	\N	\N
12	2	6	2026-01-22	18	20	2026-01-22 18:12:54.871981	2026-01-22 18:43:04.067779	2	10	10	0	\N	\N
15	2	6	2026-02-05	14	5	2026-02-05 14:30:43.226622	2026-02-05 14:30:43.226622	64	2	3	0	\N	\N
16	1	78	2026-02-10	15	1	2026-02-10 15:29:50.959833	2026-02-10 15:29:50.959833	120	1	0	0	Done good	\N
17	2	80	2026-02-13	16	10	2026-02-13 16:34:42.33944	2026-02-13 16:34:42.33944	67	10	0	0	\N	\N
18	2	80	2026-02-17	15	10	2026-02-17 15:52:19.002208	2026-02-17 15:52:19.002208	67	10	0	0	\N	\N
19	1	83	2026-03-10	14	11	2026-03-10 14:16:19.999158	2026-03-10 14:16:19.999158	1	11	0	0	\N	\N
20	1	84	2026-03-10	14	11	2026-03-10 14:16:20.00258	2026-03-10 14:16:20.00258	1	11	0	0	\N	\N
21	1	85	2026-03-10	14	11	2026-03-10 14:16:20.004646	2026-03-10 14:16:20.004646	1	11	0	0	\N	\N
22	1	86	2026-03-10	14	11	2026-03-10 14:16:23.050979	2026-03-10 14:16:23.050979	2	11	0	0	\N	\N
23	1	87	2026-03-10	14	11	2026-03-10 14:16:23.053207	2026-03-10 14:16:23.053207	2	11	0	0	\N	\N
24	1	88	2026-03-10	14	11	2026-03-10 14:16:25.940347	2026-03-10 14:16:25.940347	3	11	0	0	\N	\N
25	1	89	2026-03-10	14	11	2026-03-10 14:16:28.823811	2026-03-10 14:16:28.823811	4	11	0	0	\N	\N
26	1	90	2026-03-10	14	11	2026-03-10 14:16:31.732047	2026-03-10 14:16:31.732047	5	11	0	0	\N	\N
27	1	91	2026-03-10	14	11	2026-03-10 14:16:34.35389	2026-03-10 14:16:34.35389	6	11	0	0	\N	\N
28	1	92	2026-03-10	14	11	2026-03-10 14:16:37.288289	2026-03-10 14:16:37.288289	7	11	0	0	\N	\N
29	1	93	2026-03-10	14	11	2026-03-10 14:16:40.081903	2026-03-10 14:16:40.081903	8	11	0	0	\N	\N
30	1	94	2026-03-10	14	11	2026-03-10 14:16:40.083947	2026-03-10 14:16:40.083947	8	11	0	0	\N	\N
31	1	95	2026-03-10	14	11	2026-03-10 14:16:40.085637	2026-03-10 14:16:40.085637	8	11	0	0	\N	\N
32	1	96	2026-03-10	14	11	2026-03-10 14:16:42.916455	2026-03-10 14:16:42.916455	9	11	0	0	\N	\N
33	1	97	2026-03-10	14	11	2026-03-10 14:16:46.295131	2026-03-10 14:16:46.295131	10	11	0	0	\N	\N
34	1	83	2026-03-10	15	7	2026-03-10 15:11:41.503526	2026-03-10 15:11:41.503526	1	7	0	0	\N	WORKSTATION COMBINED
35	1	84	2026-03-10	15	7	2026-03-10 15:11:41.506689	2026-03-10 15:11:41.506689	1	7	0	0	\N	WORKSTATION COMBINED
36	1	85	2026-03-10	15	7	2026-03-10 15:11:41.508879	2026-03-10 15:11:41.508879	1	7	0	0	\N	WORKSTATION COMBINED
37	1	86	2026-03-10	15	5	2026-03-10 15:14:32.135106	2026-03-10 15:14:32.135106	2	5	0	0	\N	WORKSTATION COMBINED
38	1	87	2026-03-10	15	5	2026-03-10 15:14:32.13814	2026-03-10 15:14:32.13814	2	5	0	0	\N	WORKSTATION COMBINED
39	1	88	2026-03-10	15	11	2026-03-10 15:14:38.016271	2026-03-10 15:14:38.016271	3	11	0	0	\N	\N
40	1	89	2026-03-10	15	12	2026-03-10 15:14:42.189417	2026-03-10 15:14:42.189417	4	12	0	0	\N	\N
41	1	90	2026-03-10	15	11	2026-03-10 15:14:45.180997	2026-03-10 15:14:45.180997	5	11	0	0	\N	\N
42	1	91	2026-03-10	15	11	2026-03-10 15:14:48.098903	2026-03-10 15:14:48.098903	6	11	0	0	\N	\N
43	1	92	2026-03-10	15	11	2026-03-10 15:14:50.665918	2026-03-10 15:14:50.665918	7	11	0	0	\N	\N
44	1	93	2026-03-10	15	11	2026-03-10 15:14:53.510891	2026-03-10 15:14:53.510891	8	11	0	0	\N	\N
45	1	94	2026-03-10	15	11	2026-03-10 15:14:53.5129	2026-03-10 15:14:53.5129	8	11	0	0	\N	\N
46	1	95	2026-03-10	15	11	2026-03-10 15:14:53.514851	2026-03-10 15:14:53.514851	8	11	0	0	\N	\N
47	1	96	2026-03-10	15	11	2026-03-10 15:14:56.300251	2026-03-10 15:14:56.300251	9	11	0	0	\N	\N
48	1	97	2026-03-10	15	11	2026-03-10 15:14:59.453859	2026-03-10 15:14:59.453859	10	11	0	0	\N	\N
49	1	83	2026-03-16	17	11	2026-03-16 17:17:32.504449	2026-03-16 17:17:32.504449	1	11	0	0	\N	\N
50	1	84	2026-03-16	17	11	2026-03-16 17:17:32.508405	2026-03-16 17:17:32.508405	1	11	0	0	\N	\N
51	1	85	2026-03-16	17	11	2026-03-16 17:17:32.51062	2026-03-16 17:17:32.51062	1	11	0	0	\N	\N
52	1	83	2026-03-17	19	11	2026-03-17 20:22:58.897668	2026-03-17 21:49:54.744259	1	11	0	0	\N	\N
54	1	84	2026-03-17	19	11	2026-03-17 20:22:58.903727	2026-03-17 21:49:54.747413	1	11	0	0	\N	\N
56	1	85	2026-03-17	19	11	2026-03-17 20:22:58.9071	2026-03-17 21:49:54.750558	1	11	0	0	\N	\N
74	1	83	2026-03-20	14	22	2026-03-20 14:45:09.232013	2026-03-20 14:45:09.232013	1	22	0	0	\N	INEFFICIENT
75	1	84	2026-03-20	14	22	2026-03-20 14:45:09.23469	2026-03-20 14:45:09.23469	1	22	0	0	\N	INEFFICIENT
76	1	85	2026-03-20	14	22	2026-03-20 14:45:09.236652	2026-03-20 14:45:09.236652	1	22	0	0	\N	INEFFICIENT
\.


--
-- Data for Name: line_shift_closures; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.line_shift_closures (id, line_id, work_date, closed_by, closed_at, notes) FROM stdin;
\.


--
-- Data for Name: line_workstations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.line_workstations (id, line_id, workstation_number, workstation_code, qr_code_path, created_at) FROM stdin;
1101	15	1	W01	qrcodes/workstations/RUMIYA/ws_RUMIYA_W01.png	2026-03-20 21:09:44.791883
3	1	3	W03	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W03.png	2026-02-19 19:22:49.961362
4	1	4	W04	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W04.png	2026-02-19 19:22:49.975617
5	1	5	W05	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W05.png	2026-02-19 19:22:49.988822
6	1	6	W06	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W06.png	2026-02-19 19:22:50.002901
8	1	8	W08	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W08.png	2026-02-19 19:22:50.029272
9	1	9	W09	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W09.png	2026-02-19 19:22:50.043765
10	1	10	W10	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W10.png	2026-02-19 19:22:50.057209
11	1	11	W11	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W11.png	2026-02-19 19:22:50.07087
12	1	12	W12	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W12.png	2026-02-19 19:22:50.083893
13	1	13	W13	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W13.png	2026-02-19 19:22:50.096629
14	1	14	W14	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W14.png	2026-02-19 19:22:50.109286
15	1	15	W15	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W15.png	2026-02-19 19:22:50.12727
16	1	16	W16	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W16.png	2026-02-19 19:22:50.1404
17	1	17	W17	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W17.png	2026-02-19 19:22:50.152988
18	1	18	W18	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W18.png	2026-02-19 19:22:50.165242
20	1	20	W20	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W20.png	2026-02-19 19:22:50.18955
22	1	22	W22	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W22.png	2026-02-19 19:22:50.213895
23	1	23	W23	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W23.png	2026-02-19 19:22:50.225784
24	1	24	W24	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W24.png	2026-02-19 19:22:50.237849
25	1	25	W25	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W25.png	2026-02-19 19:22:50.250318
26	1	26	W26	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W26.png	2026-02-19 19:22:50.262536
27	1	27	W27	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W27.png	2026-02-19 19:22:50.274721
28	1	28	W28	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W28.png	2026-02-19 19:22:50.286639
29	1	29	W29	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W29.png	2026-02-19 19:22:50.298647
30	1	30	W30	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W30.png	2026-02-19 19:22:50.310942
31	1	31	W31	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W31.png	2026-02-19 19:22:50.322801
32	1	32	W32	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W32.png	2026-02-19 19:22:50.334576
33	1	33	W33	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W33.png	2026-02-19 19:22:50.346495
35	1	35	W35	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W35.png	2026-02-19 19:22:50.370191
36	1	36	W36	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W36.png	2026-02-19 19:22:50.381951
37	1	37	W37	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W37.png	2026-02-19 19:22:50.393729
38	1	38	W38	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W38.png	2026-02-19 19:22:50.405479
39	1	39	W39	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W39.png	2026-02-19 19:22:50.41728
40	1	40	W40	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W40.png	2026-02-19 19:22:50.429068
41	1	41	W41	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W41.png	2026-02-19 19:22:50.440835
42	1	42	W42	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W42.png	2026-02-19 19:22:50.452941
43	1	43	W43	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W43.png	2026-02-19 19:22:50.468842
45	1	45	W45	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W45.png	2026-02-19 19:22:50.494481
46	1	46	W46	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W46.png	2026-02-19 19:22:50.508915
47	1	47	W47	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W47.png	2026-02-19 19:22:50.520897
49	1	49	W49	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W49.png	2026-02-19 19:22:50.544765
50	1	50	W50	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W50.png	2026-02-19 19:22:50.557161
51	1	51	W51	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W51.png	2026-02-19 19:22:50.568995
52	1	52	W52	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W52.png	2026-02-19 19:22:50.581052
53	1	53	W53	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W53.png	2026-02-19 19:22:50.592888
54	1	54	W54	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W54.png	2026-02-19 19:22:50.604953
55	1	55	W55	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W55.png	2026-02-19 19:22:50.61834
56	1	56	W56	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W56.png	2026-02-19 19:22:50.630381
57	1	57	W57	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W57.png	2026-02-19 19:22:50.642356
58	1	58	W58	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W58.png	2026-02-19 19:22:50.654493
59	1	59	W59	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W59.png	2026-02-19 19:22:50.666127
60	1	60	W60	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W60.png	2026-02-19 19:22:50.677934
62	1	62	W62	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W62.png	2026-02-19 19:22:50.701388
63	1	63	W63	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W63.png	2026-02-19 19:22:50.712955
64	1	64	W64	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W64.png	2026-02-19 19:22:50.724498
65	1	65	W65	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W65.png	2026-02-19 19:22:50.736288
66	1	66	W66	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W66.png	2026-02-19 19:22:50.750601
67	1	67	W67	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W67.png	2026-02-19 19:22:50.762714
68	1	68	W68	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W68.png	2026-02-19 19:22:50.774635
70	1	70	W70	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W70.png	2026-02-19 19:22:50.799324
71	1	71	W71	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W71.png	2026-02-19 19:22:50.811694
72	1	72	W72	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W72.png	2026-02-19 19:22:50.82353
73	1	73	W73	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W73.png	2026-02-19 19:22:50.836273
74	1	74	W74	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W74.png	2026-02-19 19:22:50.848844
76	1	76	W76	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W76.png	2026-02-19 19:22:50.872267
77	1	77	W77	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W77.png	2026-02-19 19:22:50.884029
78	1	78	W78	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W78.png	2026-02-19 19:22:50.895739
79	1	79	W79	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W79.png	2026-02-19 19:22:50.907566
80	1	80	W80	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W80.png	2026-02-19 19:22:50.919404
81	1	81	W81	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W81.png	2026-02-19 19:22:50.933135
2	1	2	W02	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W02.png	2026-02-19 19:22:49.946949
1102	15	2	W02	qrcodes/workstations/RUMIYA/ws_RUMIYA_W02.png	2026-03-20 21:09:44.80727
84	1	84	W84	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W84.png	2026-02-19 19:22:50.972533
85	1	85	W85	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W85.png	2026-02-19 19:22:50.984947
86	1	86	W86	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W86.png	2026-02-19 19:22:50.997077
87	1	87	W87	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W87.png	2026-02-19 19:22:51.009179
88	1	88	W88	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W88.png	2026-02-19 19:22:51.020834
89	1	89	W89	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W89.png	2026-02-19 19:22:51.032646
90	1	90	W90	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W90.png	2026-02-19 19:22:51.048825
91	1	91	W91	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W91.png	2026-02-19 19:22:51.067156
92	1	92	W92	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W92.png	2026-02-19 19:22:51.083547
93	1	93	W93	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W93.png	2026-02-19 19:22:51.09927
94	1	94	W94	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W94.png	2026-02-19 19:22:51.115096
96	1	96	W96	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W96.png	2026-02-19 19:22:51.143951
97	1	97	W97	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W97.png	2026-02-19 19:22:51.15606
98	1	98	W98	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W98.png	2026-02-19 19:22:51.168087
99	1	99	W99	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W99.png	2026-02-19 19:22:51.18333
101	2	1	W01	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W01.png	2026-02-19 19:22:51.216268
102	2	2	W02	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W02.png	2026-02-19 19:22:51.228701
103	2	3	W03	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W03.png	2026-02-19 19:22:51.240756
104	2	4	W04	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W04.png	2026-02-19 19:22:51.252604
105	2	5	W05	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W05.png	2026-02-19 19:22:51.264712
106	2	6	W06	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W06.png	2026-02-19 19:22:51.276699
107	2	7	W07	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W07.png	2026-02-19 19:22:51.288505
108	2	8	W08	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W08.png	2026-02-19 19:22:51.300423
110	2	10	W10	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W10.png	2026-02-19 19:22:51.324536
111	2	11	W11	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W11.png	2026-02-19 19:22:51.336201
112	2	12	W12	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W12.png	2026-02-19 19:22:51.347751
113	2	13	W13	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W13.png	2026-02-19 19:22:51.359507
114	2	14	W14	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W14.png	2026-02-19 19:22:51.37327
115	2	15	W15	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W15.png	2026-02-19 19:22:51.385963
116	2	16	W16	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W16.png	2026-02-19 19:22:51.39898
117	2	17	W17	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W17.png	2026-02-19 19:22:51.410747
119	2	19	W19	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W19.png	2026-02-19 19:22:51.434929
120	2	20	W20	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W20.png	2026-02-19 19:22:51.448766
121	2	21	W21	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W21.png	2026-02-19 19:22:51.460771
122	2	22	W22	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W22.png	2026-02-19 19:22:51.472569
123	2	23	W23	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W23.png	2026-02-19 19:22:51.484523
124	2	24	W24	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W24.png	2026-02-19 19:22:51.496981
125	2	25	W25	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W25.png	2026-02-19 19:22:51.510015
126	2	26	W26	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W26.png	2026-02-19 19:22:51.522769
128	2	28	W28	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W28.png	2026-02-19 19:22:51.546716
129	2	29	W29	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W29.png	2026-02-19 19:22:51.558371
130	2	30	W30	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W30.png	2026-02-19 19:22:51.570421
131	2	31	W31	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W31.png	2026-02-19 19:22:51.582362
132	2	32	W32	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W32.png	2026-02-19 19:22:51.594006
133	2	33	W33	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W33.png	2026-02-19 19:22:51.605902
134	2	34	W34	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W34.png	2026-02-19 19:22:51.618785
135	2	35	W35	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W35.png	2026-02-19 19:22:51.634717
137	2	37	W37	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W37.png	2026-02-19 19:22:51.658809
138	2	38	W38	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W38.png	2026-02-19 19:22:51.670743
139	2	39	W39	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W39.png	2026-02-19 19:22:51.682898
140	2	40	W40	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W40.png	2026-02-19 19:22:51.694722
141	2	41	W41	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W41.png	2026-02-19 19:22:51.706639
142	2	42	W42	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W42.png	2026-02-19 19:22:51.718429
143	2	43	W43	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W43.png	2026-02-19 19:22:51.730481
144	2	44	W44	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W44.png	2026-02-19 19:22:51.742828
146	2	46	W46	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W46.png	2026-02-19 19:22:51.766866
147	2	47	W47	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W47.png	2026-02-19 19:22:51.779005
148	2	48	W48	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W48.png	2026-02-19 19:22:51.791576
149	2	49	W49	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W49.png	2026-02-19 19:22:51.805266
150	2	50	W50	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W50.png	2026-02-19 19:22:51.816891
151	2	51	W51	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W51.png	2026-02-19 19:22:51.828449
152	2	52	W52	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W52.png	2026-02-19 19:22:51.840169
153	2	53	W53	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W53.png	2026-02-19 19:22:51.852364
155	2	55	W55	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W55.png	2026-02-19 19:22:51.876222
156	2	56	W56	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W56.png	2026-02-19 19:22:51.887764
157	2	57	W57	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W57.png	2026-02-19 19:22:51.899357
158	2	58	W58	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W58.png	2026-02-19 19:22:51.91094
159	2	59	W59	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W59.png	2026-02-19 19:22:51.922627
160	2	60	W60	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W60.png	2026-02-19 19:22:51.935902
161	2	61	W61	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W61.png	2026-02-19 19:22:51.94747
162	2	62	W62	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W62.png	2026-02-19 19:22:51.96764
1103	15	3	W03	qrcodes/workstations/RUMIYA/ws_RUMIYA_W03.png	2026-03-20 21:09:44.821019
1104	15	4	W04	qrcodes/workstations/RUMIYA/ws_RUMIYA_W04.png	2026-03-20 21:09:44.834685
1105	15	5	W05	qrcodes/workstations/RUMIYA/ws_RUMIYA_W05.png	2026-03-20 21:09:44.848383
1106	15	6	W06	qrcodes/workstations/RUMIYA/ws_RUMIYA_W06.png	2026-03-20 21:09:44.861627
1107	15	7	W07	qrcodes/workstations/RUMIYA/ws_RUMIYA_W07.png	2026-03-20 21:09:44.874666
1108	15	8	W08	qrcodes/workstations/RUMIYA/ws_RUMIYA_W08.png	2026-03-20 21:09:44.888822
164	2	64	W64	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W64.png	2026-02-19 19:22:51.992718
165	2	65	W65	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W65.png	2026-02-19 19:22:52.004529
166	2	66	W66	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W66.png	2026-02-19 19:22:52.016637
167	2	67	W67	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W67.png	2026-02-19 19:22:52.028401
168	2	68	W68	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W68.png	2026-02-19 19:22:52.040016
169	2	69	W69	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W69.png	2026-02-19 19:22:52.052007
170	2	70	W70	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W70.png	2026-02-19 19:22:52.063998
171	2	71	W71	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W71.png	2026-02-19 19:22:52.076159
173	2	73	W73	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W73.png	2026-02-19 19:22:52.100146
174	2	74	W74	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W74.png	2026-02-19 19:22:52.11243
175	2	75	W75	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W75.png	2026-02-19 19:22:52.124627
176	2	76	W76	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W76.png	2026-02-19 19:22:52.136639
177	2	77	W77	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W77.png	2026-02-19 19:22:52.148217
178	2	78	W78	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W78.png	2026-02-19 19:22:52.159851
179	2	79	W79	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W79.png	2026-02-19 19:22:52.171731
180	2	80	W80	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W80.png	2026-02-19 19:22:52.183518
182	2	82	W82	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W82.png	2026-02-19 19:22:52.207381
183	2	83	W83	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W83.png	2026-02-19 19:22:52.219233
184	2	84	W84	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W84.png	2026-02-19 19:22:52.232081
185	2	85	W85	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W85.png	2026-02-19 19:22:52.244437
186	2	86	W86	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W86.png	2026-02-19 19:22:52.257544
187	2	87	W87	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W87.png	2026-02-19 19:22:52.2697
188	2	88	W88	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W88.png	2026-02-19 19:22:52.281516
189	2	89	W89	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W89.png	2026-02-19 19:22:52.29392
191	2	91	W91	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W91.png	2026-02-19 19:22:52.317824
192	2	92	W92	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W92.png	2026-02-19 19:22:52.329413
193	2	93	W93	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W93.png	2026-02-19 19:22:52.341347
194	2	94	W94	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W94.png	2026-02-19 19:22:52.353015
195	2	95	W95	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W95.png	2026-02-19 19:22:52.364876
196	2	96	W96	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W96.png	2026-02-19 19:22:52.376745
197	2	97	W97	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W97.png	2026-02-19 19:22:52.388623
198	2	98	W98	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W98.png	2026-02-19 19:22:52.400602
200	2	100	W100	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W100.png	2026-02-19 19:22:52.423829
1109	15	9	W09	qrcodes/workstations/RUMIYA/ws_RUMIYA_W09.png	2026-03-20 21:09:44.905564
1110	15	10	W10	qrcodes/workstations/RUMIYA/ws_RUMIYA_W10.png	2026-03-20 21:09:44.919035
1111	15	11	W11	qrcodes/workstations/RUMIYA/ws_RUMIYA_W11.png	2026-03-20 21:09:44.932702
1112	15	12	W12	qrcodes/workstations/RUMIYA/ws_RUMIYA_W12.png	2026-03-20 21:09:44.946326
1113	15	13	W13	qrcodes/workstations/RUMIYA/ws_RUMIYA_W13.png	2026-03-20 21:09:44.959189
1114	15	14	W14	qrcodes/workstations/RUMIYA/ws_RUMIYA_W14.png	2026-03-20 21:09:44.971951
1115	15	15	W15	qrcodes/workstations/RUMIYA/ws_RUMIYA_W15.png	2026-03-20 21:09:44.98476
1116	15	16	W16	qrcodes/workstations/RUMIYA/ws_RUMIYA_W16.png	2026-03-20 21:09:44.998
1117	15	17	W17	qrcodes/workstations/RUMIYA/ws_RUMIYA_W17.png	2026-03-20 21:09:45.010665
1118	15	18	W18	qrcodes/workstations/RUMIYA/ws_RUMIYA_W18.png	2026-03-20 21:09:45.023092
1119	15	19	W19	qrcodes/workstations/RUMIYA/ws_RUMIYA_W19.png	2026-03-20 21:09:45.035762
1120	15	20	W20	qrcodes/workstations/RUMIYA/ws_RUMIYA_W20.png	2026-03-20 21:09:45.048558
1121	15	21	W21	qrcodes/workstations/RUMIYA/ws_RUMIYA_W21.png	2026-03-20 21:09:45.060961
1122	15	22	W22	qrcodes/workstations/RUMIYA/ws_RUMIYA_W22.png	2026-03-20 21:09:45.0752
1123	15	23	W23	qrcodes/workstations/RUMIYA/ws_RUMIYA_W23.png	2026-03-20 21:09:45.087664
1124	15	24	W24	qrcodes/workstations/RUMIYA/ws_RUMIYA_W24.png	2026-03-20 21:09:45.10022
1125	15	25	W25	qrcodes/workstations/RUMIYA/ws_RUMIYA_W25.png	2026-03-20 21:09:45.113632
1126	15	26	W26	qrcodes/workstations/RUMIYA/ws_RUMIYA_W26.png	2026-03-20 21:09:45.127062
1127	15	27	W27	qrcodes/workstations/RUMIYA/ws_RUMIYA_W27.png	2026-03-20 21:09:45.139722
1128	15	28	W28	qrcodes/workstations/RUMIYA/ws_RUMIYA_W28.png	2026-03-20 21:09:45.152157
1129	15	29	W29	qrcodes/workstations/RUMIYA/ws_RUMIYA_W29.png	2026-03-20 21:09:45.164382
1130	15	30	W30	qrcodes/workstations/RUMIYA/ws_RUMIYA_W30.png	2026-03-20 21:09:45.177077
1131	15	31	W31	qrcodes/workstations/RUMIYA/ws_RUMIYA_W31.png	2026-03-20 21:09:45.189372
1132	15	32	W32	qrcodes/workstations/RUMIYA/ws_RUMIYA_W32.png	2026-03-20 21:09:45.20224
1133	15	33	W33	qrcodes/workstations/RUMIYA/ws_RUMIYA_W33.png	2026-03-20 21:09:45.215657
1134	15	34	W34	qrcodes/workstations/RUMIYA/ws_RUMIYA_W34.png	2026-03-20 21:09:45.227862
1135	15	35	W35	qrcodes/workstations/RUMIYA/ws_RUMIYA_W35.png	2026-03-20 21:09:45.24121
1136	15	36	W36	qrcodes/workstations/RUMIYA/ws_RUMIYA_W36.png	2026-03-20 21:09:45.254005
1137	15	37	W37	qrcodes/workstations/RUMIYA/ws_RUMIYA_W37.png	2026-03-20 21:09:45.266941
1138	15	38	W38	qrcodes/workstations/RUMIYA/ws_RUMIYA_W38.png	2026-03-20 21:09:45.287625
1139	15	39	W39	qrcodes/workstations/RUMIYA/ws_RUMIYA_W39.png	2026-03-20 21:09:45.300187
1140	15	40	W40	qrcodes/workstations/RUMIYA/ws_RUMIYA_W40.png	2026-03-20 21:09:45.312729
1141	15	41	W41	qrcodes/workstations/RUMIYA/ws_RUMIYA_W41.png	2026-03-20 21:09:45.325556
1142	15	42	W42	qrcodes/workstations/RUMIYA/ws_RUMIYA_W42.png	2026-03-20 21:09:45.337883
1143	15	43	W43	qrcodes/workstations/RUMIYA/ws_RUMIYA_W43.png	2026-03-20 21:09:45.350701
1144	15	44	W44	qrcodes/workstations/RUMIYA/ws_RUMIYA_W44.png	2026-03-20 21:09:45.36325
1145	15	45	W45	qrcodes/workstations/RUMIYA/ws_RUMIYA_W45.png	2026-03-20 21:09:45.37583
1146	15	46	W46	qrcodes/workstations/RUMIYA/ws_RUMIYA_W46.png	2026-03-20 21:09:45.388946
1147	15	47	W47	qrcodes/workstations/RUMIYA/ws_RUMIYA_W47.png	2026-03-20 21:09:45.401239
1148	15	48	W48	qrcodes/workstations/RUMIYA/ws_RUMIYA_W48.png	2026-03-20 21:09:45.414372
1149	15	49	W49	qrcodes/workstations/RUMIYA/ws_RUMIYA_W49.png	2026-03-20 21:09:45.426675
1150	15	50	W50	qrcodes/workstations/RUMIYA/ws_RUMIYA_W50.png	2026-03-20 21:09:45.439132
1151	15	51	W51	qrcodes/workstations/RUMIYA/ws_RUMIYA_W51.png	2026-03-20 21:09:45.451565
1152	15	52	W52	qrcodes/workstations/RUMIYA/ws_RUMIYA_W52.png	2026-03-20 21:09:45.463951
1153	15	53	W53	qrcodes/workstations/RUMIYA/ws_RUMIYA_W53.png	2026-03-20 21:09:45.476375
1154	15	54	W54	qrcodes/workstations/RUMIYA/ws_RUMIYA_W54.png	2026-03-20 21:09:45.488727
1155	15	55	W55	qrcodes/workstations/RUMIYA/ws_RUMIYA_W55.png	2026-03-20 21:09:45.501242
1156	15	56	W56	qrcodes/workstations/RUMIYA/ws_RUMIYA_W56.png	2026-03-20 21:09:45.51375
1157	15	57	W57	qrcodes/workstations/RUMIYA/ws_RUMIYA_W57.png	2026-03-20 21:09:45.526996
1158	15	58	W58	qrcodes/workstations/RUMIYA/ws_RUMIYA_W58.png	2026-03-20 21:09:45.539152
1159	15	59	W59	qrcodes/workstations/RUMIYA/ws_RUMIYA_W59.png	2026-03-20 21:09:45.551624
1160	15	60	W60	qrcodes/workstations/RUMIYA/ws_RUMIYA_W60.png	2026-03-20 21:09:45.563889
1161	15	61	W61	qrcodes/workstations/RUMIYA/ws_RUMIYA_W61.png	2026-03-20 21:09:45.577291
1162	15	62	W62	qrcodes/workstations/RUMIYA/ws_RUMIYA_W62.png	2026-03-20 21:09:45.589572
1163	15	63	W63	qrcodes/workstations/RUMIYA/ws_RUMIYA_W63.png	2026-03-20 21:09:45.602309
1164	15	64	W64	qrcodes/workstations/RUMIYA/ws_RUMIYA_W64.png	2026-03-20 21:09:45.615156
1165	15	65	W65	qrcodes/workstations/RUMIYA/ws_RUMIYA_W65.png	2026-03-20 21:09:45.627404
1166	15	66	W66	qrcodes/workstations/RUMIYA/ws_RUMIYA_W66.png	2026-03-20 21:09:45.640799
1167	15	67	W67	qrcodes/workstations/RUMIYA/ws_RUMIYA_W67.png	2026-03-20 21:09:45.653133
1168	15	68	W68	qrcodes/workstations/RUMIYA/ws_RUMIYA_W68.png	2026-03-20 21:09:45.665628
109	2	9	W09	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W09.png	2026-02-19 19:22:51.312677
118	2	18	W18	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W18.png	2026-02-19 19:22:51.422576
127	2	27	W27	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W27.png	2026-02-19 19:22:51.535041
136	2	36	W36	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W36.png	2026-02-19 19:22:51.646861
145	2	45	W45	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W45.png	2026-02-19 19:22:51.754793
154	2	54	W54	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W54.png	2026-02-19 19:22:51.863966
163	2	63	W63	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W63.png	2026-02-19 19:22:51.980864
172	2	72	W72	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W72.png	2026-02-19 19:22:52.087992
181	2	81	W81	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W81.png	2026-02-19 19:22:52.195138
190	2	90	W90	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W90.png	2026-02-19 19:22:52.306112
199	2	99	W99	qrcodes/workstations/GAFOOR_LINE/ws_GAFOOR_LINE_W99.png	2026-02-19 19:22:52.412258
1	1	1	W01	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W01.png	2026-02-19 19:22:49.919484
7	1	7	W07	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W07.png	2026-02-19 19:22:50.01599
19	1	19	W19	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W19.png	2026-02-19 19:22:50.17716
44	1	44	W44	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W44.png	2026-02-19 19:22:50.480832
69	1	69	W69	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W69.png	2026-02-19 19:22:50.787364
100	1	100	W100	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W100.png	2026-02-19 19:22:51.198112
21	1	21	W21	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W21.png	2026-02-19 19:22:50.201956
34	1	34	W34	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W34.png	2026-02-19 19:22:50.358216
48	1	48	W48	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W48.png	2026-02-19 19:22:50.533012
61	1	61	W61	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W61.png	2026-02-19 19:22:50.689732
75	1	75	W75	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W75.png	2026-02-19 19:22:50.860623
82	1	82	W82	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W82.png	2026-02-19 19:22:50.946933
83	1	83	W83	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W83.png	2026-02-19 19:22:50.959383
95	1	95	W95	qrcodes/workstations/RUMIYA_LINE/ws_RUMIYA_LINE_W95.png	2026-02-19 19:22:51.131161
1169	15	69	W69	qrcodes/workstations/RUMIYA/ws_RUMIYA_W69.png	2026-03-20 21:09:45.678237
1170	15	70	W70	qrcodes/workstations/RUMIYA/ws_RUMIYA_W70.png	2026-03-20 21:09:45.691553
1171	15	71	W71	qrcodes/workstations/RUMIYA/ws_RUMIYA_W71.png	2026-03-20 21:09:45.703771
1001	13	1	W01	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W01.png	2026-03-20 20:50:05.21183
1002	13	2	W02	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W02.png	2026-03-20 20:50:05.240307
1003	13	3	W03	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W03.png	2026-03-20 20:50:05.256121
1004	13	4	W04	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W04.png	2026-03-20 20:50:05.269663
1005	13	5	W05	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W05.png	2026-03-20 20:50:05.283604
1006	13	6	W06	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W06.png	2026-03-20 20:50:05.297578
1007	13	7	W07	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W07.png	2026-03-20 20:50:05.310612
1008	13	8	W08	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W08.png	2026-03-20 20:50:05.324623
1009	13	9	W09	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W09.png	2026-03-20 20:50:05.339512
1010	13	10	W10	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W10.png	2026-03-20 20:50:05.355342
1011	13	11	W11	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W11.png	2026-03-20 20:50:05.370181
1012	13	12	W12	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W12.png	2026-03-20 20:50:05.384821
1013	13	13	W13	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W13.png	2026-03-20 20:50:05.39963
1014	13	14	W14	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W14.png	2026-03-20 20:50:05.414162
1015	13	15	W15	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W15.png	2026-03-20 20:50:05.428257
1016	13	16	W16	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W16.png	2026-03-20 20:50:05.444261
1017	13	17	W17	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W17.png	2026-03-20 20:50:05.458665
1018	13	18	W18	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W18.png	2026-03-20 20:50:05.473431
1019	13	19	W19	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W19.png	2026-03-20 20:50:05.487998
1020	13	20	W20	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W20.png	2026-03-20 20:50:05.502206
1021	13	21	W21	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W21.png	2026-03-20 20:50:05.516225
1022	13	22	W22	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W22.png	2026-03-20 20:50:05.530633
1023	13	23	W23	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W23.png	2026-03-20 20:50:05.545099
1024	13	24	W24	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W24.png	2026-03-20 20:50:05.558958
1025	13	25	W25	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W25.png	2026-03-20 20:50:05.573336
1026	13	26	W26	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W26.png	2026-03-20 20:50:05.587478
1027	13	27	W27	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W27.png	2026-03-20 20:50:05.601508
1028	13	28	W28	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W28.png	2026-03-20 20:50:05.616151
1029	13	29	W29	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W29.png	2026-03-20 20:50:05.63195
1030	13	30	W30	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W30.png	2026-03-20 20:50:05.646026
1031	13	31	W31	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W31.png	2026-03-20 20:50:05.660616
1032	13	32	W32	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W32.png	2026-03-20 20:50:05.674952
1033	13	33	W33	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W33.png	2026-03-20 20:50:05.689308
1034	13	34	W34	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W34.png	2026-03-20 20:50:05.70337
1035	13	35	W35	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W35.png	2026-03-20 20:50:05.717994
1036	13	36	W36	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W36.png	2026-03-20 20:50:05.740584
1037	13	37	W37	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W37.png	2026-03-20 20:50:05.754441
1038	13	38	W38	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W38.png	2026-03-20 20:50:05.768831
1039	13	39	W39	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W39.png	2026-03-20 20:50:05.782613
1040	13	40	W40	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W40.png	2026-03-20 20:50:05.796697
1041	13	41	W41	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W41.png	2026-03-20 20:50:05.81078
1042	13	42	W42	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W42.png	2026-03-20 20:50:05.824569
1043	13	43	W43	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W43.png	2026-03-20 20:50:05.8383
1044	13	44	W44	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W44.png	2026-03-20 20:50:05.853162
1045	13	45	W45	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W45.png	2026-03-20 20:50:05.867018
1046	13	46	W46	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W46.png	2026-03-20 20:50:05.881975
1047	13	47	W47	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W47.png	2026-03-20 20:50:05.896167
1048	13	48	W48	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W48.png	2026-03-20 20:50:05.909986
1049	13	49	W49	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W49.png	2026-03-20 20:50:05.924338
1050	13	50	W50	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W50.png	2026-03-20 20:50:05.938047
1051	13	51	W51	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W51.png	2026-03-20 20:50:05.952271
1052	13	52	W52	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W52.png	2026-03-20 20:50:05.966562
1053	13	53	W53	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W53.png	2026-03-20 20:50:05.981128
1054	13	54	W54	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W54.png	2026-03-20 20:50:05.995087
1055	13	55	W55	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W55.png	2026-03-20 20:50:06.009034
1056	13	56	W56	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W56.png	2026-03-20 20:50:06.023865
1057	13	57	W57	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W57.png	2026-03-20 20:50:06.038341
1058	13	58	W58	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W58.png	2026-03-20 20:50:06.052253
1059	13	59	W59	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W59.png	2026-03-20 20:50:06.066357
1060	13	60	W60	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W60.png	2026-03-20 20:50:06.080797
1061	13	61	W61	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W61.png	2026-03-20 20:50:06.099571
1062	13	62	W62	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W62.png	2026-03-20 20:50:06.11375
1063	13	63	W63	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W63.png	2026-03-20 20:50:06.128496
1064	13	64	W64	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W64.png	2026-03-20 20:50:06.14309
1065	13	65	W65	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W65.png	2026-03-20 20:50:06.157584
1066	13	66	W66	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W66.png	2026-03-20 20:50:06.172327
1067	13	67	W67	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W67.png	2026-03-20 20:50:06.187035
1068	13	68	W68	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W68.png	2026-03-20 20:50:06.201886
1069	13	69	W69	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W69.png	2026-03-20 20:50:06.217326
1070	13	70	W70	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W70.png	2026-03-20 20:50:06.231828
1071	13	71	W71	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W71.png	2026-03-20 20:50:06.247627
1072	13	72	W72	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W72.png	2026-03-20 20:50:06.263121
1073	13	73	W73	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W73.png	2026-03-20 20:50:06.279003
1074	13	74	W74	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W74.png	2026-03-20 20:50:06.293941
1075	13	75	W75	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W75.png	2026-03-20 20:50:06.308525
1076	13	76	W76	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W76.png	2026-03-20 20:50:06.322827
1077	13	77	W77	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W77.png	2026-03-20 20:50:06.337703
1078	13	78	W78	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W78.png	2026-03-20 20:50:06.352015
1079	13	79	W79	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W79.png	2026-03-20 20:50:06.365766
1080	13	80	W80	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W80.png	2026-03-20 20:50:06.379729
1081	13	81	W81	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W81.png	2026-03-20 20:50:06.393851
1082	13	82	W82	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W82.png	2026-03-20 20:50:06.407645
1083	13	83	W83	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W83.png	2026-03-20 20:50:06.422379
1084	13	84	W84	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W84.png	2026-03-20 20:50:06.436509
1085	13	85	W85	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W85.png	2026-03-20 20:50:06.451444
1086	13	86	W86	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W86.png	2026-03-20 20:50:06.466593
1087	13	87	W87	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W87.png	2026-03-20 20:50:06.480731
1088	13	88	W88	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W88.png	2026-03-20 20:50:06.495797
1089	13	89	W89	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W89.png	2026-03-20 20:50:06.511508
1090	13	90	W90	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W90.png	2026-03-20 20:50:06.525652
1091	13	91	W91	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W91.png	2026-03-20 20:50:06.54001
1092	13	92	W92	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W92.png	2026-03-20 20:50:06.553975
1093	13	93	W93	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W93.png	2026-03-20 20:50:06.567785
1094	13	94	W94	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W94.png	2026-03-20 20:50:06.582634
1095	13	95	W95	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W95.png	2026-03-20 20:50:06.597589
1096	13	96	W96	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W96.png	2026-03-20 20:50:06.611574
1097	13	97	W97	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W97.png	2026-03-20 20:50:06.625442
1098	13	98	W98	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W98.png	2026-03-20 20:50:06.639377
1099	13	99	W99	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W99.png	2026-03-20 20:50:06.653223
1100	13	100	W100	qrcodes/workstations/RUMIYA-1/ws_RUMIYA-1_W100.png	2026-03-20 20:50:06.667284
1172	15	72	W72	qrcodes/workstations/RUMIYA/ws_RUMIYA_W72.png	2026-03-20 21:09:45.716042
1173	15	73	W73	qrcodes/workstations/RUMIYA/ws_RUMIYA_W73.png	2026-03-20 21:09:45.728561
1174	15	74	W74	qrcodes/workstations/RUMIYA/ws_RUMIYA_W74.png	2026-03-20 21:09:45.740766
1175	15	75	W75	qrcodes/workstations/RUMIYA/ws_RUMIYA_W75.png	2026-03-20 21:09:45.753013
1176	15	76	W76	qrcodes/workstations/RUMIYA/ws_RUMIYA_W76.png	2026-03-20 21:09:45.765735
1177	15	77	W77	qrcodes/workstations/RUMIYA/ws_RUMIYA_W77.png	2026-03-20 21:09:45.795175
1178	15	78	W78	qrcodes/workstations/RUMIYA/ws_RUMIYA_W78.png	2026-03-20 21:09:45.808103
1179	15	79	W79	qrcodes/workstations/RUMIYA/ws_RUMIYA_W79.png	2026-03-20 21:09:45.820512
1180	15	80	W80	qrcodes/workstations/RUMIYA/ws_RUMIYA_W80.png	2026-03-20 21:09:45.832734
1181	15	81	W81	qrcodes/workstations/RUMIYA/ws_RUMIYA_W81.png	2026-03-20 21:09:45.846457
1182	15	82	W82	qrcodes/workstations/RUMIYA/ws_RUMIYA_W82.png	2026-03-20 21:09:45.859895
1183	15	83	W83	qrcodes/workstations/RUMIYA/ws_RUMIYA_W83.png	2026-03-20 21:09:45.872318
1184	15	84	W84	qrcodes/workstations/RUMIYA/ws_RUMIYA_W84.png	2026-03-20 21:09:45.885072
1185	15	85	W85	qrcodes/workstations/RUMIYA/ws_RUMIYA_W85.png	2026-03-20 21:09:45.897375
1186	15	86	W86	qrcodes/workstations/RUMIYA/ws_RUMIYA_W86.png	2026-03-20 21:09:45.910121
1187	15	87	W87	qrcodes/workstations/RUMIYA/ws_RUMIYA_W87.png	2026-03-20 21:09:45.922758
1188	15	88	W88	qrcodes/workstations/RUMIYA/ws_RUMIYA_W88.png	2026-03-20 21:09:45.935006
1189	15	89	W89	qrcodes/workstations/RUMIYA/ws_RUMIYA_W89.png	2026-03-20 21:09:45.9477
1190	15	90	W90	qrcodes/workstations/RUMIYA/ws_RUMIYA_W90.png	2026-03-20 21:09:45.960016
1191	15	91	W91	qrcodes/workstations/RUMIYA/ws_RUMIYA_W91.png	2026-03-20 21:09:45.972774
1192	15	92	W92	qrcodes/workstations/RUMIYA/ws_RUMIYA_W92.png	2026-03-20 21:09:45.985065
1193	15	93	W93	qrcodes/workstations/RUMIYA/ws_RUMIYA_W93.png	2026-03-20 21:09:45.997767
1194	15	94	W94	qrcodes/workstations/RUMIYA/ws_RUMIYA_W94.png	2026-03-20 21:09:46.010198
1195	15	95	W95	qrcodes/workstations/RUMIYA/ws_RUMIYA_W95.png	2026-03-20 21:09:46.022355
1196	15	96	W96	qrcodes/workstations/RUMIYA/ws_RUMIYA_W96.png	2026-03-20 21:09:46.034983
1197	15	97	W97	qrcodes/workstations/RUMIYA/ws_RUMIYA_W97.png	2026-03-20 21:09:46.047077
1198	15	98	W98	qrcodes/workstations/RUMIYA/ws_RUMIYA_W98.png	2026-03-20 21:09:46.059112
1199	15	99	W99	qrcodes/workstations/RUMIYA/ws_RUMIYA_W99.png	2026-03-20 21:09:46.072363
1200	15	100	W100	qrcodes/workstations/RUMIYA/ws_RUMIYA_W100.png	2026-03-20 21:09:46.086485
\.


--
-- Data for Name: material_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.material_transactions (id, line_id, work_date, transaction_type, quantity, from_process_id, to_process_id, notes, recorded_by, created_at) FROM stdin;
1	2	2026-01-22	issued	100	\N	6	Initial materials at link	\N	2026-01-22 18:12:21.413627
3	2	2026-01-22	issued	100	\N	6	Initial materials at link	\N	2026-01-22 18:18:28.9572
5	2	2026-01-22	forwarded	10	6	7	Hourly progress 18	\N	2026-01-22 18:43:04.074374
6	2	2026-02-04	issued	10	\N	13	Initial materials at link	\N	2026-02-04 20:39:30.279201
7	2	2026-02-04	received	5	\N	13	Existing materials at process	\N	2026-02-04 20:39:30.284562
8	2	2026-02-05	issued	10	\N	6	Initial materials at link	\N	2026-02-05 14:26:51.45615
9	2	2026-02-05	received	5	\N	6	Existing materials at process	\N	2026-02-05 14:26:51.472582
10	2	2026-02-05	forwarded	2	6	7	Hourly progress 14	\N	2026-02-05 14:30:43.233289
11	1	2026-02-10	issued	1	\N	78	Initial materials at link	\N	2026-02-10 15:29:26.141348
12	2	2026-02-13	issued	100	\N	80	Initial materials at link	\N	2026-02-13 16:32:39.576958
\.


--
-- Data for Name: operations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.operations (id, operation_code, operation_name, operation_description, operation_category, is_active, created_at, updated_at, created_by, updated_by, qr_code_path) FROM stdin;
2	OP_002	1st patti  & step patt with  nonwoon  pasting & att	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
3	OP_003	stamp & step patti pasting & atttatching	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
5	OP_005	beeding & cc pkt attatching	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
6	OP_006	1st patti  & step patti with ams'lining close  side stitiching	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
7	OP_007	cc pkt with side stitching	\N	STITCHING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
9	OP_009	cc pkt recutting process	\N	CUTTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
10	OP_010	Gusset leather with recutting process	\N	CUTTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
11	OP_011	Gusset  pvc  with recutting process	\N	CUTTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
13	OP_013	Gusset leather bit recutting process	\N	CUTTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
14	OP_014	logo bit insert & lock	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
16	OP_016	Gusset leather with nonwoon pasting & attatching	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
17	OP_017	kimlon leather with pasting & attatching	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
18	OP_018	leather bit pasting attatching	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
20	OP_020	Gusset with nonwoon pasting	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
21	OP_021	Gusset pvc & nonwoon attatching	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
23	OP_023	Gusset  leather with  creasing loop bit	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
24	OP_024	Gusset leather with embossing process	\N	EMBOSSING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
26	OP_026	Gusset  leather  1st primer	\N	PRIMER	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
27	OP_027	Gusset leather  die process	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
29	OP_029	Gusset  pvc with 1st primer	\N	PRIMER	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
30	OP_030	Gusset  pvc  with die process	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
32	OP_032	interial case  with primer process	\N	PRIMER	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
33	OP_033	interial case  with  die  process	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
34	OP_034	interial  case  sulpa with die	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
36	OP_036	gusset pvc stitching  area thread  pull	\N	STITCHING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
37	OP_037	gusset pvc side stitching	\N	STITCHING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
1	OP_001	E.I PROCESS    ( STEP & STAMP PKT), (WINDOW PKT), (CC PKT) , \n( STAMP PATTI )	\N	EDGE_INKING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
4	OP_004	cc pkt with cover lining pasting & attatching	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
8	OP_008	1st patti & stamp patti stitching	\N	STITCHING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
12	OP_012	Gusset kimlon recuting process	\N	CUTTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
15	OP_015	logo grinding process with tape attatching	\N	GRINDING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
19	OP_019	Gusset pvc pasting	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
38	OP_038	interial case  lable side stitching	\N	STITCHING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
40	OP_040	interial case side edges pasting	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
41	OP_041	interial case mold used edge folding	\N	EDGE_INKING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
43	OP_043	interial case mold used edge folding	\N	EDGE_INKING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
44	OP_044	interial case front & back side seam stitching	\N	STITCHING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
46	OP_046	Gusset leather with D-ring & zipper AMS stitching	\N	STITCHING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
47	OP_047	Gusset leather with D-ring & zipper opposite AMS stitching	\N	STITCHING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
48	OP_048	first patti & window side edges pasting	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
50	OP_050	gusset leather zipper  with side edges pasting	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
51	OP_051	zipper stitching area thread full & kimlon pasting	\N	STITCHING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
52	OP_052	kimlon & zipper mold used attatching	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
54	OP_054	kimlon & zipper mold used folding	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
55	OP_055	interial case  with cc pkt pasting & attatching	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
57	OP_057	interial case with pasting & attatching& thread pull operation	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
58	OP_058	interial case with window pkt pasting	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
59	OP_059	interial case with window pkt mold used attatching	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
61	OP_061	interial case with cc pkt  window stitching	\N	STITCHING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
62	OP_062	final case stage mold used pressing	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
63	OP_063	interial case with final case pasting &  Shape process	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
65	OP_065	interial case with final case Attatching	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
66	OP_066	final stage window side stitching	\N	STITCHING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
67	OP_067	final stage straight  stitching	\N	STITCHING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
69	OP_069	shapping process	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
70	OP_070	cleaning process	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
22	OP_022	Gusset  leather with shape creasing	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
25	OP_025	Gusset leather heating process	\N	HEATING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
28	OP_028	Gusset pvc heating process	\N	HEATING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
31	OP_031	interial case heating process	\N	HEATING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
35	OP_035	interial case embossing side lable pasting & attatching	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
39	OP_039	interial case front & back side seam stitching	\N	STITCHING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
42	OP_042	interial case side edges pasting	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
45	OP_045	Gusset leather with D-ring pasting & attatching	\N	PASTING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
49	OP_049	first patti  with cc pkt & window attatching	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
53	OP_053	kimlon & zipper mold used folding	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
56	OP_056	interial case  with cc pkt  step patti stitching	\N	STITCHING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
60	OP_060	interial case with cc pkt stamp side stitching	\N	STITCHING	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
64	OP_064	interial case with final case Attatching	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
68	OP_068	final lamping	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
71	OP_071	Quality Analysys	\N	GENERAL	t	2026-01-14 15:38:51.766894	2026-01-14 15:38:51.766894	\N	\N	\N
79	OP-0008	PATTI PRIMER 1	\N	\N	t	2026-02-17 15:21:36.973217	2026-02-17 15:21:36.973217	\N	\N	\N
80	OP-0009	PATTI DYE	\N	\N	t	2026-02-17 15:21:36.973217	2026-02-17 15:21:36.973217	\N	\N	\N
81	OP-0010	PATTI PRIMER 2	\N	\N	t	2026-02-17 15:21:36.973217	2026-02-17 15:21:36.973217	\N	\N	\N
82	OP-0011	CLEANING	\N	\N	t	2026-02-17 15:21:36.973217	2026-02-17 15:21:36.973217	\N	\N	\N
83	OP-0012	CLEANING	\N	\N	t	2026-02-17 15:21:36.973217	2026-02-17 15:21:36.973217	\N	\N	\N
84	OP-0013	CLEANING	\N	\N	t	2026-02-17 15:21:36.973217	2026-02-17 15:21:36.973217	\N	\N	\N
72	OP-0001	TOP PASTING	\N	\N	t	2026-02-17 15:21:36.973217	2026-02-17 15:21:36.973217	\N	\N	\N
73	OP-0002	KIMLON PASTING	\N	\N	t	2026-02-17 15:21:36.973217	2026-02-17 15:21:36.973217	\N	\N	\N
74	OP-0003	ATTACHING TOP & KIMLON	\N	\N	t	2026-02-17 15:21:36.973217	2026-02-17 15:21:36.973217	\N	\N	\N
75	OP-0004	GUSSET STITCHING -2NOS	\N	\N	t	2026-02-17 15:21:36.973217	2026-02-17 15:21:36.973217	\N	\N	\N
76	OP-0005	GUSSET LAMPING -2NOS	\N	\N	t	2026-02-17 15:21:36.973217	2026-02-17 15:21:36.973217	\N	\N	\N
77	OP-0006	GUSSET SHAPING	\N	\N	t	2026-02-17 15:21:36.973217	2026-02-17 15:21:36.973217	\N	\N	\N
78	OP-0007	PATTI PROMOTOR	\N	\N	t	2026-02-17 15:21:36.973217	2026-02-17 15:21:36.973217	\N	\N	\N
\.


--
-- Data for Name: process_assignment_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.process_assignment_history (id, line_id, process_id, employee_id, start_time, end_time, quantity_completed, changed_by, created_at, materials_at_link, existing_materials) FROM stdin;
1	2	6	61	2026-02-05 14:29:42.720202	2026-02-05 14:29:42.720202	0	\N	2026-02-05 14:29:42.720202	0	0
2	2	6	64	2026-02-05 14:29:42.720202	\N	0	\N	2026-02-05 14:29:42.720202	0	0
\.


--
-- Data for Name: process_material_wip; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.process_material_wip (id, line_id, process_id, work_date, materials_in, materials_out, wip_quantity, updated_at) FROM stdin;
1	2	6	2026-01-22	200	10	190	2026-01-22 18:43:04.078958
3	2	7	2026-01-22	10	0	10	2026-01-22 18:43:04.081912
9	2	13	2026-02-04	15	0	15	2026-02-04 20:39:30.286108
14	2	7	2026-02-05	2	0	2	2026-02-05 14:30:43.240125
11	2	6	2026-02-05	15	2	3	2026-02-05 14:30:43.242494
16	1	78	2026-02-10	1	0	0	2026-02-10 15:29:50.972053
19	2	80	2026-02-13	100	0	0	2026-02-13 16:34:42.353551
22	2	80	2026-02-17	0	0	0	2026-02-17 15:52:19.025362
\.


--
-- Data for Name: product_processes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_processes (id, product_id, operation_id, sequence_number, operation_sah, cycle_time_seconds, manpower_required, is_active, created_at, updated_at, created_by, updated_by, qr_code_path, target_units, workspace_id, group_name, workstation_code, worker_input_mapping, osm_checked) FROM stdin;
98	10	72	1	0.0033	12	1	t	2026-03-20 14:17:48.408161	2026-03-20 14:17:48.408161	\N	\N	\N	0	\N	\N	\N	CONT	f
99	10	73	2	0.0033	12	1	t	2026-03-20 14:17:48.408161	2026-03-20 14:17:48.408161	\N	\N	\N	0	\N	\N	\N	CONT	t
100	10	74	3	0.0083	30	1	t	2026-03-20 14:17:48.408161	2026-03-20 14:17:48.408161	\N	\N	\N	0	\N	\N	\N	CONT	f
101	10	75	4	0.0083	30	1	t	2026-03-20 14:17:48.408161	2026-03-20 14:17:48.408161	\N	\N	\N	0	\N	\N	\N	CONT	f
102	10	76	5	0.0056	20	1	t	2026-03-20 14:17:48.408161	2026-03-20 14:17:48.408161	\N	\N	\N	0	\N	\N	\N	CONT	t
103	10	77	6	0.0044	16	1	t	2026-03-20 14:17:48.408161	2026-03-20 14:17:48.408161	\N	\N	\N	0	\N	\N	\N	CONT	f
104	10	78	7	0.0056	20	1	t	2026-03-20 14:17:48.408161	2026-03-20 14:17:48.408161	\N	\N	\N	0	\N	\N	\N	CONT	f
105	10	79	8	0.0028	10	1	t	2026-03-20 14:17:48.408161	2026-03-20 14:17:48.408161	\N	\N	\N	0	\N	\N	\N	CONT	t
106	10	80	9	0.0056	20	1	t	2026-03-20 14:17:48.408161	2026-03-20 14:17:48.408161	\N	\N	\N	0	\N	\N	\N	CONT	f
107	10	81	10	0.0028	10	1	t	2026-03-20 14:17:48.408161	2026-03-20 14:17:48.408161	\N	\N	\N	0	\N	\N	\N	CONT	t
108	10	82	11	0.0042	15	1	t	2026-03-20 14:17:48.408161	2026-03-20 14:17:48.408161	\N	\N	\N	0	\N	\N	\N	CONT	f
85	5	74	3	0.0083	30	1	t	2026-02-17 15:21:36.973217	2026-02-17 15:21:36.973217	\N	\N	\N	200	\N	GROUP1	W1	FIRST INPUT	f
86	5	75	4	0.0083	30	1	t	2026-02-17 15:21:36.973217	2026-02-17 15:21:36.973217	\N	\N	\N	200	\N	GROUP1	W2	CONT	f
87	5	76	5	0.0056	20	1	t	2026-02-17 15:21:36.973217	2026-02-17 15:21:36.973217	\N	\N	\N	200	\N	GROUP2	W2	CONT	t
88	5	77	6	0.0044	16	1	t	2026-02-17 15:21:36.973217	2026-02-17 15:21:36.973217	\N	\N	\N	200	\N	GROUP2	W3	CONT	f
89	5	78	7	0.0056	20	1	t	2026-02-17 15:21:36.973217	2026-02-17 15:21:36.973217	\N	\N	\N	200	\N	GROUP2	W4	CONT	f
90	5	79	8	0.0028	10	1	t	2026-02-17 15:21:36.973217	2026-02-17 15:21:36.973217	\N	\N	\N	200	\N	GROUP2	W5	CONT	t
91	5	80	9	0.0056	20	1	t	2026-02-17 15:21:36.973217	2026-02-17 15:21:36.973217	\N	\N	\N	200	\N	GROUP2	W6	CONT	f
92	5	81	10	0.0028	10	1	t	2026-02-17 15:21:36.973217	2026-02-17 15:21:36.973217	\N	\N	\N	200	\N	GROUP2	W7	CONT	t
94	5	82	11	0.0042	15	1	t	2026-02-17 15:21:36.973217	2026-02-17 15:21:36.973217	\N	\N	\N	200	\N	GROUP3	W8	FIRST INPUT	f
8	1	3	3	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
9	1	4	4	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
7	1	2	2	0.0178	64	1	t	2026-01-15 10:27:14.50459	2026-02-17 11:58:52.879263	\N	\N	\N	0	\N	\N	\N	CONT	f
10	1	5	5	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
11	1	6	6	0.0069	25	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
12	1	7	7	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
13	1	8	8	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
14	1	9	9	0.0222	80	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
15	1	10	10	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
16	1	11	11	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
17	1	12	12	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
18	1	13	13	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
19	1	14	14	0.0181	65	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
20	1	15	15	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
21	1	16	16	0.0281	101	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
22	1	17	17	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
23	1	18	18	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
24	1	19	19	0.0111	40	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
25	1	20	20	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
26	1	21	21	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
27	1	22	22	0.0183	66	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
28	1	23	23	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
29	1	24	24	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
30	1	25	25	0.0508	183	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
31	1	26	26	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
32	1	27	27	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
33	1	28	28	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
34	1	29	29	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
35	1	30	30	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
39	1	34	34	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
42	1	37	37	0.0222	80	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
45	1	42	40	0.0419	151	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
48	1	43	43	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
51	1	46	46	0.0203	73	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
54	1	49	49	0.0236	85	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
57	1	52	52	0.0244	88	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
36	1	31	31	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
37	1	32	32	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
38	1	33	33	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
40	1	35	35	0.0189	68	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
41	1	36	36	0.0072	26	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
43	1	38	38	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
44	1	44	39	0.0164	59	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
46	1	43	41	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
47	1	42	42	0.0419	151	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
49	1	44	44	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
50	1	45	45	0.0114	41	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
52	1	47	47	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
53	1	48	48	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
55	1	50	50	0.0269	97	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
56	1	51	51	0.0136	49	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
58	1	54	53	0.0422	152	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
59	1	54	54	0.0419	151	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
61	1	56	56	0.0094	34	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
62	1	57	57	0.0258	93	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
64	1	59	59	0.0336	121	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
65	1	60	60	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
67	1	62	62	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
68	1	63	63	0.0197	71	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
70	1	65	65	0.0297	107	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
71	1	66	66	0.0306	110	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
73	1	68	68	0.0211	76	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
74	1	69	69	0.0281	101	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
76	1	71	71	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
77	2	1	1	0.0122	44	1	t	2026-01-15 10:57:12.368428	2026-02-17 12:37:46.908312	\N	\N	\N	0	\N	1	1	CONT	f
60	1	55	55	0.0283	102	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
63	1	58	58	0.0167	60	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
66	1	61	61	0.0336	121	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
69	1	65	64	0.0286	103	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
72	1	67	67	0.0306	110	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
75	1	70	70	0.0306	110	1	t	2026-01-15 10:27:14.50459	2026-01-15 10:27:14.50459	\N	\N	\N	0	\N	\N	\N	CONT	f
6	1	1	1	0.0278	100	1	t	2026-01-15 10:27:14.50459	2026-01-15 19:40:06.736196	\N	\N	\N	10	\N	\N	\N	CONT	f
80	4	51	1	0.0278	100	1	t	2026-02-13 16:19:59.262395	2026-02-13 16:19:59.262395	\N	\N	\N	0	\N	\N	\N	CONT	f
78	3	11	1	0.0028	10	1	t	2026-02-05 13:57:37.929796	2026-02-17 11:58:52.857877	\N	\N	\N	1	\N	\N	\N	CONT	f
79	2	1	2	0.0028	10	1	t	2026-02-08 13:21:45.532161	2026-02-17 12:37:55.181901	\N	\N	\N	0	\N	1	1	CONT	f
83	5	72	1	0.0033	12	1	t	2026-02-17 15:21:36.973217	2026-02-17 15:21:36.973217	\N	\N	\N	200	\N	GROUP1	W1	FIRST INPUT	f
84	5	73	2	0.0033	12	1	t	2026-02-17 15:21:36.973217	2026-02-17 15:21:36.973217	\N	\N	\N	200	\N	GROUP1	W1	FIRST INPUT	t
95	5	83	12	0.0044	16	1	t	2026-02-17 15:21:36.973217	2026-02-17 15:21:36.973217	\N	\N	\N	200	\N	GROUP3	W8	FIRST INPUT	f
97	5	84	13	0.0028	10	1	t	2026-02-17 15:21:36.973217	2026-02-17 15:31:46.194741	\N	\N	\N	0	\N	GROUP11	W25	CONT	t
93	5	72	93	0.0056	20	1	f	2026-02-17 15:21:36.973217	2026-02-17 15:34:09.508317	\N	\N	\N	0	\N	GROUP3	W7	FIRST INPUT	t
96	5	84	96	0.0125	45	1	f	2026-02-17 15:21:36.973217	2026-02-17 15:21:36.973217	\N	\N	\N	200	\N	GROUP11	W24	\N	t
\.


--
-- Data for Name: production_day_locks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.production_day_locks (work_date, locked_by, locked_at, notes) FROM stdin;
\.


--
-- Data for Name: production_lines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.production_lines (id, line_code, line_name, hall_location, is_active, created_at, updated_at, created_by, updated_by, current_product_id, target_units, efficiency, qr_code_path, line_leader) FROM stdin;
1	RUMIYA_LINE	HALL B RUMIYA LINE	Hall B	t	2026-01-14 15:08:26.291686	2026-03-20 21:49:57.402677	\N	\N	5	500	0.00	qrcodes/lines/line_1.png	Rumiya
2	GAFOOR_LINE	HALL A GAFOOR LINE	Hall A	t	2026-01-14 15:08:26.291686	2026-03-09 22:54:07.479505	\N	\N	1	200	0.00	qrcodes/lines/line_2.png	Gafoor
13	RUMIYA-1	Hall B	Hall B	t	2026-03-20 20:50:04.94559	2026-03-20 20:50:04.94559	\N	\N	\N	0	0.00	qrcodes/lines/line_13.png	Rumiya-One
15	RUMIYA	Hall B	Hall B	t	2026-03-20 21:09:44.355815	2026-03-20 21:09:44.355815	\N	\N	\N	0	0.00	qrcodes/lines/line_15.png	Rumiya
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, product_code, product_name, product_description, category, is_active, created_at, updated_at, created_by, updated_by, line_id, buyer_name, target_qty) FROM stdin;
3	AC4321	TEST 2			t	2026-02-05 13:50:15.741621	2026-02-08 12:56:31.292046	\N	\N	\N	\N	0
4	CY40555	Test One		Purse	t	2026-02-13 16:13:48.876091	2026-02-13 16:14:14.437965	\N	\N	\N	\N	0
2	AB1234	TEST 1	\N	wallet	t	2026-01-15 10:56:31.929644	2026-02-17 14:58:38.059443	\N	\N	1	Buyer 1	500
1	CY405	ACCORDION WALLET	\N	WALLET	t	2026-01-14 15:39:14.422357	2026-02-17 15:00:04.897973	\N	\N	2	Buyer 2	100
10	CG1234	Test	\N	\N	t	2026-03-20 14:17:48.408161	2026-03-20 14:17:48.408161	\N	\N	\N	\N	0
5	4321	BILLFOLD WALLET	\N	SLG	t	2026-02-17 15:21:36.973217	2026-03-09 22:53:57.141574	\N	\N	\N	COACH	500
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, full_name, role, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: worker_adjustments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.worker_adjustments (id, line_id, work_date, departure_id, vacant_workstation_code, from_employee_id, from_workstation_code, adjustment_type, reassignment_time, created_at) FROM stdin;
1	1	2026-03-10	1	W1	2	W2	combine	2026-03-10 14:42:47.579+05:30	2026-03-10 14:42:47.001252+05:30
2	1	2026-03-17	3	W2	1	W1	combine	2026-03-17 20:28:16.382+05:30	2026-03-17 20:28:12.493738+05:30
\.


--
-- Data for Name: worker_departures; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.worker_departures (id, line_id, work_date, employee_id, workstation_code, departure_time, departure_reason, notes, created_at) FROM stdin;
1	1	2026-03-10	1	W1	2026-03-10 14:42:00+05:30	sick	Emergency	2026-03-10 14:42:27.545531+05:30
2	1	2026-03-16	1	W1	2026-03-16 17:22:00+05:30	personal	\N	2026-03-16 17:22:48.256128+05:30
3	1	2026-03-17	2	W2	2026-03-17 20:27:00+05:30	personal	\N	2026-03-17 20:27:45.604518+05:30
4	1	2026-03-20	1	W1	2026-03-20 14:46:00+05:30	operational	\N	2026-03-20 14:46:48.630229+05:30
\.


--
-- Data for Name: workspaces; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workspaces (id, workspace_code, workspace_name, workspace_type, line_id, qr_code_path, is_active, created_at, updated_at, created_by, updated_by, group_name, worker_input_mapping) FROM stdin;
1	WS-01	Stitching Station 1	Stitching	1	\N	f	2026-02-17 11:55:03.41806	2026-02-17 11:58:52.90393	\N	\N	\N	CONT
\.


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 64, true);


--
-- Name: defect_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.defect_log_id_seq', 1, false);


--
-- Name: defect_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.defect_types_id_seq', 16, true);


--
-- Name: downtime_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.downtime_log_id_seq', 1, false);


--
-- Name: downtime_reasons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.downtime_reasons_id_seq', 18, true);


--
-- Name: employee_attendance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_attendance_id_seq', 19, true);


--
-- Name: employee_process_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_process_assignments_id_seq', 256, true);


--
-- Name: employee_workstation_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employee_workstation_assignments_id_seq', 371, true);


--
-- Name: employees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employees_id_seq', 145, true);


--
-- Name: group_wip_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.group_wip_id_seq', 1, false);


--
-- Name: line_daily_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.line_daily_metrics_id_seq', 2, true);


--
-- Name: line_daily_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.line_daily_plans_id_seq', 72, true);


--
-- Name: line_material_stock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.line_material_stock_id_seq', 1, false);


--
-- Name: line_ot_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.line_ot_plans_id_seq', 11, true);


--
-- Name: line_ot_progress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.line_ot_progress_id_seq', 1, false);


--
-- Name: line_ot_workstation_processes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.line_ot_workstation_processes_id_seq', 75, true);


--
-- Name: line_ot_workstations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.line_ot_workstations_id_seq', 50, true);


--
-- Name: line_plan_workstation_processes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.line_plan_workstation_processes_id_seq', 708, true);


--
-- Name: line_plan_workstations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.line_plan_workstations_id_seq', 408, true);


--
-- Name: line_process_hourly_progress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.line_process_hourly_progress_id_seq', 76, true);


--
-- Name: line_shift_closures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.line_shift_closures_id_seq', 1, false);


--
-- Name: line_workstations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.line_workstations_id_seq', 1200, true);


--
-- Name: material_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.material_transactions_id_seq', 12, true);


--
-- Name: operations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.operations_id_seq', 231, true);


--
-- Name: process_assignment_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.process_assignment_history_id_seq', 2, true);


--
-- Name: process_material_wip_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.process_material_wip_id_seq', 23, true);


--
-- Name: product_processes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_processes_id_seq', 109, true);


--
-- Name: production_lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.production_lines_id_seq', 15, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.products_id_seq', 17, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: worker_adjustments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.worker_adjustments_id_seq', 2, true);


--
-- Name: worker_departures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.worker_departures_id_seq', 4, true);


--
-- Name: workspaces_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.workspaces_id_seq', 2, true);


--
-- Name: app_settings app_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_pkey PRIMARY KEY (key);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: defect_log defect_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.defect_log
    ADD CONSTRAINT defect_log_pkey PRIMARY KEY (id);


--
-- Name: defect_types defect_types_defect_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.defect_types
    ADD CONSTRAINT defect_types_defect_code_key UNIQUE (defect_code);


--
-- Name: defect_types defect_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.defect_types
    ADD CONSTRAINT defect_types_pkey PRIMARY KEY (id);


--
-- Name: downtime_log downtime_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.downtime_log
    ADD CONSTRAINT downtime_log_pkey PRIMARY KEY (id);


--
-- Name: downtime_reasons downtime_reasons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.downtime_reasons
    ADD CONSTRAINT downtime_reasons_pkey PRIMARY KEY (id);


--
-- Name: downtime_reasons downtime_reasons_reason_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.downtime_reasons
    ADD CONSTRAINT downtime_reasons_reason_code_key UNIQUE (reason_code);


--
-- Name: employee_attendance employee_attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_attendance
    ADD CONSTRAINT employee_attendance_pkey PRIMARY KEY (id);


--
-- Name: employee_process_assignments employee_process_assignments_employee_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_process_assignments
    ADD CONSTRAINT employee_process_assignments_employee_id_key UNIQUE (employee_id);


--
-- Name: employee_process_assignments employee_process_assignments_line_process_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_process_assignments
    ADD CONSTRAINT employee_process_assignments_line_process_key UNIQUE (line_id, process_id);


--
-- Name: employee_process_assignments employee_process_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_process_assignments
    ADD CONSTRAINT employee_process_assignments_pkey PRIMARY KEY (id);


--
-- Name: employee_workstation_assignments employee_workstation_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_workstation_assignments
    ADD CONSTRAINT employee_workstation_assignments_pkey PRIMARY KEY (id);


--
-- Name: employees employees_emp_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_emp_code_key UNIQUE (emp_code);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: group_wip group_wip_line_id_work_date_group_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_wip
    ADD CONSTRAINT group_wip_line_id_work_date_group_name_key UNIQUE (line_id, work_date, group_name);


--
-- Name: group_wip group_wip_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_wip
    ADD CONSTRAINT group_wip_pkey PRIMARY KEY (id);


--
-- Name: line_daily_metrics line_daily_metrics_line_id_work_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_daily_metrics
    ADD CONSTRAINT line_daily_metrics_line_id_work_date_key UNIQUE (line_id, work_date);


--
-- Name: line_daily_metrics line_daily_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_daily_metrics
    ADD CONSTRAINT line_daily_metrics_pkey PRIMARY KEY (id);


--
-- Name: line_daily_plans line_daily_plans_line_id_work_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_daily_plans
    ADD CONSTRAINT line_daily_plans_line_id_work_date_key UNIQUE (line_id, work_date);


--
-- Name: line_daily_plans line_daily_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_daily_plans
    ADD CONSTRAINT line_daily_plans_pkey PRIMARY KEY (id);


--
-- Name: line_hourly_reports line_hourly_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_hourly_reports
    ADD CONSTRAINT line_hourly_reports_pkey PRIMARY KEY (line_id, work_date, hour_slot);


--
-- Name: line_material_stock line_material_stock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_material_stock
    ADD CONSTRAINT line_material_stock_pkey PRIMARY KEY (id);


--
-- Name: line_ot_plans line_ot_plans_line_id_work_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_ot_plans
    ADD CONSTRAINT line_ot_plans_line_id_work_date_key UNIQUE (line_id, work_date);


--
-- Name: line_ot_plans line_ot_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_ot_plans
    ADD CONSTRAINT line_ot_plans_pkey PRIMARY KEY (id);


--
-- Name: line_ot_progress line_ot_progress_ot_workstation_id_work_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_ot_progress
    ADD CONSTRAINT line_ot_progress_ot_workstation_id_work_date_key UNIQUE (ot_workstation_id, work_date);


--
-- Name: line_ot_progress line_ot_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_ot_progress
    ADD CONSTRAINT line_ot_progress_pkey PRIMARY KEY (id);


--
-- Name: line_ot_workstation_processes line_ot_workstation_processes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_ot_workstation_processes
    ADD CONSTRAINT line_ot_workstation_processes_pkey PRIMARY KEY (id);


--
-- Name: line_ot_workstations line_ot_workstations_ot_plan_id_workstation_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_ot_workstations
    ADD CONSTRAINT line_ot_workstations_ot_plan_id_workstation_code_key UNIQUE (ot_plan_id, workstation_code);


--
-- Name: line_ot_workstations line_ot_workstations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_ot_workstations
    ADD CONSTRAINT line_ot_workstations_pkey PRIMARY KEY (id);


--
-- Name: line_plan_workstation_processes line_plan_workstation_process_workstation_id_product_proces_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_plan_workstation_processes
    ADD CONSTRAINT line_plan_workstation_process_workstation_id_product_proces_key UNIQUE (workstation_id, product_process_id);


--
-- Name: line_plan_workstation_processes line_plan_workstation_processes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_plan_workstation_processes
    ADD CONSTRAINT line_plan_workstation_processes_pkey PRIMARY KEY (id);


--
-- Name: line_plan_workstations line_plan_workstations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_plan_workstations
    ADD CONSTRAINT line_plan_workstations_pkey PRIMARY KEY (id);


--
-- Name: line_process_hourly_progress line_process_hourly_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_process_hourly_progress
    ADD CONSTRAINT line_process_hourly_progress_pkey PRIMARY KEY (id);


--
-- Name: line_shift_closures line_shift_closures_line_id_work_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_shift_closures
    ADD CONSTRAINT line_shift_closures_line_id_work_date_key UNIQUE (line_id, work_date);


--
-- Name: line_shift_closures line_shift_closures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_shift_closures
    ADD CONSTRAINT line_shift_closures_pkey PRIMARY KEY (id);


--
-- Name: line_workstations line_workstations_line_id_workstation_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_workstations
    ADD CONSTRAINT line_workstations_line_id_workstation_code_key UNIQUE (line_id, workstation_code);


--
-- Name: line_workstations line_workstations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_workstations
    ADD CONSTRAINT line_workstations_pkey PRIMARY KEY (id);


--
-- Name: material_transactions material_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_transactions
    ADD CONSTRAINT material_transactions_pkey PRIMARY KEY (id);


--
-- Name: operations operations_operation_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operations
    ADD CONSTRAINT operations_operation_code_key UNIQUE (operation_code);


--
-- Name: operations operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operations
    ADD CONSTRAINT operations_pkey PRIMARY KEY (id);


--
-- Name: process_assignment_history process_assignment_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_assignment_history
    ADD CONSTRAINT process_assignment_history_pkey PRIMARY KEY (id);


--
-- Name: process_material_wip process_material_wip_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_material_wip
    ADD CONSTRAINT process_material_wip_pkey PRIMARY KEY (id);


--
-- Name: product_processes product_processes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_processes
    ADD CONSTRAINT product_processes_pkey PRIMARY KEY (id);


--
-- Name: production_day_locks production_day_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_day_locks
    ADD CONSTRAINT production_day_locks_pkey PRIMARY KEY (work_date);


--
-- Name: production_lines production_lines_line_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_lines
    ADD CONSTRAINT production_lines_line_code_key UNIQUE (line_code);


--
-- Name: production_lines production_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_lines
    ADD CONSTRAINT production_lines_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: products products_product_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_product_code_key UNIQUE (product_code);


--
-- Name: employee_attendance uq_employee_attendance; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_attendance
    ADD CONSTRAINT uq_employee_attendance UNIQUE (employee_id, attendance_date);


--
-- Name: line_material_stock uq_line_material_stock; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_material_stock
    ADD CONSTRAINT uq_line_material_stock UNIQUE (line_id, work_date);


--
-- Name: line_process_hourly_progress uq_line_process_hour; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_process_hourly_progress
    ADD CONSTRAINT uq_line_process_hour UNIQUE (line_id, process_id, work_date, hour_slot);


--
-- Name: process_material_wip uq_process_material_wip; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_material_wip
    ADD CONSTRAINT uq_process_material_wip UNIQUE (line_id, process_id, work_date);


--
-- Name: product_processes uq_product_sequence; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_processes
    ADD CONSTRAINT uq_product_sequence UNIQUE (product_id, sequence_number);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: worker_adjustments worker_adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.worker_adjustments
    ADD CONSTRAINT worker_adjustments_pkey PRIMARY KEY (id);


--
-- Name: worker_departures worker_departures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.worker_departures
    ADD CONSTRAINT worker_departures_pkey PRIMARY KEY (id);


--
-- Name: workspaces workspaces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspaces
    ADD CONSTRAINT workspaces_pkey PRIMARY KEY (id);


--
-- Name: workspaces workspaces_workspace_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspaces
    ADD CONSTRAINT workspaces_workspace_code_key UNIQUE (workspace_code);


--
-- Name: idx_assignment_history_employee; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_assignment_history_employee ON public.process_assignment_history USING btree (employee_id);


--
-- Name: idx_assignment_history_line_process; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_assignment_history_line_process ON public.process_assignment_history USING btree (line_id, process_id);


--
-- Name: idx_assignment_history_open; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_assignment_history_open ON public.process_assignment_history USING btree (line_id, process_id) WHERE (end_time IS NULL);


--
-- Name: idx_assignment_history_start_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_assignment_history_start_time ON public.process_assignment_history USING btree (start_time);


--
-- Name: idx_attendance_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attendance_date ON public.employee_attendance USING btree (attendance_date);


--
-- Name: idx_attendance_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attendance_status ON public.employee_attendance USING btree (status);


--
-- Name: idx_audit_logs_changed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_changed_at ON public.audit_logs USING btree (changed_at);


--
-- Name: idx_audit_logs_ip; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_ip ON public.audit_logs USING btree (ip_address) WHERE (ip_address IS NOT NULL);


--
-- Name: idx_audit_logs_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_session ON public.audit_logs USING btree (session_id) WHERE (session_id IS NOT NULL);


--
-- Name: idx_audit_logs_table; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_table ON public.audit_logs USING btree (table_name);


--
-- Name: idx_audit_logs_table_record; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_table_record ON public.audit_logs USING btree (table_name, record_id);


--
-- Name: idx_audit_logs_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_user ON public.audit_logs USING btree (changed_by);


--
-- Name: idx_day_locks_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_day_locks_date ON public.production_day_locks USING btree (work_date);


--
-- Name: idx_defect_log_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_defect_log_date ON public.defect_log USING btree (work_date);


--
-- Name: idx_defect_log_employee; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_defect_log_employee ON public.defect_log USING btree (employee_id);


--
-- Name: idx_defect_log_line_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_defect_log_line_date ON public.defect_log USING btree (line_id, work_date);


--
-- Name: idx_defect_log_process; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_defect_log_process ON public.defect_log USING btree (process_id);


--
-- Name: idx_defect_log_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_defect_log_status ON public.defect_log USING btree (status);


--
-- Name: idx_defect_log_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_defect_log_type ON public.defect_log USING btree (defect_type_id);


--
-- Name: idx_defect_types_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_defect_types_active ON public.defect_types USING btree (is_active);


--
-- Name: idx_defect_types_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_defect_types_category ON public.defect_types USING btree (defect_category);


--
-- Name: idx_defect_types_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_defect_types_code ON public.defect_types USING btree (defect_code);


--
-- Name: idx_downtime_log_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_downtime_log_date ON public.downtime_log USING btree (work_date);


--
-- Name: idx_downtime_log_line_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_downtime_log_line_date ON public.downtime_log USING btree (line_id, work_date);


--
-- Name: idx_downtime_log_reason; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_downtime_log_reason ON public.downtime_log USING btree (reason_id);


--
-- Name: idx_downtime_log_start; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_downtime_log_start ON public.downtime_log USING btree (start_time);


--
-- Name: idx_downtime_reasons_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_downtime_reasons_active ON public.downtime_reasons USING btree (is_active);


--
-- Name: idx_downtime_reasons_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_downtime_reasons_category ON public.downtime_reasons USING btree (reason_category);


--
-- Name: idx_downtime_reasons_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_downtime_reasons_code ON public.downtime_reasons USING btree (reason_code);


--
-- Name: idx_employees_emp_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employees_emp_code ON public.employees USING btree (emp_code);


--
-- Name: idx_employees_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employees_is_active ON public.employees USING btree (is_active);


--
-- Name: idx_employees_line_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employees_line_id ON public.employees USING btree (default_line_id);


--
-- Name: idx_ewa_employee; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ewa_employee ON public.employee_workstation_assignments USING btree (employee_id);


--
-- Name: idx_ewa_line; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ewa_line ON public.employee_workstation_assignments USING btree (line_id);


--
-- Name: idx_ewa_line_date_ws_ot; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_ewa_line_date_ws_ot ON public.employee_workstation_assignments USING btree (line_id, work_date, workstation_code, is_overtime);


--
-- Name: idx_group_wip_line_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_group_wip_line_date ON public.group_wip USING btree (line_id, work_date);


--
-- Name: idx_hourly_progress_employee; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hourly_progress_employee ON public.line_process_hourly_progress USING btree (employee_id) WHERE (employee_id IS NOT NULL);


--
-- Name: idx_hourly_progress_line_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hourly_progress_line_date ON public.line_process_hourly_progress USING btree (line_id, work_date);


--
-- Name: idx_hourly_progress_work_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hourly_progress_work_date ON public.line_process_hourly_progress USING btree (work_date);


--
-- Name: idx_line_daily_metrics_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_line_daily_metrics_date ON public.line_daily_metrics USING btree (work_date);


--
-- Name: idx_line_daily_metrics_line_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_line_daily_metrics_line_date ON public.line_daily_metrics USING btree (line_id, work_date);


--
-- Name: idx_line_daily_plans_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_line_daily_plans_date ON public.line_daily_plans USING btree (work_date);


--
-- Name: idx_line_daily_plans_line; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_line_daily_plans_line ON public.line_daily_plans USING btree (line_id);


--
-- Name: idx_line_daily_plans_product_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_line_daily_plans_product_date ON public.line_daily_plans USING btree (product_id, work_date);


--
-- Name: idx_line_material_stock_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_line_material_stock_date ON public.line_material_stock USING btree (work_date);


--
-- Name: idx_line_workstations_line; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_line_workstations_line ON public.line_workstations USING btree (line_id);


--
-- Name: idx_lpw_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lpw_group ON public.line_plan_workstations USING btree (line_id, work_date, group_name);


--
-- Name: idx_lpw_line_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lpw_line_date ON public.line_plan_workstations USING btree (line_id, work_date);


--
-- Name: idx_lpw_line_date_product_ws; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_lpw_line_date_product_ws ON public.line_plan_workstations USING btree (line_id, work_date, product_id, workstation_number);


--
-- Name: idx_lpwp_process; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lpwp_process ON public.line_plan_workstation_processes USING btree (product_process_id);


--
-- Name: idx_lpwp_workstation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lpwp_workstation ON public.line_plan_workstation_processes USING btree (workstation_id);


--
-- Name: idx_material_transactions_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_material_transactions_date ON public.material_transactions USING btree (work_date);


--
-- Name: idx_material_transactions_line; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_material_transactions_line ON public.material_transactions USING btree (line_id);


--
-- Name: idx_material_transactions_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_material_transactions_type ON public.material_transactions USING btree (transaction_type);


--
-- Name: idx_material_tx_line_date_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_material_tx_line_date_type ON public.material_transactions USING btree (line_id, work_date, transaction_type);


--
-- Name: idx_operations_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_operations_active ON public.operations USING btree (is_active);


--
-- Name: idx_operations_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_operations_category ON public.operations USING btree (operation_category);


--
-- Name: idx_operations_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_operations_code ON public.operations USING btree (operation_code);


--
-- Name: idx_process_material_wip_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_process_material_wip_date ON public.process_material_wip USING btree (work_date);


--
-- Name: idx_process_material_wip_line; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_process_material_wip_line ON public.process_material_wip USING btree (line_id);


--
-- Name: idx_process_wip_line_process_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_process_wip_line_process_date ON public.process_material_wip USING btree (line_id, process_id, work_date);


--
-- Name: idx_product_processes_operation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_product_processes_operation ON public.product_processes USING btree (operation_id);


--
-- Name: idx_product_processes_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_product_processes_product ON public.product_processes USING btree (product_id);


--
-- Name: idx_product_processes_sequence; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_product_processes_sequence ON public.product_processes USING btree (product_id, sequence_number);


--
-- Name: idx_products_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_active ON public.products USING btree (is_active);


--
-- Name: idx_products_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_products_code ON public.products USING btree (product_code);


--
-- Name: idx_shift_closures_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_shift_closures_date ON public.line_shift_closures USING btree (work_date);


--
-- Name: idx_wa_departure; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wa_departure ON public.worker_adjustments USING btree (departure_id);


--
-- Name: idx_wa_departure_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_wa_departure_unique ON public.worker_adjustments USING btree (departure_id);


--
-- Name: idx_wa_line_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wa_line_date ON public.worker_adjustments USING btree (line_id, work_date);


--
-- Name: idx_wd_employee_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wd_employee_date ON public.worker_departures USING btree (employee_id, work_date);


--
-- Name: idx_wd_line_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wd_line_date ON public.worker_departures USING btree (line_id, work_date);


--
-- Name: idx_wd_line_date_ws_emp; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_wd_line_date_ws_emp ON public.worker_departures USING btree (line_id, work_date, workstation_code, employee_id);


--
-- Name: idx_workspaces_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_workspaces_active ON public.workspaces USING btree (is_active);


--
-- Name: idx_workspaces_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_workspaces_code ON public.workspaces USING btree (workspace_code);


--
-- Name: idx_workspaces_line; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_workspaces_line ON public.workspaces USING btree (line_id);


--
-- Name: material_transactions material_transaction_notify; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER material_transaction_notify AFTER INSERT OR UPDATE ON public.material_transactions FOR EACH ROW EXECUTE FUNCTION public.log_material_transaction();


--
-- Name: employee_process_assignments notify_employee_process_assignments; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER notify_employee_process_assignments AFTER INSERT OR DELETE OR UPDATE ON public.employee_process_assignments FOR EACH ROW EXECUTE FUNCTION public.notify_data_change();


--
-- Name: employees notify_employees; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER notify_employees AFTER INSERT OR DELETE OR UPDATE ON public.employees FOR EACH ROW EXECUTE FUNCTION public.notify_data_change();


--
-- Name: operations notify_operations; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER notify_operations AFTER INSERT OR DELETE OR UPDATE ON public.operations FOR EACH ROW EXECUTE FUNCTION public.notify_data_change();


--
-- Name: product_processes notify_product_processes; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER notify_product_processes AFTER INSERT OR DELETE OR UPDATE ON public.product_processes FOR EACH ROW EXECUTE FUNCTION public.notify_data_change();


--
-- Name: production_lines notify_production_lines; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER notify_production_lines AFTER INSERT OR DELETE OR UPDATE ON public.production_lines FOR EACH ROW EXECUTE FUNCTION public.notify_data_change();


--
-- Name: products notify_products; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER notify_products AFTER INSERT OR DELETE OR UPDATE ON public.products FOR EACH ROW EXECUTE FUNCTION public.notify_data_change();


--
-- Name: defect_log update_defect_log_modtime; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_defect_log_modtime BEFORE UPDATE ON public.defect_log FOR EACH ROW EXECUTE FUNCTION public.update_modified_column();


--
-- Name: defect_types update_defect_types_modtime; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_defect_types_modtime BEFORE UPDATE ON public.defect_types FOR EACH ROW EXECUTE FUNCTION public.update_modified_column();


--
-- Name: downtime_log update_downtime_log_modtime; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_downtime_log_modtime BEFORE UPDATE ON public.downtime_log FOR EACH ROW EXECUTE FUNCTION public.update_modified_column();


--
-- Name: downtime_reasons update_downtime_reasons_modtime; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_downtime_reasons_modtime BEFORE UPDATE ON public.downtime_reasons FOR EACH ROW EXECUTE FUNCTION public.update_modified_column();


--
-- Name: defect_log defect_log_defect_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.defect_log
    ADD CONSTRAINT defect_log_defect_type_id_fkey FOREIGN KEY (defect_type_id) REFERENCES public.defect_types(id);


--
-- Name: defect_log defect_log_detected_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.defect_log
    ADD CONSTRAINT defect_log_detected_by_fkey FOREIGN KEY (detected_by) REFERENCES public.users(id);


--
-- Name: defect_log defect_log_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.defect_log
    ADD CONSTRAINT defect_log_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: defect_log defect_log_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.defect_log
    ADD CONSTRAINT defect_log_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.production_lines(id);


--
-- Name: defect_log defect_log_process_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.defect_log
    ADD CONSTRAINT defect_log_process_id_fkey FOREIGN KEY (process_id) REFERENCES public.product_processes(id);


--
-- Name: defect_log defect_log_rework_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.defect_log
    ADD CONSTRAINT defect_log_rework_employee_id_fkey FOREIGN KEY (rework_employee_id) REFERENCES public.employees(id);


--
-- Name: downtime_log downtime_log_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.downtime_log
    ADD CONSTRAINT downtime_log_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.production_lines(id);


--
-- Name: downtime_log downtime_log_reason_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.downtime_log
    ADD CONSTRAINT downtime_log_reason_id_fkey FOREIGN KEY (reason_id) REFERENCES public.downtime_reasons(id);


--
-- Name: downtime_log downtime_log_reported_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.downtime_log
    ADD CONSTRAINT downtime_log_reported_by_fkey FOREIGN KEY (reported_by) REFERENCES public.users(id);


--
-- Name: downtime_log downtime_log_resolved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.downtime_log
    ADD CONSTRAINT downtime_log_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: employee_attendance employee_attendance_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_attendance
    ADD CONSTRAINT employee_attendance_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: employee_process_assignments employee_process_assignments_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_process_assignments
    ADD CONSTRAINT employee_process_assignments_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: employee_process_assignments employee_process_assignments_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_process_assignments
    ADD CONSTRAINT employee_process_assignments_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.production_lines(id) ON DELETE SET NULL;


--
-- Name: employee_process_assignments employee_process_assignments_process_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_process_assignments
    ADD CONSTRAINT employee_process_assignments_process_id_fkey FOREIGN KEY (process_id) REFERENCES public.product_processes(id) ON DELETE CASCADE;


--
-- Name: employee_workstation_assignments employee_workstation_assignments_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_workstation_assignments
    ADD CONSTRAINT employee_workstation_assignments_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: employee_workstation_assignments employee_workstation_assignments_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_workstation_assignments
    ADD CONSTRAINT employee_workstation_assignments_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.production_lines(id) ON DELETE CASCADE;


--
-- Name: employee_workstation_assignments employee_workstation_assignments_line_plan_workstation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_workstation_assignments
    ADD CONSTRAINT employee_workstation_assignments_line_plan_workstation_id_fkey FOREIGN KEY (line_plan_workstation_id) REFERENCES public.line_plan_workstations(id) ON DELETE CASCADE;


--
-- Name: employees employees_default_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_default_line_id_fkey FOREIGN KEY (default_line_id) REFERENCES public.production_lines(id);


--
-- Name: production_lines fk_lines_current_product; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_lines
    ADD CONSTRAINT fk_lines_current_product FOREIGN KEY (current_product_id) REFERENCES public.products(id);


--
-- Name: products fk_products_line; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT fk_products_line FOREIGN KEY (line_id) REFERENCES public.production_lines(id);


--
-- Name: group_wip group_wip_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_wip
    ADD CONSTRAINT group_wip_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.production_lines(id) ON DELETE CASCADE;


--
-- Name: line_daily_metrics line_daily_metrics_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_daily_metrics
    ADD CONSTRAINT line_daily_metrics_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.production_lines(id) ON DELETE CASCADE;


--
-- Name: line_daily_metrics line_daily_metrics_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_daily_metrics
    ADD CONSTRAINT line_daily_metrics_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: line_daily_plans line_daily_plans_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_daily_plans
    ADD CONSTRAINT line_daily_plans_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: line_daily_plans line_daily_plans_incoming_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_daily_plans
    ADD CONSTRAINT line_daily_plans_incoming_product_id_fkey FOREIGN KEY (incoming_product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: line_daily_plans line_daily_plans_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_daily_plans
    ADD CONSTRAINT line_daily_plans_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.production_lines(id) ON DELETE CASCADE;


--
-- Name: line_daily_plans line_daily_plans_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_daily_plans
    ADD CONSTRAINT line_daily_plans_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE RESTRICT;


--
-- Name: line_daily_plans line_daily_plans_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_daily_plans
    ADD CONSTRAINT line_daily_plans_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: line_hourly_reports line_hourly_reports_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_hourly_reports
    ADD CONSTRAINT line_hourly_reports_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.production_lines(id) ON DELETE CASCADE;


--
-- Name: line_material_stock line_material_stock_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_material_stock
    ADD CONSTRAINT line_material_stock_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.production_lines(id) ON DELETE CASCADE;


--
-- Name: line_ot_plans line_ot_plans_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_ot_plans
    ADD CONSTRAINT line_ot_plans_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.production_lines(id);


--
-- Name: line_ot_plans line_ot_plans_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_ot_plans
    ADD CONSTRAINT line_ot_plans_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: line_ot_progress line_ot_progress_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_ot_progress
    ADD CONSTRAINT line_ot_progress_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE SET NULL;


--
-- Name: line_ot_progress line_ot_progress_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_ot_progress
    ADD CONSTRAINT line_ot_progress_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.production_lines(id) ON DELETE CASCADE;


--
-- Name: line_ot_progress line_ot_progress_ot_workstation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_ot_progress
    ADD CONSTRAINT line_ot_progress_ot_workstation_id_fkey FOREIGN KEY (ot_workstation_id) REFERENCES public.line_ot_workstations(id) ON DELETE CASCADE;


--
-- Name: line_ot_workstation_processes line_ot_workstation_processes_ot_workstation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_ot_workstation_processes
    ADD CONSTRAINT line_ot_workstation_processes_ot_workstation_id_fkey FOREIGN KEY (ot_workstation_id) REFERENCES public.line_ot_workstations(id) ON DELETE CASCADE;


--
-- Name: line_ot_workstation_processes line_ot_workstation_processes_product_process_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_ot_workstation_processes
    ADD CONSTRAINT line_ot_workstation_processes_product_process_id_fkey FOREIGN KEY (product_process_id) REFERENCES public.product_processes(id);


--
-- Name: line_ot_workstations line_ot_workstations_ot_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_ot_workstations
    ADD CONSTRAINT line_ot_workstations_ot_plan_id_fkey FOREIGN KEY (ot_plan_id) REFERENCES public.line_ot_plans(id) ON DELETE CASCADE;


--
-- Name: line_plan_workstation_processes line_plan_workstation_processes_product_process_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_plan_workstation_processes
    ADD CONSTRAINT line_plan_workstation_processes_product_process_id_fkey FOREIGN KEY (product_process_id) REFERENCES public.product_processes(id);


--
-- Name: line_plan_workstation_processes line_plan_workstation_processes_workstation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_plan_workstation_processes
    ADD CONSTRAINT line_plan_workstation_processes_workstation_id_fkey FOREIGN KEY (workstation_id) REFERENCES public.line_plan_workstations(id) ON DELETE CASCADE;


--
-- Name: line_plan_workstations line_plan_workstations_co_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_plan_workstations
    ADD CONSTRAINT line_plan_workstations_co_employee_id_fkey FOREIGN KEY (co_employee_id) REFERENCES public.employees(id) ON DELETE SET NULL;


--
-- Name: line_plan_workstations line_plan_workstations_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_plan_workstations
    ADD CONSTRAINT line_plan_workstations_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.production_lines(id) ON DELETE CASCADE;


--
-- Name: line_plan_workstations line_plan_workstations_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_plan_workstations
    ADD CONSTRAINT line_plan_workstations_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: line_process_hourly_progress line_process_hourly_progress_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_process_hourly_progress
    ADD CONSTRAINT line_process_hourly_progress_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE SET NULL;


--
-- Name: line_process_hourly_progress line_process_hourly_progress_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_process_hourly_progress
    ADD CONSTRAINT line_process_hourly_progress_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.production_lines(id) ON DELETE CASCADE;


--
-- Name: line_process_hourly_progress line_process_hourly_progress_process_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_process_hourly_progress
    ADD CONSTRAINT line_process_hourly_progress_process_id_fkey FOREIGN KEY (process_id) REFERENCES public.product_processes(id) ON DELETE CASCADE;


--
-- Name: line_shift_closures line_shift_closures_closed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_shift_closures
    ADD CONSTRAINT line_shift_closures_closed_by_fkey FOREIGN KEY (closed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: line_shift_closures line_shift_closures_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_shift_closures
    ADD CONSTRAINT line_shift_closures_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.production_lines(id) ON DELETE CASCADE;


--
-- Name: line_workstations line_workstations_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_workstations
    ADD CONSTRAINT line_workstations_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.production_lines(id) ON DELETE CASCADE;


--
-- Name: material_transactions material_transactions_from_process_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_transactions
    ADD CONSTRAINT material_transactions_from_process_id_fkey FOREIGN KEY (from_process_id) REFERENCES public.product_processes(id) ON DELETE SET NULL;


--
-- Name: material_transactions material_transactions_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_transactions
    ADD CONSTRAINT material_transactions_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.production_lines(id) ON DELETE CASCADE;


--
-- Name: material_transactions material_transactions_recorded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_transactions
    ADD CONSTRAINT material_transactions_recorded_by_fkey FOREIGN KEY (recorded_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: material_transactions material_transactions_to_process_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_transactions
    ADD CONSTRAINT material_transactions_to_process_id_fkey FOREIGN KEY (to_process_id) REFERENCES public.product_processes(id) ON DELETE SET NULL;


--
-- Name: process_assignment_history process_assignment_history_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_assignment_history
    ADD CONSTRAINT process_assignment_history_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: process_assignment_history process_assignment_history_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_assignment_history
    ADD CONSTRAINT process_assignment_history_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: process_assignment_history process_assignment_history_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_assignment_history
    ADD CONSTRAINT process_assignment_history_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.production_lines(id) ON DELETE CASCADE;


--
-- Name: process_assignment_history process_assignment_history_process_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_assignment_history
    ADD CONSTRAINT process_assignment_history_process_id_fkey FOREIGN KEY (process_id) REFERENCES public.product_processes(id) ON DELETE CASCADE;


--
-- Name: process_material_wip process_material_wip_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_material_wip
    ADD CONSTRAINT process_material_wip_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.production_lines(id) ON DELETE CASCADE;


--
-- Name: process_material_wip process_material_wip_process_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_material_wip
    ADD CONSTRAINT process_material_wip_process_id_fkey FOREIGN KEY (process_id) REFERENCES public.product_processes(id) ON DELETE CASCADE;


--
-- Name: product_processes product_processes_operation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_processes
    ADD CONSTRAINT product_processes_operation_id_fkey FOREIGN KEY (operation_id) REFERENCES public.operations(id) ON DELETE RESTRICT;


--
-- Name: product_processes product_processes_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_processes
    ADD CONSTRAINT product_processes_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE RESTRICT;


--
-- Name: product_processes product_processes_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_processes
    ADD CONSTRAINT product_processes_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id);


--
-- Name: production_day_locks production_day_locks_locked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_day_locks
    ADD CONSTRAINT production_day_locks_locked_by_fkey FOREIGN KEY (locked_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: worker_adjustments worker_adjustments_departure_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.worker_adjustments
    ADD CONSTRAINT worker_adjustments_departure_id_fkey FOREIGN KEY (departure_id) REFERENCES public.worker_departures(id) ON DELETE CASCADE;


--
-- Name: worker_adjustments worker_adjustments_from_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.worker_adjustments
    ADD CONSTRAINT worker_adjustments_from_employee_id_fkey FOREIGN KEY (from_employee_id) REFERENCES public.employees(id);


--
-- Name: worker_adjustments worker_adjustments_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.worker_adjustments
    ADD CONSTRAINT worker_adjustments_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.production_lines(id) ON DELETE CASCADE;


--
-- Name: worker_departures worker_departures_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.worker_departures
    ADD CONSTRAINT worker_departures_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: worker_departures worker_departures_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.worker_departures
    ADD CONSTRAINT worker_departures_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.production_lines(id) ON DELETE CASCADE;


--
-- Name: workspaces workspaces_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspaces
    ADD CONSTRAINT workspaces_line_id_fkey FOREIGN KEY (line_id) REFERENCES public.production_lines(id);


--
-- PostgreSQL database dump complete
--

\unrestrict EswYVbzplxp14egmXiIpTk4nAkpjfhdFVF7FRFXvLVmSTLTzdUFPFz7rsjly3f3

